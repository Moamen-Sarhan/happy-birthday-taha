<?php
// inc/config.php

// ====== تحميل autoload من Composer ======
$autoload = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoload)) {
    require_once $autoload;
}

// ====== تحميل .env ======
use Dotenv\Dotenv;
$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->safeLoad();

// ====== تعريف الثوابت من .env أو استخدام القيم الافتراضية ======
define('DB_HOST', $_ENV['DB_HOST'] ?? 'database.host2play.gratis');
define('DB_PORT', $_ENV['DB_PORT'] ?? '3306');
define('DB_NAME', $_ENV['DB_NAME'] ?? 's43220_italiano_db');
define('DB_USER', $_ENV['DB_USER'] ?? '');
define('DB_PASS', $_ENV['DB_PASS'] ?? '');

define('DISCORD_CLIENT_ID', $_ENV['DISCORD_CLIENT_ID'] ?? '');
define('DISCORD_CLIENT_SECRET', $_ENV['DISCORD_CLIENT_SECRET'] ?? '');
define('DISCORD_REDIRECT_URI', $_ENV['DISCORD_REDIRECT_URI'] ?? 'https://italiano.ct.ws/Italiano/auth/discord-callback.php');

define('BOT_API_URL', $_ENV['BOT_API_URL'] ?? 'http://node05.host2play.gratis:5032');
define('BOT_API_KEY', $_ENV['BOT_API_KEY'] ?? '');

define('DISCORD_COMPANY_ROLE_ID', $_ENV['DISCORD_COMPANY_ROLE_ID'] ?? '');

// ====== الاتصال بقاعدة البيانات (PDO) - مؤقتاً لحين تحويل جميع الصفحات للـ API ======
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    // سجل الخطأ لكن لا توقف الموقع (لأننا سنستخدم الـ API)
    error_log('❌ PDO Connection Error: ' . $e->getMessage());
    $pdo = null;
}

// ====== تضمين دوال الـ API ======
require_once __DIR__ . '/bot-api.php';

// ====== دوال مساعدة ======
function getBotApiUrl() {
    return BOT_API_URL;
}

function getBotApiKey() {
    return BOT_API_KEY;
}
?>