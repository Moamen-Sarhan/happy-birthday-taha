<?php
// inc/functions.php
function ensureSession() {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}
ensureSession();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;

    global $pdo;
    if (isset($_SESSION['user_id'])) {
        $userId = $_SESSION['user_id'];
        $roles = getUserRolesFromDB($userId, $pdo);
        $_SESSION['roles'] = $roles;
    } else {
        $_SESSION['roles'] = ['member'];
    }

    return [
        'id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'discord_id' => $_SESSION['discord_id'] ?? null,
        'avatar' => $_SESSION['avatar'] ?? null,
        'roles' => $_SESSION['roles'] ?? ['member'],
    ];
}

function getAllRoles($pdo) {
    return $pdo->query("SELECT * FROM roles ORDER BY sort_order")->fetchAll(PDO::FETCH_ASSOC);
}

function getUserRoleKeys($userId, $pdo) {
    $stmt = $pdo->prepare("
        SELECT r.role_key FROM user_roles ur
        JOIN roles r ON ur.role_id = r.id
        WHERE ur.user_id = ?
        ORDER BY r.sort_order
    ");
    $stmt->execute([$userId]);
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

function userHasRole($userRoles, $roleKey) {
    return in_array($roleKey, $userRoles, true);
}

function isFounder($userRoles) {
    return in_array('founder', $userRoles, true);
}

function canManageAppType($userRoles, $managerRoleKey) {
    if (isFounder($userRoles)) return true;
    if (!$managerRoleKey) return false;
    return in_array($managerRoleKey, $userRoles, true);
}

function logout() {
    ensureSession();
    $_SESSION = [];
    session_destroy();
    header('Location: ../pages/index.php');
    exit;
}

function uploadImage($fieldName, $subfolder, $maxWidth = 800, $maxHeight = 600) {
    if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return ['success' => false, 'message' => 'لم يتم رفع أي ملف', 'path' => null];
    }
    if ($_FILES[$fieldName]['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE => 'الملف أكبر من الحد الأقصى المسموح',
            UPLOAD_ERR_FORM_SIZE => 'الملف أكبر من الحد الأقصى المسموح في النموذج',
            UPLOAD_ERR_PARTIAL => 'تم رفع الملف جزئياً',
            UPLOAD_ERR_NO_TMP_DIR => 'مجلد مؤقت غير موجود',
            UPLOAD_ERR_CANT_WRITE => 'فشل كتابة الملف على القرص',
            UPLOAD_ERR_EXTENSION => 'تم إيقاف رفع الملف بواسطة إضافة PHP'
        ];
        $msg = $errors[$_FILES[$fieldName]['error']] ?? 'خطأ غير معروف';
        return ['success' => false, 'message' => 'خطأ في رفع الملف: ' . $msg, 'path' => null];
    }

    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $_FILES[$fieldName]['tmp_name']);
    finfo_close($finfo);

    if (!isset($allowed[$mime])) {
        return ['success' => false, 'message' => 'نوع الملف غير مسموح. الأنواع المسموحة: JPG, PNG, WEBP, GIF', 'path' => null];
    }

    if ($_FILES[$fieldName]['size'] > 5 * 1024 * 1024) {
        return ['success' => false, 'message' => 'حجم الملف يتجاوز 5 ميجابايت', 'path' => null];
    }

    $dir = __DIR__ . '/../uploads/' . $subfolder . '/';
    if (!is_dir($dir)) {
        if (!mkdir($dir, 0755, true)) {
            return ['success' => false, 'message' => 'فشل إنشاء مجلد التحميل', 'path' => null];
        }
    }

    $sourcePath = $_FILES[$fieldName]['tmp_name'];
    $ext = $allowed[$mime];
    $filename = uniqid($subfolder . '_', true) . '.' . $ext;
    $target = $dir . $filename;

    list($srcWidth, $srcHeight, $type) = getimagesize($sourcePath);
    $srcImage = null;
    switch ($type) {
        case IMAGETYPE_JPEG: $srcImage = imagecreatefromjpeg($sourcePath); break;
        case IMAGETYPE_PNG:  $srcImage = imagecreatefrompng($sourcePath); break;
        case IMAGETYPE_WEBP: $srcImage = imagecreatefromwebp($sourcePath); break;
        case IMAGETYPE_GIF:  $srcImage = imagecreatefromgif($sourcePath); break;
        default: return ['success' => false, 'message' => 'نوع الصورة غير مدعوم للمعالجة', 'path' => null];
    }

    $ratio = min($maxWidth / $srcWidth, $maxHeight / $srcHeight);
    $newWidth = (int)($srcWidth * $ratio);
    $newHeight = (int)($srcHeight * $ratio);

    $newImage = imagecreatetruecolor($newWidth, $newHeight);

    if ($type === IMAGETYPE_PNG || $type === IMAGETYPE_GIF) {
        imagealphablending($newImage, false);
        imagesavealpha($newImage, true);
        $transparent = imagecolorallocatealpha($newImage, 255, 255, 255, 127);
        imagefilledrectangle($newImage, 0, 0, $newWidth, $newHeight, $transparent);
    }

    imagecopyresampled($newImage, $srcImage, 0, 0, 0, 0, $newWidth, $newHeight, $srcWidth, $srcHeight);

    switch ($type) {
        case IMAGETYPE_JPEG: imagejpeg($newImage, $target, 90); break;
        case IMAGETYPE_PNG:  imagepng($newImage, $target, 9); break;
        case IMAGETYPE_WEBP: imagewebp($newImage, $target, 90); break;
        case IMAGETYPE_GIF:  imagegif($newImage, $target); break;
    }

    imagedestroy($srcImage);
    imagedestroy($newImage);

    return ['success' => true, 'message' => 'تم رفع الملف وتغيير حجمه بنجاح', 'path' => 'uploads/' . $subfolder . '/' . $filename];
}

if (!function_exists('generateCSRFToken')) {
    function generateCSRFToken() {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('verifyCSRFToken')) {
    function verifyCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
}

function addNotification($pdo, $userId, $type, $title, $message, $link = null) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, type, title, message, link) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$userId, $type, $title, $message, $link]);
        return true;
    } catch (PDOException $e) {
        error_log('Notification error: ' . $e->getMessage());
        return false;
    }
}

function getUserRolesFromDB($userId, $pdo) {
    try {
        $stmt = $pdo->prepare("
            SELECT r.role_key FROM user_roles ur
            JOIN roles r ON ur.role_id = r.id
            WHERE ur.user_id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        error_log('getUserRolesFromDB error: ' . $e->getMessage());
        return [];
    }
}

// ============================================================
// 🤖 دوال البوت
// ============================================================

function addBotAction($pdo, $userId, $actionType, $actionData) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO bot_actions (user_id, action_type, action_data, status) 
            VALUES (?, ?, ?, 'pending')
        ");
        $stmt->execute([$userId, $actionType, json_encode($actionData, JSON_UNESCAPED_UNICODE)]);
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        error_log('addBotAction error: ' . $e->getMessage());
        return false;
    }
}

function sendBotDM($pdo, $userId, $title, $message, $link = null) {
    return addBotAction($pdo, $userId, 'dm', [
        'title' => $title,
        'message' => $message,
        'link' => $link
    ]);
}

function createBotTicket($pdo, $userId, $section, $title, $message) {
    return addBotAction($pdo, $userId, 'create_ticket', [
        'section' => $section,
        'title' => $title,
        'message' => $message
    ]);
}

function sendBotAnnouncement($pdo, $userId, $channelId, $message) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO bot_announcements (channel_id, message, sent_by, status) 
            VALUES (?, ?, ?, 'pending')
        ");
        $stmt->execute([$channelId, $message, $userId]);
        
        return addBotAction($pdo, $userId, 'announcement', [
            'channel_id' => $channelId,
            'message' => $message,
            'announcement_id' => $pdo->lastInsertId()
        ]);
    } catch (PDOException $e) {
        error_log('sendBotAnnouncement error: ' . $e->getMessage());
        return false;
    }
}

function getDiscordChannels() {
    $botApiUrl = BOT_API_URL . '/api/channels';
    try {
        $ch = curl_init($botApiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true) ?? [];
    } catch (Exception $e) {
        return [];
    }
}

// ============================================================
// 🤖 التحقق من حالة البوت (بدون الاعتماد على API مباشرة)
// ============================================================
function getBotStatus($pdo) {
    // محاولة الاتصال بـ API أولاً (إذا كان متاحاً)
    $botApiUrl = BOT_API_URL . '/api/status';
    try {
        $ch = curl_init($botApiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($httpCode === 200 && $response) {
            $data = json_decode($response, true);
            if (isset($data['status']) && $data['status'] === 'online') {
                return 'online';
            }
        }
    } catch (Exception $e) {
        // فشل الاتصال بـ API، ننتقل للفحص عبر قاعدة البيانات
    }
    
    // فحص عبر قاعدة البيانات
    try {
        // 1. هل هناك إجراءات عالقة منذ أكثر من 5 دقائق؟
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM bot_actions 
            WHERE status = 'pending' AND created_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        ");
        $stmt->execute();
        $stuckActions = $stmt->fetchColumn();
        if ($stuckActions > 0) {
            return 'offline';
        }
        
        // 2. هل هناك إجراءات تم تنفيذها خلال آخر دقيقة؟
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM bot_actions 
            WHERE status = 'sent' AND processed_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)
        ");
        $stmt->execute();
        $recentActions = $stmt->fetchColumn();
        if ($recentActions > 0) {
            return 'online';
        }
        
        // 3. هل هناك إجراءات معلقة لم تُنفذ بعد؟
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM bot_actions WHERE status = 'pending'");
        $stmt->execute();
        $pendingActions = $stmt->fetchColumn();
        if ($pendingActions > 0) {
            return 'unknown';
        }
        
        return 'unknown';
    } catch (PDOException $e) {
        return 'unknown';
    }
}

// ============================================================
// 🌾 دوال نظام المزارع
// ============================================================

function getAvailableFarms($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM farms WHERE is_active = 1 AND (available_from IS NULL OR available_from <= NOW()) ORDER BY name");
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function isFarmAvailable($pdo, $farm_id, $start_date, $end_date) {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM farm_bookings 
        WHERE farm_id = ? 
          AND status IN ('pending', 'approved')
          AND start_date <= ? 
          AND end_date >= ?
    ");
    $stmt->execute([$farm_id, $end_date, $start_date]);
    return $stmt->fetchColumn() == 0;
}

function calculateFarmCost($farm_price_per_day, $assistant_price_per_day, $days, $assistants) {
    return ($farm_price_per_day + ($assistant_price_per_day * $assistants)) * $days;
}

function autoCompleteFarmBookings($pdo) {
    try {
        $today = date('Y-m-d');
        // إنهاء الحجوزات المنتهية
        $stmt = $pdo->prepare("
            UPDATE farm_bookings 
            SET status = 'completed' 
            WHERE status = 'approved' AND end_date < ?
        ");
        $stmt->execute([$today]);
        
        // ===== إرسال تذكير قبل 24 ساعة من الانتهاء =====
        $reminderDate = date('Y-m-d', strtotime('+1 day'));
        $stmt = $pdo->prepare("
            SELECT fb.*, u.username, u.discord_id, f.name as farm_name 
            FROM farm_bookings fb
            JOIN users u ON fb.user_id = u.id
            JOIN farms f ON fb.farm_id = f.id
            WHERE fb.status = 'approved' 
              AND fb.end_date = ? 
              AND fb.reminder_sent = 0
        ");
        $stmt->execute([$reminderDate]);
        $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($bookings as $booking) {
            $title = '⏰ تذكير: انتهاء حجز المزرعة غداً!';
            $message = "تذكير: حجزك للمزرعة \"" . $booking['farm_name'] . "\" سينتهي غداً (" . $booking['end_date'] . ").\n";
            $message .= "يرجى التأكد من تسليم المزرعة في الموعد المحدد.";
            sendBotDM($pdo, $booking['user_id'], $title, $message);
            addNotification($pdo, $booking['user_id'], 'farm', $title, $message);
            
            $upd = $pdo->prepare("UPDATE farm_bookings SET reminder_sent = 1 WHERE id = ?");
            $upd->execute([$booking['id']]);
        }
    } catch (PDOException $e) {
        error_log('Auto complete farm bookings error: ' . $e->getMessage());
    }
}

// ============================================================
// 👤 دوال إدارة الأعضاء
// ============================================================

function getMemberByUserId($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT * FROM members WHERE user_id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getMemberById($pdo, $id) {
    $stmt = $pdo->prepare("SELECT * FROM members WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getAllMembers($pdo, $onlyActive = true) {
    $sql = "
        SELECT m.*, u.username, u.discord_id, u.avatar as user_avatar
        FROM members m
        JOIN users u ON m.user_id = u.id
    ";
    if ($onlyActive) {
        $sql .= " WHERE m.is_active = 1";
    }
    $sql .= " ORDER BY m.sort_order ASC, m.display_name ASC";
    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}

function getMemberAvatar($member, $size = 120) {
    // استخدام صورة الملف الشخصي إذا كانت موجودة
    if (!empty($member['avatar'])) {
        return '/Italiano/uploads/members/' . $member['avatar'];
    }
    // وإلا استخدام صورة ديسكورد
    if (!empty($member['discord_id'])) {
        $avatarHash = $member['user_avatar'] ?? '';
        if (!empty($avatarHash)) {
            return 'https://cdn.discordapp.com/avatars/' . $member['discord_id'] . '/' . $avatarHash . '.png?size=' . $size;
        }
        return 'https://cdn.discordapp.com/embed/avatars/' . (intval($member['discord_id']) % 5) . '.png?size=' . $size;
    }
    // صورة افتراضية
    return 'https://ui-avatars.com/api/?name=' . urlencode($member['display_name'] ?? 'U') . '&size=' . $size . '&background=ce2b37&color=fff';
}

function getMemberAvatarUrl($member, $size = 120) {
    return getMemberAvatar($member, $size);
}

function getMemberPosition($member) {
    return $member['position'] ?? 'عضو في العائلة';
}

function getMemberBio($member) {
    return $member['bio'] ?? '';
}

function getMemberAchievements($member) {
    if (empty($member['achievements'])) return [];
    return explode("\n", $member['achievements']);
}
?>