<?php
// inc/bot-api.php
// دوال آمنة للتواصل مع Bot API عبر HTTP مع X-API-Key

if (!defined('BOT_API_URL')) {
    die('❌ BOT_API_URL غير معرف. تأكد من تحميل config.php أولاً.');
}

if (!defined('BOT_API_KEY') || empty(BOT_API_KEY)) {
    die('❌ BOT_API_KEY غير معرف أو فارغ. تأكد من تحميل config.php أولاً.');
}

/**
 * إرسال طلب GET إلى Bot API
 *
 * @param string $endpoint المسار النسبي (مثل: /api/status)
 * @param array|null $params معاملات GET اختيارية
 * @return array|false مصفوفة response أو false عند الفشل
 */
function bot_api_get($endpoint, $params = null)
{
    return bot_api_request($endpoint, 'GET', $params);
}

/**
 * إرسال طلب POST إلى Bot API
 *
 * @param string $endpoint المسار النسبي (مثل: /api/tickets)
 * @param array|null $data بيانات JSON لإرسالها
 * @return array|false مصفوفة response أو false عند الفشل
 */
function bot_api_post($endpoint, $data = null)
{
    return bot_api_request($endpoint, 'POST', $data);
}

/**
 * دالة أساسية لإرسال أي طلب إلى Bot API
 *
 * @param string $endpoint المسار النسبي
 * @param string $method GET أو POST
 * @param array|null $data بيانات للـ POST أو معاملات للـ GET
 * @return array|false مصفوفة response أو false عند الفشل
 */
function bot_api_request($endpoint, $method = 'GET', $data = null)
{
    // بناء الـ URL الكامل
    $baseUrl = rtrim(BOT_API_URL, '/');
    $endpoint = ltrim($endpoint, '/');
    $url = $baseUrl . '/' . $endpoint;

    // إضافة معاملات GET إذا وجدت
    if ($method === 'GET' && is_array($data) && !empty($data)) {
        $url .= '?' . http_build_query($data);
    }

    // تهيئة cURL
    $ch = curl_init();

    // إعدادات cURL الأساسية
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10, // 10 ثواني مهلة
        CURLOPT_HTTPHEADER => [
            'X-API-Key: ' . BOT_API_KEY,
            'Content-Type: application/json',
            'Accept: application/json',
        ],
        CURLOPT_SSL_VERIFYPEER => false, // لو في مشكلة SSL (للاختبار المحلي)
        CURLOPT_FOLLOWLOCATION => true,
    ]);

    // إعدادات خاصة بـ POST
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($data !== null) {
            $jsonData = json_encode($data);
            if ($jsonData === false) {
                error_log('❌ Bot API: فشل في ترميز JSON');
                return false;
            }
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
            // إضافة Content-Type: application/json (مضبوط بالفعل في الـ headers)
        }
    }

    // تنفيذ الطلب
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    // معالجة الأخطاء
    if ($error) {
        error_log("❌ Bot API Request Error: $error (URL: $url)");
        return false;
    }

    if ($httpCode < 200 || $httpCode >= 300) {
        error_log("❌ Bot API HTTP Error: $httpCode (URL: $url)");
        // محاولة فك الـ response لو كان JSON عشان نعرف الخطأ
        $decoded = json_decode($response, true);
        if ($decoded && isset($decoded['error'])) {
            error_log("❌ Bot API Error Message: " . $decoded['error']);
        }
        return false;
    }

    // فك الـ JSON
    $decoded = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('❌ Bot API JSON Parse Error: ' . json_last_error_msg());
        return false;
    }

    return $decoded;
}

// ============================================================
// دوال مساعدة للاستخدام المباشر في الصفحات
// ============================================================

/**
 * جلب حالة البوت
 */
function bot_get_status()
{
    return bot_api_get('/api/status');
}

/**
 * جلب قائمة القنوات النصية من السيرفر
 */
function bot_get_channels()
{
    return bot_api_get('/api/channels');
}

/**
 * جلب قائمة المستخدمين من قاعدة البيانات
 */
function bot_get_users()
{
    return bot_api_get('/api/users');
}

/**
 * جلب التذاكر من قاعدة البيانات
 */
function bot_get_tickets()
{
    return bot_api_get('/api/tickets');
}

/**
 * إنشاء تذكرة جديدة عبر البوت
 */
function bot_create_ticket($userId, $section, $title, $message)
{
    return bot_api_post('/api/tickets', [
        'userId'   => $userId,
        'section'  => $section,
        'title'    => $title,
        'message'  => $message,
    ]);
}

/**
 * جلب بيانات مستخدم معين من قاعدة البيانات
 */
function bot_get_user($userId)
{
    return bot_api_get('/api/users/' . intval($userId));
}

/**
 * جلب بيانات مزرعة معينة
 */
function bot_get_farm($farmId)
{
    return bot_api_get('/api/farms/' . intval($farmId));
}

/**
 * جلب قائمة المزارع
 */
function bot_get_farms()
{
    return bot_api_get('/api/farms');
}

/**
 * جلب حجوزات المزارع
 */
function bot_get_farm_bookings()
{
    return bot_api_get('/api/farm-bookings');
}

// يمكنك إضافة دوال أخرى حسب الحاجة
?>