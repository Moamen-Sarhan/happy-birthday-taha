<?php
require_once __DIR__ . '/../inc/functions.php';
require_once __DIR__ . '/../inc/config.php';
generateCSRFToken();

$isLoggedIn = isLoggedIn();
$currentUser = getCurrentUser();
$userRoles = $currentUser ? ($currentUser['roles'] ?? []) : [];
$isFounder = in_array('founder', $userRoles, true);

if (!$isLoggedIn || !$isFounder) {
    header('Location: index.php');
    exit;
}

$csrfToken = generateCSRFToken();
$editId = isset($_GET['edit']) ? intval($_GET['edit']) : 0;
$editMember = null;
$users = [];
$message = '';
$error = '';

// جلب جميع المستخدمين لإضافتهم كأعضاء
try {
    $users = $pdo->query("SELECT id, username, discord_id, avatar FROM users ORDER BY username")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $users = [];
}

if ($editId > 0) {
    $editMember = getMemberById($pdo, $editId);
    if (!$editMember) {
        $error = '❌ العضو غير موجود';
        $editId = 0;
    }
}

// معالجة حفظ البيانات
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'طلب غير صالح (CSRF)';
    } else {
        $action = $_POST['action'] ?? '';
        $user_id = intval($_POST['user_id'] ?? 0);
        $display_name = trim($_POST['display_name'] ?? '');
        $position = trim($_POST['position'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        $achievements = trim($_POST['achievements'] ?? '');
        $join_date = $_POST['join_date'] ?? '';
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        if ($action === 'add' || $action === 'edit') {
            if (empty($display_name) || $user_id <= 0) {
                $error = 'يرجى ملء الاسم واختيار المستخدم';
            } else {
                // معالجة رفع الصورة
                $avatarPath = null;
                if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
                    $uploadResult = uploadImage('avatar', 'members', 400, 400);
                    if ($uploadResult['success']) {
                        $avatarPath = basename($uploadResult['path']);
                    } else {
                        $error = 'فشل رفع الصورة: ' . $uploadResult['message'];
                    }
                }
                
                if (empty($error)) {
                    try {
                        if ($action === 'add') {
                            // التحقق من عدم وجود العضو مسبقاً
                            $check = $pdo->prepare("SELECT id FROM members WHERE user_id = ?");
                            $check->execute([$user_id]);
                            if ($check->fetchColumn()) {
                                $error = '⚠️ هذا المستخدم مضاف بالفعل كعضو';
                            } else {
                                $stmt = $pdo->prepare("
                                    INSERT INTO members (user_id, display_name, avatar, position, bio, achievements, join_date, is_active)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                                ");
                                $stmt->execute([$user_id, $display_name, $avatarPath, $position, $bio, $achievements, $join_date, $is_active]);
                                $message = '✅ تم إضافة العضو بنجاح!';
                            }
                        } else {
                            // تعديل
                            $id = intval($_POST['id'] ?? 0);
                            if ($id > 0) {
                                $updateFields = "display_name = ?, position = ?, bio = ?, achievements = ?, join_date = ?, is_active = ?";
                                $params = [$display_name, $position, $bio, $achievements, $join_date, $is_active];
                                
                                if ($avatarPath) {
                                    $updateFields = "display_name = ?, avatar = ?, position = ?, bio = ?, achievements = ?, join_date = ?, is_active = ?";
                                    $params = [$display_name, $avatarPath, $position, $bio, $achievements, $join_date, $is_active];
                                }
                                
                                $stmt = $pdo->prepare("UPDATE members SET $updateFields WHERE id = ?");
                                $params[] = $id;
                                $stmt->execute($params);
                                $message = '✅ تم تحديث العضو بنجاح!';
                                $editId = 0;
                                $editMember = null;
                            }
                        }
                    } catch (PDOException $e) {
                        $error = '❌ خطأ في قاعدة البيانات: ' . $e->getMessage();
                    }
                }
            }
        } elseif ($action === 'delete') {
            $id = intval($_POST['id'] ?? 0);
            if ($id > 0) {
                $stmt = $pdo->prepare("DELETE FROM members WHERE id = ?");
                $stmt->execute([$id]);
                $message = '✅ تم حذف العضو بنجاح!';
            }
        }
    }
}

// جلب جميع الأعضاء لعرضهم
$members = getAllMembers($pdo, false);

// تحديث editMember إذا تغير بعد الحفظ
if ($editId > 0 && !$editMember) {
    $editMember = getMemberById($pdo, $editId);
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الأعضاء - Italiano</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/Italiano/css/style.css">
    <style>
        .manage-container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .manage-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; margin-bottom: 30px; }
        .manage-header h1 i { color: var(--accent); }
        .form-card { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--radius); padding: 30px; margin-bottom: 30px; }
        .form-card h3 { margin-bottom: 20px; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-grid .full-width { grid-column: span 2; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 6px; color: var(--text-secondary); }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 10px; background: var(--bg-input);
            border: 1px solid var(--border-color); border-radius: var(--radius-sm);
            color: var(--text-primary); font-family: inherit;
        }
        .form-group input[type="file"] { padding: 8px; background: transparent; }
        .form-group textarea { resize: vertical; min-height: 80px; }
        .form-group .checkbox-group { display: flex; align-items: center; gap: 10px; }
        .form-group .checkbox-group input { width: auto; }
        .btn-submit { background: var(--accent); color: white; border: none; padding: 12px 30px; border-radius: var(--radius-full); font-weight: 700; cursor: pointer; transition: var(--transition); }
        .btn-submit:hover { background: var(--accent-hover); transform: translateY(-2px); }
        .btn-cancel { background: #6c757d; color: white; border: none; padding: 12px 30px; border-radius: var(--radius-full); font-weight: 700; cursor: pointer; transition: var(--transition); text-decoration: none; display: inline-block; }
        .btn-cancel:hover { background: #5a6268; }
        .btn-delete { background: #dc3545; color: white; border: none; padding: 8px 20px; border-radius: var(--radius-full); font-weight: 700; cursor: pointer; transition: var(--transition); }
        .btn-delete:hover { background: #c82333; }
        .member-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; }
        .member-item { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: var(--radius); padding: 20px; text-align: center; transition: var(--transition); }
        .member-item:hover { border-color: var(--accent); }
        .member-item img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 2px solid var(--accent); margin-bottom: 10px; }
        .member-item .name { font-weight: 700; color: var(--text-primary); }
        .member-item .pos { color: var(--accent); font-size: 14px; }
        .member-item .status { font-size: 12px; padding: 2px 12px; border-radius: 20px; display: inline-block; margin-top: 5px; }
        .member-item .status-active { background: #10b98120; color: #10b981; border: 1px solid #10b98140; }
        .member-item .status-inactive { background: #ef444420; color: #ef4444; border: 1px solid #ef444440; }
        .member-item .actions { margin-top: 12px; display: flex; gap: 8px; justify-content: center; flex-wrap: wrap; }
        .alert-success { background: #10b98120; border: 1px solid #10b98140; color: #10b981; padding: 12px 20px; border-radius: var(--radius-sm); margin-bottom: 20px; }
        .alert-danger { background: #ef444420; border: 1px solid #ef444440; color: #ef4444; padding: 12px 20px; border-radius: var(--radius-sm); margin-bottom: 20px; }
        .back-link { color: var(--text-secondary); text-decoration: none; font-weight: 600; }
        .back-link i { margin-left: 8px; }
        .member-avatar-preview { width: 120px; height: 120px; border-radius: 50%; object-fit: cover; border: 3px solid var(--accent); margin: 10px auto; display: block; }
    </style>
</head>
<body>

<!-- ===== الهيدر ===== -->
<header class="header">
    <a href="/Italiano/index.php?tab=home" class="logo" style="display:flex; align-items:center; gap:10px; text-decoration:none;">
        <img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png?ver=2" alt="ITV - Italiano">
    </a>
    <nav class="nav">
        <a href="/Italiano/pages/rules.php?tab=rules"><i class="fas fa-gavel"></i> القوانين</a>
        <a href="/Italiano/index.php?tab=store"><i class="fas fa-store"></i> المتجر</a>
        <a href="/Italiano/index.php?tab=applications"><i class="fas fa-file-signature"></i> التقديمات</a>
        <a href="/Italiano/index.php?tab=farms"><i class="fas fa-tractor"></i> المزارع</a>
        <a href="/Italiano/pages/members.php"><i class="fas fa-users"></i> الأعضاء</a>
    </nav>
    <div style="display:flex; align-items:center; gap:14px;">
        <a href="/Italiano/index.php?tab=profile" class="profile-wrapper">
            <div class="avatar-container">
                <div class="fallback"><?php echo strtoupper(substr($currentUser['username'] ?? 'U', 0, 1)); ?></div>
                <span class="status-dot"></span>
            </div>
            <span class="profile-name"><?php echo htmlspecialchars($currentUser['username'] ?? 'مستخدم'); ?></span>
        </a>
        <a href="/Italiano/index.php?tab=dashboard" class="dashboard-icon" title="لوحة التحكم"><i class="fas fa-th"></i></a>
    </div>
</header>

<!-- ===== المحتوى ===== -->
<div class="manage-container">

    <a href="/Italiano/pages/members.php" class="back-link"><i class="fas fa-arrow-right"></i> العودة للأعضاء</a>

    <div class="manage-header">
        <h1><i class="fas fa-user-edit"></i> إدارة الأعضاء</h1>
        <span style="color: var(--text-secondary);">عدد الأعضاء: <?php echo count($members); ?></span>
    </div>

    <?php if ($message): ?>
        <div class="alert-success"><i class="fas fa-check-circle"></i> <?php echo $message; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <!-- ===== نموذج إضافة/تعديل ===== -->
    <div class="form-card">
        <h3>
            <i class="fas fa-<?php echo $editMember ? 'pen' : 'plus'; ?>"></i>
            <?php echo $editMember ? 'تعديل العضو' : 'إضافة عضو جديد'; ?>
        </h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
            <input type="hidden" name="action" value="<?php echo $editMember ? 'edit' : 'add'; ?>">
            <?php if ($editMember): ?>
                <input type="hidden" name="id" value="<?php echo $editMember['id']; ?>">
            <?php endif; ?>

            <div class="form-grid">
                <div class="form-group">
                    <label>اختر المستخدم *</label>
                    <select name="user_id" required <?php echo $editMember ? 'disabled' : ''; ?>>
                        <option value="">-- اختر مستخدم --</option>
                        <?php foreach ($users as $user): ?>
                            <option value="<?php echo $user['id']; ?>" <?php echo ($editMember && $editMember['user_id'] == $user['id']) || (!$editMember && $user['id'] == ($_POST['user_id'] ?? 0)) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($user['username']); ?> (<?php echo htmlspecialchars($user['discord_id'] ?? 'لا يوجد ديسكورد'); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>الاسم المعروض *</label>
                    <input type="text" name="display_name" value="<?php echo htmlspecialchars($editMember['display_name'] ?? ($_POST['display_name'] ?? '')); ?>" required>
                </div>

                <div class="form-group">
                    <label>الوظيفة / المنصب</label>
                    <input type="text" name="position" value="<?php echo htmlspecialchars($editMember['position'] ?? ($_POST['position'] ?? '')); ?>" placeholder="مثلاً: مدير العمليات">
                </div>

                <div class="form-group">
                    <label>تاريخ الانضمام</label>
                    <input type="date" name="join_date" value="<?php echo $editMember['join_date'] ?? ($_POST['join_date'] ?? ''); ?>">
                </div>

                <div class="form-group full-width">
                    <label>نبذة عن العضو</label>
                    <textarea name="bio" rows="3" placeholder="اكتب نبذة عن العضو..."><?php echo htmlspecialchars($editMember['bio'] ?? ($_POST['bio'] ?? '')); ?></textarea>
                </div>

                <div class="form-group full-width">
                    <label>الإنجازات (كل إنجاز في سطر جديد)</label>
                    <textarea name="achievements" rows="4" placeholder="اكتب الإنجازات كل واحد في سطر..."><?php echo htmlspecialchars($editMember['achievements'] ?? ($_POST['achievements'] ?? '')); ?></textarea>
                </div>

                <div class="form-group">
                    <label>صورة العضو</label>
                    <input type="file" name="avatar" accept="image/*">
                    <?php if ($editMember && !empty($editMember['avatar'])): ?>
                        <img src="/Italiano/uploads/members/<?php echo htmlspecialchars($editMember['avatar']); ?>" alt="صورة" class="member-avatar-preview">
                    <?php endif; ?>
                </div>

                <div class="form-group" style="display:flex; align-items:flex-end;">
                    <div class="checkbox-group">
                        <input type="checkbox" name="is_active" id="is_active" <?php echo ($editMember && $editMember['is_active'] == 1) || (!isset($_POST['is_active']) && !$editMember) ? 'checked' : ''; ?>>
                        <label for="is_active">نشط (يظهر في قائمة الأعضاء)</label>
                    </div>
                </div>
            </div>

            <div style="display:flex; gap:12px; flex-wrap:wrap; margin-top:15px;">
                <button type="submit" class="btn-submit"><i class="fas fa-save"></i> <?php echo $editMember ? 'تحديث' : 'إضافة'; ?></button>
                <?php if ($editMember): ?>
                    <a href="?edit=0" class="btn-cancel"><i class="fas fa-times"></i> إلغاء التعديل</a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- ===== قائمة الأعضاء الحاليين ===== -->
    <h3 style="margin-bottom:15px;"><i class="fas fa-list"></i> الأعضاء الحاليون</h3>
    <div class="member-list">
        <?php foreach ($members as $member): ?>
            <div class="member-item">
                <?php
                $avatarUrl = getMemberAvatarUrl($member, 80);
                ?>
                <img src="<?php echo $avatarUrl; ?>" alt="<?php echo htmlspecialchars($member['display_name']); ?>">
                <div class="name"><?php echo htmlspecialchars($member['display_name']); ?></div>
                <div class="pos"><?php echo htmlspecialchars($member['position'] ?? 'عضو'); ?></div>
                <span class="status <?php echo $member['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                    <?php echo $member['is_active'] ? '🟢 نشط' : '🔴 غير نشط'; ?>
                </span>
                <div class="actions">
                    <a href="?edit=<?php echo $member['id']; ?>" class="btn btn-primary btn-sm" style="padding:4px 14px; font-size:13px;">
                        <i class="fas fa-pen"></i> تعديل
                    </a>
                    <form method="POST" style="display:inline;" onsubmit="return confirm('هل أنت متأكد من حذف هذا العضو؟');">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $member['id']; ?>">
                        <button type="submit" class="btn-delete" style="padding:4px 14px; font-size:13px;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (empty($members)): ?>
            <p style="color:var(--text-secondary); grid-column:span 2; text-align:center; padding:40px;">لا يوجد أعضاء مضافة بعد.</p>
        <?php endif; ?>
    </div>

</div>

<!-- ===== الفوتر ===== -->
<footer class="footer">
    <div class="footer-container">
        <div class="footer-col"><div class="footer-logo"><img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png" alt="Italiano" class="footer-logo-img"></div>
            <p class="footer-desc">عائلة Italiano، واحدة من أعرق العائلات في عالم وناسة تايم.</p>
            <div class="footer-social">
                <a href="#" class="social-link"><i class="fab fa-discord"></i></a>
                <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
        <div class="footer-col"><h4 class="footer-title">السيرفر</h4><ul class="footer-links">
                <li><a href="/Italiano/index.php?tab=store">المتجر</a></li>
                <li><a href="/Italiano/index.php?tab=applications">التقديمات</a></li>
                <li><a href="/Italiano/pages/members.php">الأعضاء</a></li>
            </ul></div>
        <div class="footer-col"><h4 class="footer-title">الدعم الفني</h4><ul class="footer-links">
                <li><a href="/Italiano/pages/rules.php?tab=rules">القوانين</a></li>
                <li><a href="https://discord.gg/BdqPsR3ATm" target="_blank">ديسكورد</a></li>
            </ul></div>
    </div>
    <div class="footer-bottom">
        <div class="footer-bottom-container">
            <span class="footer-copy">© 2026 Italiano. جميع الحقوق محفوظة.</span>
            <span class="footer-dev">تم التطوير بواسطة <strong>M_550</strong></span>
        </div>
    </div>
</footer>

</body>
</html>