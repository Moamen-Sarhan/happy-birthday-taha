<?php
require_once __DIR__ . '/../inc/functions.php';
require_once __DIR__ . '/../inc/config.php';

$sessionRoles = $_SESSION['roles'] ?? [];
$canManage = isFounder($sessionRoles);

function ensureVehicleUploadDir() {
    $dir = __DIR__ . '/uploads/vehicles/';
    if (!is_dir($dir)) {
        if (!mkdir($dir, 0755, true)) {
            return false;
        }
    }
    return true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $response = ['success' => false, 'message' => 'حدث خطأ'];

    if (!$canManage) {
        $response = ['success' => false, 'message' => 'غير مصرح'];
    } else {
        try {
            if ($action === 'add_vehicle') {
                $name = trim($_POST['name'] ?? '');
                $desc = trim($_POST['description'] ?? '');
                
                if (!ensureVehicleUploadDir()) {
                    $response = ['success' => false, 'message' => 'فشل إنشاء مجلد رفع الصور، تأكد من صلاحيات الكتابة'];
                    echo json_encode($response);
                    exit;
                }

                // 🔥 تم إضافة 800, 600 لتغيير حجم الصورة
                $uploadResult = uploadImage('image', 'vehicles', 800, 600);
                $imagePath = null;
                if ($uploadResult['success']) {
                    $imagePath = $uploadResult['path'];
                } elseif (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
                    $response = ['success' => false, 'message' => 'فشل رفع الصورة: ' . $uploadResult['message']];
                    echo json_encode($response);
                    exit;
                }
                
                if (!$name) {
                    $response = ['success' => false, 'message' => 'اكتب اسم السيارة'];
                } else {
                    $stmt = $pdo->prepare("INSERT INTO vehicles (name, description, image) VALUES (?, ?, ?)");
                    $stmt->execute([$name, $desc, $imagePath]);
                    $response = [
                        'success' => true,
                        'message' => 'تمت إضافة السيارة بنجاح',
                        'id' => $pdo->lastInsertId(),
                        'image' => $imagePath
                    ];
                }
            } elseif ($action === 'delete_vehicle') {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("DELETE FROM vehicles WHERE id = ?");
                $stmt->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        } catch (PDOException $e) {
            $response = ['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()];
        }
    }

    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

$vehicles = $pdo->query("SELECT * FROM vehicles ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>سيارات الشركة - Italiano</title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Tajawal', sans-serif; background:#020205; color:#e2e8f0; padding:20px; }
    .container { max-width:1200px; margin:0 auto; }
    .top-bar { 
        display:flex; 
        justify-content:space-between; 
        align-items:center; 
        margin-bottom:30px; 
        flex-wrap:wrap; 
        gap:10px; 
    }
    .top-bar h1 { 
        font-size:26px; 
        color: #ce2b37; 
        text-shadow: 0 0 10px rgba(206,43,55,0.3);
        font-weight: 900;
    }
    .back-link { color:#6866ff; text-decoration:none; font-weight:600; }
    .btn { padding:10px 20px; border:none; border-radius:30px; font-weight:700; cursor:pointer; font-family:inherit; }
    .btn-primary { background:#6866ff; color:white; }
    .grid { 
        display: grid; 
        grid-template-columns: 1fr; 
        gap: 0;
        max-width: 1000px; 
        margin: 0 auto;
    }
    .p-card { 
        background:#0a0a0f; 
        border:1px solid #ffffff10; 
        border-radius:18px; 
        overflow:hidden; 
        position:relative;
        border-bottom: 4px solid;
        border-image: linear-gradient(to right, #009246, #ffffff, #ce2b37) 1;
        padding-bottom: 30px;
        margin-bottom: 30px;
    }
    .p-card:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }
    .p-card img { 
        width: 100%; 
        height: auto; 
        max-height: 600px;
        object-fit: cover; 
        background: #1a1a2e; 
    }
    .p-body { padding:20px; }
    .p-body h3 { margin-bottom:6px; font-size:22px; color:white; }
    .p-body p { color:#94a3b8; font-size:15px; line-height:1.6; }
    .delete-btn { position:absolute; top:15px; left:15px; background:rgba(239,68,68,0.9); border:none; color:white; width:36px; height:36px; border-radius:50%; cursor:pointer; font-size:16px; }
    .empty { color:#94a3b8; text-align:center; padding:60px 0; }
    .modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.7); backdrop-filter:blur(8px); z-index:999; display:none; justify-content:center; align-items:center; }
    .modal-overlay.active { display:flex; }
    .modal-box { background:#0a0a0f; border:1px solid #6866ff40; border-radius:20px; padding:30px; max-width:480px; width:95%; position:relative; }
    .modal-box .close-btn { position:absolute; top:15px; left:15px; background:transparent; border:none; color:#94a3b8; font-size:24px; cursor:pointer; transition:0.3s; }
    .modal-box .close-btn:hover { color:white; transform:rotate(90deg); }
    .modal-box h2 { margin-bottom:20px; color:white; }
    .form-group { margin-bottom:16px; }
    .form-group label { display:block; font-weight:600; margin-bottom:6px; color:#e2e8f0; }
    .form-group input, .form-group textarea { width:100%; padding:10px; background:#020205; border:1px solid #ffffff15; border-radius:10px; color:white; }

    .notification {
        position: fixed;
        top: 20px;
        left: 20px;
        background: #0a0a0f;
        border: 1px solid #6866ff50;
        padding: 15px 25px;
        border-radius: 15px;
        color: white;
        z-index: 9999;
        transform: translateX(-120%);
        transition: transform 0.5s ease;
        box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        font-weight: 700;
    }
    .notification.show { transform: translateX(0); }
    .notification i { margin-left: 10px; color: #10b981; }
    .notification.error i { color: #ef4444; }
</style>
<!-- 🔥 سكربت التمرير للأعلى -->
<script>
    if ('scrollRestoration' in history) {
        history.scrollRestoration = 'manual';
    }
    window.scrollTo(0, 0);
    document.addEventListener('DOMContentLoaded', function() {
        window.scrollTo(0, 0);
    });
    window.addEventListener('load', function() {
        window.scrollTo(0, 0);
    });
</script>
</head>
<body>
<div class="container">
    <div class="notification" id="notification">
        <i class="fas fa-check-circle"></i>
        <span id="notification-text">تم التنفيذ بنجاح!</span>
    </div>

    <div class="top-bar">
        <h1><i class="fas fa-car"></i> سيارات الشركة</h1>
        <div style="display:flex; gap:10px; align-items:center;">
            <?php if ($canManage): ?>
                <button class="btn btn-primary" onclick="document.getElementById('addModal').classList.add('active')"><i class="fas fa-plus"></i> إضافة سيارة</button>
            <?php endif; ?>
            <a class="back-link" href="index.php"><i class="fas fa-arrow-right"></i> رجوع للرئيسية</a>
        </div>
    </div>

    <div class="grid" id="grid">
        <?php foreach ($vehicles as $p): ?>
        <div class="p-card" data-id="<?php echo $p['id']; ?>">
            <?php if ($canManage): ?>
                <button class="delete-btn" onclick="deleteItem(<?php echo $p['id']; ?>)"><i class="fas fa-trash"></i></button>
            <?php endif; ?>
            <!-- 🔥 تم إصلاح مسار الصورة -->
            <img src="<?php echo $p['image'] ? '/Italiano/' . htmlspecialchars($p['image']) : 'https://via.placeholder.com/1000x600/1a1a2e/6866ff?text=سيارة'; ?>" alt="">
            <div class="p-body">
                <h3><?php echo htmlspecialchars($p['name']); ?></h3>
                <p><?php echo htmlspecialchars($p['description']); ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if (empty($vehicles)): ?><div class="empty">لا يوجد سيارات مضافة حالياً.</div><?php endif; ?>
</div>

<?php if ($canManage): ?>
<div class="modal-overlay" id="addModal" onclick="closeModal(event)">
    <div class="modal-box" onclick="event.stopPropagation();">
        <button class="close-btn" onclick="closeModal()"><i class="fas fa-times"></i></button>
        <h2><i class="fas fa-plus-circle"></i> إضافة سيارة جديدة</h2>
        <form id="vehicleForm">
            <div class="form-group"><label>اسم السيارة</label><input type="text" name="name" required></div>
            <div class="form-group"><label>الوصف (اختياري)</label><textarea name="description" rows="3"></textarea></div>
            <div class="form-group"><label>الصورة</label><input type="file" name="image" accept="image/*"></div>
            <button type="submit" class="btn btn-primary" style="width:100%;"><i class="fas fa-save"></i> حفظ</button>
        </form>
    </div>
</div>
<script>
function showNotification(text, type = 'success') {
    let notif = document.getElementById('notification');
    document.getElementById('notification-text').textContent = text;
    notif.className = 'notification';
    if (type === 'error') notif.classList.add('error');
    notif.classList.add('show');
    setTimeout(() => notif.classList.remove('show'), 3000);
}

function closeModal(e) {
    if (e && e.target !== e.currentTarget) return;
    document.getElementById('addModal').classList.remove('active');
}

document.querySelector('#addModal .modal-box').addEventListener('click', function(e) {
    e.stopPropagation();
});

document.getElementById('vehicleForm').addEventListener('submit', function(e){
    e.preventDefault();
    let fd = new FormData(this);
    fd.append('action', 'add_vehicle');
    fetch(window.location.href, { method:'POST', body: fd })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showNotification('✅ ' + data.message, 'success');
            const grid = document.getElementById('grid');
            const newCard = document.createElement('div');
            newCard.className = 'p-card';
            newCard.dataset.id = data.id;
            // 🔥 تم إصلاح مسار الصورة في الكارت الجديد
            newCard.innerHTML = `
                <?php if ($canManage): ?>
                <button class="delete-btn" onclick="deleteItem(${data.id})"><i class="fas fa-trash"></i></button>
                <?php endif; ?>
                <img src="${data.image ? '/Italiano/' + data.image : 'https://via.placeholder.com/1000x600/1a1a2e/6866ff?text=سيارة'}" alt="">
                <div class="p-body">
                    <h3>${fd.get('name')}</h3>
                    <p>${fd.get('description') || ''}</p>
                </div>
            `;
            grid.appendChild(newCard);
            const empty = document.querySelector('.empty');
            if (empty) empty.remove();
            closeModal();
        } else {
            showNotification('❌ ' + data.message, 'error');
        }
    })
    .catch(() => {
        showNotification('❌ حدث خطأ في الاتصال', 'error');
    });
});

function deleteItem(id) {
    if (!confirm('تأكيد حذف السيارة؟')) return;
    fetch(window.location.href, {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:`action=delete_vehicle&id=${id}`
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showNotification('✅ ' + data.message, 'success');
            const card = document.querySelector(`.p-card[data-id="${id}"]`);
            if (card) card.remove();
            if (document.querySelectorAll('.p-card').length === 0) {
                const grid = document.getElementById('grid');
                const emptyMsg = document.createElement('div');
                emptyMsg.className = 'empty';
                emptyMsg.textContent = 'لا يوجد سيارات مضافة حالياً.';
                grid.appendChild(emptyMsg);
            }
        } else {
            showNotification('❌ ' + data.message, 'error');
        }
    })
    .catch(() => {
        showNotification('❌ حدث خطأ في الاتصال', 'error');
    });
}
</script>
<?php endif; ?>
</body>
</html>