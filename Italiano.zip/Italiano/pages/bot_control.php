<?php
require_once __DIR__ . '/../inc/functions.php';
require_once __DIR__ . '/../inc/config.php';

// التحقق من تسجيل الدخول وصلاحية الفاوندر فقط
$isLoggedIn = isLoggedIn();
$currentUser = getCurrentUser();
$userRoles = $currentUser ? ($currentUser['roles'] ?? []) : [];
$isFounder = in_array('founder', $userRoles, true);

if (!$isLoggedIn || !$isFounder) {
    header('Location: index.php');
    exit;
}

$csrfToken = generateCSRFToken();

// معالجة إرسال الإعلان
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_announcement') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'طلب غير صالح';
    } else {
        $channelId = trim($_POST['channel_id'] ?? '');
        $message = trim($_POST['message'] ?? '');
        
        if (empty($channelId) || empty($message)) {
            $error = 'يرجى ملء جميع الحقول';
        } else {
            $result = sendBotAnnouncement($pdo, $currentUser['id'], $channelId, $message);
            if ($result) {
                $success = '✅ تم إرسال الإعلان بنجاح!';
            } else {
                $error = '❌ فشل إرسال الإعلان، تأكد من تشغيل البوت.';
            }
        }
    }
}

// جلب الإعلانات السابقة
$announcements = [];
try {
    $announcements = $pdo->query("
        SELECT a.*, u.username as sender_name 
        FROM bot_announcements a
        JOIN users u ON a.sent_by = u.id
        ORDER BY a.sent_at DESC
        LIMIT 50
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log('Error fetching announcements: ' . $e->getMessage());
}

// جلب رومات الديسكورد
$channels = getDiscordChannels();

// ===== جلب الإشعارات =====
$notifications = [];
$unreadCount = 0;
if ($currentUser && $currentUser['id']) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
        $stmt->execute([$currentUser['id']]);
        $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$currentUser['id']]);
        $unreadCount = (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        $notifications = [];
        $unreadCount = 0;
    }
}

// ===== إحصائيات متقدمة للوحة التحكم =====
$stats = [
    'open_tickets' => 0,
    'pending_actions' => 0,
    'total_dms' => 0,
    'total_tickets' => 0,
    'total_announcements' => 0,
    'total_users' => 0,
    'pending_bookings' => 0
];

// التحقق من وجود الجداول قبل الاستعلام
try {
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $tableExists = function($table) use ($tables) {
        return in_array($table, $tables);
    };
    
    if ($tableExists('support_tickets')) {
        $stats['open_tickets'] = (int) $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status = 'open'")->fetchColumn();
    }
    
    if ($tableExists('bot_actions')) {
        $stats['pending_actions'] = (int) $pdo->query("SELECT COUNT(*) FROM bot_actions WHERE status = 'pending'")->fetchColumn();
        $stats['total_dms'] = (int) $pdo->query("SELECT COUNT(*) FROM bot_actions WHERE action_type = 'dm' AND status = 'sent'")->fetchColumn();
        $stats['total_tickets'] = (int) $pdo->query("SELECT COUNT(*) FROM bot_actions WHERE action_type = 'create_ticket' AND status = 'sent'")->fetchColumn();
    }
    
    if ($tableExists('bot_announcements')) {
        $stats['total_announcements'] = (int) $pdo->query("SELECT COUNT(*) FROM bot_announcements WHERE status = 'sent'")->fetchColumn();
    }
    
    if ($tableExists('users')) {
        $stats['total_users'] = (int) $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    }
    
    if ($tableExists('farm_bookings')) {
        $stats['pending_bookings'] = (int) $pdo->query("SELECT COUNT(*) FROM farm_bookings WHERE status = 'pending'")->fetchColumn();
    }
} catch (PDOException $e) {
    error_log('Error fetching stats: ' . $e->getMessage());
}

// ===== التحقق من حالة البوت =====
$botStatus = getBotStatus($pdo);
$botStatusClass = $botStatus === 'online' ? 'online' : ($botStatus === 'offline' ? 'offline' : 'unknown');
$botStatusText = $botStatus === 'online' ? 'متصل' : ($botStatus === 'offline' ? 'غير متصل' : 'غير معروف');
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم البوت - Italiano</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/Italiano/css/style.css">
    <style>
        .bot-container { max-width: 1000px; margin: 0 auto; padding: 20px; }
        .bot-card { background: #0a0a0f; border: 1px solid #ffffff10; border-radius: 20px; padding: 30px; margin-bottom: 30px; }
        .bot-card h3 { color: white; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
        .bot-card h3 i { color: #ce2b37; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 8px; color: #e2e8f0; }
        .form-group input, .form-group select, .form-group textarea { 
            width: 100%; padding: 12px; 
            background: #020205; border: 1px solid #ffffff15; border-radius: 10px; 
            color: white; font-family: inherit; 
        }
        .form-group textarea { resize: vertical; min-height: 100px; }
        .btn-success { background: #10b981; color: white; border: none; padding: 12px 24px; border-radius: 30px; font-weight: 700; cursor: pointer; transition: 0.3s; }
        .btn-success:hover { background: #059669; }
        
        .announcement-item { background: #020205; border: 1px solid #ffffff10; border-radius: 12px; padding: 15px; margin-bottom: 12px; }
        .announcement-item .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        .announcement-item .header .channel { color: #94a3b8; font-size: 14px; }
        .announcement-item .header .time { color: #94a3b8; font-size: 13px; }
        .announcement-item .message { color: #e2e8f0; margin-top: 8px; line-height: 1.6; }
        .announcement-item .status { display: inline-block; padding: 2px 12px; border-radius: 20px; font-size: 12px; }
        .status-sent { background: #10b98120; color: #10b981; border: 1px solid #10b98140; }
        .status-pending { background: #f59e0b20; color: #f59e0b; border: 1px solid #f59e0b40; }
        .status-failed { background: #ef444420; color: #ef4444; border: 1px solid #ef444440; }
        
        .alert-success { background: #10b98120; border: 1px solid #10b98140; color: #10b981; padding: 12px 20px; border-radius: 12px; margin-bottom: 20px; }
        .alert-danger { background: #ef444420; border: 1px solid #ef444440; color: #ef4444; padding: 12px 20px; border-radius: 12px; margin-bottom: 20px; }
        
        .back-link { color: #6866ff; text-decoration: none; font-weight: 600; display: inline-block; margin-bottom: 20px; }
        .back-link i { margin-left: 8px; }
        
        .bot-status { display: inline-block; padding: 4px 16px; border-radius: 30px; font-size: 14px; font-weight: 600; }
        .bot-status.online { background: #10b98120; color: #10b981; border: 1px solid #10b98140; }
        .bot-status.offline { background: #ef444420; color: #ef4444; border: 1px solid #ef444440; }
        .bot-status.unknown { background: #f59e0b20; color: #f59e0b; border: 1px solid #f59e0b40; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; margin-top: 15px; }
        .stat-box { background: #020205; border-radius: 12px; padding: 20px; text-align: center; border: 1px solid #ffffff10; }
        .stat-number { font-size: 28px; font-weight: 900; }
        .stat-label { color: #94a3b8; font-size: 14px; margin-top: 5px; }
    </style>
</head>
<body>

<!-- ===== الهيدر ===== -->
<header class="header">
    <a href="/Italiano/index.php?tab=home" class="logo" style="display:flex; align-items:center; gap:10px; text-decoration:none;">
        <img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png?ver=2" alt="ITV - Italiano">
    </a>
    <nav class="nav">
        <a href="/Italiano/pages/rules.php?tab=rules"><i class="fas fa-gavel"></i> القوانين</a>
        <a href="/Italiano/index.php?tab=store"><i class="fas fa-store"></i> المتجر</a>
        <a href="/Italiano/index.php?tab=applications"><i class="fas fa-file-signature"></i> التقديمات</a>
        <a href="/Italiano/index.php?tab=farms"><i class="fas fa-tractor"></i> المزارع</a>
    </nav>
    <div style="display:flex; align-items:center; gap:14px;">
        <?php if ($isLoggedIn && $currentUser): ?>
            <div style="display:flex; align-items:center; gap:14px;">
                <div class="notif-container">
                    <i class="fas fa-bell bell-btn" onclick="toggleNotifications()"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="bell-badge"><?php echo $unreadCount > 99 ? '99+' : $unreadCount; ?></span>
                    <?php endif; ?>
                    <div class="notif-dropdown" id="notifDropdown">
                        <div class="notif-header">
                            <span style="font-weight:700; color:white; font-size:16px;">الإشعارات</span>
                            <div style="display:flex; gap:5px;">
                                <button onclick="markAllRead()" class="btn btn-sm btn-outline" style="font-size:11px; padding:4px 14px; border-radius:20px; background:transparent; border:1px solid #ffffff20; color:#94a3b8; cursor:pointer;">
                                    تحديد الكل كمقروء
                                </button>
                                <button onclick="deleteReadNotifications()" class="btn btn-sm btn-danger" style="font-size:11px; padding:4px 14px; border-radius:20px; background:#ef4444; color:white; border:none; cursor:pointer;">
                                    <i class="fas fa-trash"></i> حذف المقروءة
                                </button>
                            </div>
                        </div>
                        <?php if (empty($notifications)): ?>
                            <div class="notif-empty"><i class="fas fa-bell-slash"></i> لا توجد إشعارات</div>
                        <?php else: ?>
                            <?php foreach ($notifications as $notif): ?>
                                <div class="notif-item <?php echo $notif['is_read'] ? '' : 'unread'; ?>" onclick="markRead(<?php echo $notif['id']; ?>)">
                                    <div style="display:flex; gap:12px; align-items:flex-start;">
                                        <div class="notif-icon">
                                            <?php if ($notif['type'] === 'delivery'): ?>
                                                <i class="fas fa-box" style="color:#10b981;"></i>
                                            <?php elseif ($notif['type'] === 'ticket'): ?>
                                                <i class="fas fa-headset" style="color:#f59e0b;"></i>
                                            <?php elseif ($notif['type'] === 'purchase'): ?>
                                                <i class="fas fa-shopping-cart" style="color:#3b82f6;"></i>
                                            <?php else: ?>
                                                <i class="fas fa-bell" style="color:#ce2b37;"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div style="flex:1;">
                                            <div class="notif-title"><?php echo htmlspecialchars($notif['title']); ?></div>
                                            <div class="notif-message"><?php echo htmlspecialchars($notif['message']); ?></div>
                                            <div class="notif-time"><i class="far fa-clock"></i> <?php echo date('Y-m-d H:i', strtotime($notif['created_at'])); ?></div>
                                            <?php if ($notif['link']): ?>
                                                <div class="notif-link"><a href="<?php echo htmlspecialchars($notif['link']); ?>" target="_blank"><i class="fas fa-external-link-alt"></i> عرض الرابط</a></div>
                                            <?php endif; ?>
                                        </div>
                                        <?php if (!$notif['is_read']): ?>
                                            <div class="notif-dot"></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                <a href="/Italiano/index.php?tab=profile" class="profile-wrapper">
                    <div class="avatar-container">
                        <?php if (!empty($currentUser['avatar']) && !empty($currentUser['discord_id'])): ?>
                            <img src="https://cdn.discordapp.com/avatars/<?php echo htmlspecialchars($currentUser['discord_id']); ?>/<?php echo htmlspecialchars($currentUser['avatar']); ?>.png?size=40" alt="Profile">
                        <?php else: ?>
                            <div class="fallback"><?php echo strtoupper(substr($currentUser['username'] ?? 'U', 0, 1)); ?></div>
                        <?php endif; ?>
                        <span class="status-dot"></span>
                    </div>
                    <span class="profile-name"><?php echo htmlspecialchars($currentUser['username'] ?? 'مستخدم'); ?></span>
                </a>
                <a href="/Italiano/index.php?tab=dashboard" class="dashboard-icon" title="لوحة التحكم"><i class="fas fa-th"></i></a>
                <a href="/Italiano/pages/bot_control.php" class="dashboard-icon" title="لوحة البوت" style="color:#ce2b37;"><i class="fas fa-robot"></i></a>
            </div>
        <?php endif; ?>
    </div>
</header>

<!-- ===== المحتوى ===== -->
<div class="bot-container">

    <a href="index.php" class="back-link"><i class="fas fa-arrow-right"></i> العودة للرئيسية</a>

    <h1 style="color:white; display:flex; align-items:center; gap:12px; margin-bottom:30px;">
        <i class="fas fa-robot" style="color:#ce2b37;"></i> 
        لوحة تحكم البوت 
        <span class="bot-status <?php echo $botStatusClass; ?>" id="botStatus">
            <i class="fas fa-circle" style="font-size:10px;"></i> <?php echo $botStatusText; ?>
        </span>
    </h1>

    <?php if (isset($success)): ?>
        <div class="alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
    <?php endif; ?>

    <!-- ===== إحصائيات متقدمة ===== -->
    <div class="bot-card">
        <h3><i class="fas fa-chart-pie"></i> إحصائيات متقدمة</h3>
        <div class="stats-grid">
            <div class="stat-box">
                <div class="stat-number" style="color:#f59e0b;"><?php echo $stats['pending_actions']; ?></div>
                <div class="stat-label">أوامر معلقة</div>
            </div>
            <div class="stat-box">
                <div class="stat-number" style="color:#10b981;"><?php echo $stats['total_dms']; ?></div>
                <div class="stat-label">رسائل خاصة مرسلة</div>
            </div>
            <div class="stat-box">
                <div class="stat-number" style="color:#3b82f6;"><?php echo $stats['total_tickets']; ?></div>
                <div class="stat-label">تذاكر مفتوحة</div>
            </div>
            <div class="stat-box">
                <div class="stat-number" style="color:#ef4444;"><?php echo $stats['open_tickets']; ?></div>
                <div class="stat-label">تذاكر قيد المعالجة</div>
            </div>
            <div class="stat-box">
                <div class="stat-number" style="color:#ce2b37;"><?php echo $stats['total_announcements']; ?></div>
                <div class="stat-label">إعلانات مرسلة</div>
            </div>
            <div class="stat-box">
                <div class="stat-number" style="color:#8b5cf6;"><?php echo $stats['total_users']; ?></div>
                <div class="stat-label">إجمالي المستخدمين</div>
            </div>
            <div class="stat-box">
                <div class="stat-number" style="color:#f59e0b;"><?php echo $stats['pending_bookings']; ?></div>
                <div class="stat-label">حجوزات معلقة</div>
            </div>
        </div>
    </div>

    <!-- ===== إرسال إعلان ===== -->
    <div class="bot-card">
        <h3><i class="fas fa-bullhorn"></i> إرسال إعلان</h3>
        <form method="POST">
            <input type="hidden" name="action" value="send_announcement">
            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
            
            <div class="form-group">
                <label>الروم (اختر الروم اللي تريد الإرسال فيه)</label>
                <select name="channel_id" required>
                    <option value="">-- اختر الروم --</option>
                    <?php if (!empty($channels) && is_array($channels)): ?>
                        <?php foreach ($channels as $channel): ?>
                            <option value="<?php echo htmlspecialchars($channel['id']); ?>">
                                #<?php echo htmlspecialchars($channel['name']); ?> (<?php echo htmlspecialchars($channel['type']); ?>)
                            </option>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <option value="">⚠️ لا توجد رومات متاحة (تأكد من تشغيل البوت)</option>
                    <?php endif; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>نص الإعلان</label>
                <textarea name="message" placeholder="اكتب الإعلان هنا... يمكنك استخدام @everyone و @here" required></textarea>
            </div>
            
            <button type="submit" class="btn-success"><i class="fas fa-paper-plane"></i> إرسال الإعلان</button>
        </form>
    </div>

    <!-- ===== الإعلانات السابقة ===== -->
    <div class="bot-card">
        <h3><i class="fas fa-history"></i> الإعلانات السابقة</h3>
        
        <?php if (empty($announcements)): ?>
            <p style="color:#94a3b8; text-align:center; padding:20px;">لا توجد إعلانات سابقة.</p>
        <?php else: ?>
            <?php foreach ($announcements as $ann): ?>
                <div class="announcement-item">
                    <div class="header">
                        <div>
                            <span class="status status-<?php echo $ann['status']; ?>">
                                <?php echo $ann['status'] === 'sent' ? '✅ تم الإرسال' : ($ann['status'] === 'pending' ? '⏳ قيد الانتظار' : '❌ فشل'); ?>
                            </span>
                            <span style="color:#94a3b8; font-size:14px; margin-right:10px;">
                                <i class="fas fa-user"></i> <?php echo htmlspecialchars($ann['sender_name']); ?>
                            </span>
                        </div>
                        <span class="time"><i class="far fa-clock"></i> <?php echo date('Y-m-d H:i', strtotime($ann['sent_at'])); ?></span>
                    </div>
                    <div class="message"><?php echo nl2br(htmlspecialchars($ann['message'])); ?></div>
                    <div style="margin-top:8px; color:#94a3b8; font-size:13px;">
                        <i class="fas fa-hashtag"></i> الروم: <?php echo htmlspecialchars($ann['channel_id']); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- ===== الفوتر ===== -->
<footer class="footer">
    <div class="footer-container">
        <div class="footer-col"><div class="footer-logo"><img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png" alt="Italiano" class="footer-logo-img"></div>
            <p class="footer-desc">عائلة Italiano، واحدة من أعرق العائلات في عالم وناسة تايم.</p>
            <div class="footer-social">
                <a href="#" class="social-link"><i class="fab fa-discord"></i></a>
                <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
        <div class="footer-col"><h4 class="footer-title">السيرفر</h4><ul class="footer-links">
                <li><a href="/Italiano/index.php?tab=store">المتجر</a></li>
                <li><a href="/Italiano/index.php?tab=applications">التقديمات</a></li>
                <li><a href="/Italiano/index.php?tab=farms">المزارع</a></li>
            </ul></div>
        <div class="footer-col"><h4 class="footer-title">الدعم الفني</h4><ul class="footer-links">
                <li><a href="/Italiano/pages/rules.php?tab=rules">القوانين</a></li>
                <li><a href="https://discord.gg/BdqPsR3ATm" target="_blank">ديسكورد</a></li>
            </ul></div>
    </div>
    <div class="footer-bottom">
        <div class="footer-bottom-container">
            <span class="footer-copy">© 2026 Italiano. جميع الحقوق محفوظة.</span>
            <span class="footer-dev">تم التطوير بواسطة <strong>M_550</strong></span>
        </div>
    </div>
</footer>

<script>
function toggleNotifications() {
    let dropdown = document.getElementById('notifDropdown');
    if (dropdown) dropdown.classList.toggle('show');
}
function markRead(id) {
    let fd = new FormData();
    fd.append('action', 'mark_notification_read');
    fd.append('notification_id', id);
    fd.append('csrf_token', '<?php echo $csrfToken; ?>');
    fetch('/Italiano/api/api.php', { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            let items = document.querySelectorAll('.notif-item');
            items.forEach(item => { let dot = item.querySelector('.notif-dot'); if (dot) dot.remove(); item.classList.remove('unread'); });
            let badge = document.querySelector('.bell-badge');
            if (badge) {
                let count = parseInt(badge.textContent) - 1;
                if (count > 0) { badge.textContent = count > 99 ? '99+' : count; } else { badge.remove(); }
            }
        }
    });
}
function markAllRead() {
    let fd = new FormData();
    fd.append('action', 'mark_notification_read');
    fd.append('notification_id', 0);
    fd.append('csrf_token', '<?php echo $csrfToken; ?>');
    fetch('/Italiano/api/api.php', { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            let items = document.querySelectorAll('.notif-item');
            items.forEach(item => { let dot = item.querySelector('.notif-dot'); if (dot) dot.remove(); item.classList.remove('unread'); });
            let badge = document.querySelector('.bell-badge');
            if (badge) badge.remove();
        }
    });
}
document.addEventListener('click', function(event) {
    let container = document.querySelector('.notif-container');
    let dropdown = document.getElementById('notifDropdown');
    if (container && dropdown && !container.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});

function deleteReadNotifications() {
    if (!confirm('هل أنت متأكد من حذف جميع الإشعارات المقروءة؟')) return;
    let fd = new FormData();
    fd.append('action', 'delete_read_notifications');
    fd.append('csrf_token', '<?php echo $csrfToken; ?>');
    fetch('/Italiano/api/api.php', { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            let items = document.querySelectorAll('.notif-item');
            items.forEach(item => {
                let dot = item.querySelector('.notif-dot');
                if (!dot) {
                    item.remove();
                }
            });
            alert('✅ ' + data.message);
        } else {
            alert('❌ ' + data.message);
        }
    });
}
</script>
</body>
</html>