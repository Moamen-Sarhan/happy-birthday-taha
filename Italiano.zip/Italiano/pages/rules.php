<?php
require_once __DIR__ . '/../inc/functions.php';
require_once __DIR__ . '/../inc/config.php';

$isLoggedIn = isLoggedIn();
$currentUser = getCurrentUser();

// ===== جلب رتب المستخدم للتحقق من صلاحية لوحة التحكم =====
$userRoles = [];
if ($currentUser && $currentUser['id']) {
    $userRoles = getUserRolesFromDB($currentUser['id'], $pdo);
}
$canAccessDashboard = false;
if ($currentUser && !empty($userRoles)) {
    $canAccessDashboard = !in_array('member', $userRoles) || in_array('founder', $userRoles);
}

// ===== جلب الإشعارات =====
$notifications = [];
$unreadCount = 0;
if ($currentUser && $currentUser['id']) {
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM notifications 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT 50
        ");
        $stmt->execute([$currentUser['id']]);
        $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$currentUser['id']]);
        $unreadCount = (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        $notifications = [];
        $unreadCount = 0;
    }
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>القوانين - Italiano</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/Italiano/css/style.css">
    <style>
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .rules-hero {
            background: linear-gradient(135deg, #0a0a0f, #1a1a2e);
            border-radius: 24px;
            padding: 50px;
            margin: 30px 0;
            border: 1px solid rgba(206,43,55,0.2);
            position: relative;
            overflow: hidden;
            text-align: center;
        }
        .rules-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            display: flex;
            background: linear-gradient(90deg, #009246, #ffffff, #ce2b37);
        }
        .rules-hero h1 { font-size: 42px; font-weight: 900; margin-bottom: 10px; }
        .rules-hero h1 span { 
            background: linear-gradient(90deg, #009246, #ffffff, #ce2b37);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }
        .rules-hero p { color: #94a3b8; font-size: 18px; max-width: 700px; margin: 0 auto; }
        .rules-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin: 30px 0;
        }
        .rules-card {
            background: #0a0a0f;
            border: 1px solid #ffffff10;
            border-radius: 20px;
            padding: 30px;
            transition: 0.3s;
        }
        .rules-card:hover { border-color: #ce2b3740; transform: translateY(-3px); }
        .rules-card .card-icon { font-size: 32px; color: #ce2b37; margin-bottom: 15px; }
        .rules-card h3 { font-size: 20px; margin-bottom: 20px; color: white; }
        .rules-card ul { list-style: none; padding: 0; }
        .rules-card ul li {
            padding: 12px 0;
            border-bottom: 1px solid #ffffff05;
            display: flex;
            gap: 15px;
            align-items: flex-start;
            color: #94a3b8;
            line-height: 1.6;
        }
        .rules-card ul li:last-child { border-bottom: none; }
        .rules-card ul li .num { color: #ce2b37; font-weight: 700; min-width: 28px; font-size: 14px; }
        .rules-card ul li .text strong { color: white; }
        .rules-card.penalties { border-color: #ef444430; }
        .rules-card.penalties .card-icon { color: #ef4444; }
    </style>
</head>
<body>

<!-- ===== الهيدر الموحد ===== -->
<header class="header">
    <a href="/Italiano/index.php?tab=home" class="logo" style="display:flex; align-items:center; gap:10px; text-decoration:none;">
        <img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png?ver=2" alt="ITV - Italiano">
    </a>

    <nav class="nav">
        <a href="/Italiano/pages/rules.php?tab=rules" class="active"><i class="fas fa-gavel"></i> القوانين</a>
        <a href="/Italiano/index.php?tab=store"><i class="fas fa-store"></i> المتجر</a>
        <a href="/Italiano/index.php?tab=applications"><i class="fas fa-file-signature"></i> التقديمات</a>
        <a href="/Italiano/index.php?tab=farms" :class="{active: activeTab === 'farms'}"><i class="fas fa-tractor"></i> المزارع</a>
        <a href="/Italiano/pages/members.php"><i class="fas fa-users"></i> الأعضاء</a>
    </nav>

    <div style="display:flex; align-items:center; gap:14px;">
        <?php if ($isLoggedIn && $currentUser): ?>
            <div style="display:flex; align-items:center; gap:14px;">
                <div class="notif-container">
                    <i class="fas fa-bell bell-btn" onclick="toggleNotifications()"></i>
                    <?php if ($unreadCount > 0): ?>
                        <span class="bell-badge"><?php echo $unreadCount > 99 ? '99+' : $unreadCount; ?></span>
                    <?php endif; ?>
                    <div class="notif-dropdown" id="notifDropdown">
                        <div class="notif-header">
                            <span style="font-weight:700; color:white; font-size:16px;">الإشعارات</span>
                            <div style="display:flex; gap:5px;">
                                <button onclick="markAllRead()" class="btn btn-sm btn-outline" style="font-size:11px; padding:4px 14px; border-radius:20px; background:transparent; border:1px solid #ffffff20; color:#94a3b8; cursor:pointer;">
                                    تحديد الكل كمقروء
                                </button>
                                <button onclick="deleteReadNotifications()" class="btn btn-sm btn-danger" style="font-size:11px; padding:4px 14px; border-radius:20px; background:#ef4444; color:white; border:none; cursor:pointer;">
                                    <i class="fas fa-trash"></i> حذف المقروءة
                                </button>
                            </div>
                        </div>
                        <?php if (empty($notifications)): ?>
                            <div class="notif-empty"><i class="fas fa-bell-slash"></i> لا توجد إشعارات</div>
                        <?php else: ?>
                            <?php foreach ($notifications as $notif): ?>
                                <div class="notif-item <?php echo $notif['is_read'] ? '' : 'unread'; ?>" onclick="markRead(<?php echo $notif['id']; ?>)">
                                    <div style="display:flex; gap:12px; align-items:flex-start;">
                                        <div class="notif-icon">
                                            <?php if ($notif['type'] === 'delivery'): ?>
                                                <i class="fas fa-box" style="color:#10b981;"></i>
                                            <?php elseif ($notif['type'] === 'ticket'): ?>
                                                <i class="fas fa-headset" style="color:#f59e0b;"></i>
                                            <?php elseif ($notif['type'] === 'purchase'): ?>
                                                <i class="fas fa-shopping-cart" style="color:#3b82f6;"></i>
                                            <?php else: ?>
                                                <i class="fas fa-bell" style="color:#ce2b37;"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div style="flex:1;">
                                            <div class="notif-title"><?php echo htmlspecialchars($notif['title']); ?></div>
                                            <div class="notif-message"><?php echo htmlspecialchars($notif['message']); ?></div>
                                            <div class="notif-time"><i class="far fa-clock"></i> <?php echo date('Y-m-d H:i', strtotime($notif['created_at'])); ?></div>
                                            <?php if ($notif['link']): ?>
                                                <div class="notif-link"><a href="<?php echo htmlspecialchars($notif['link']); ?>" target="_blank"><i class="fas fa-external-link-alt"></i> عرض الرابط</a></div>
                                            <?php endif; ?>
                                        </div>
                                        <?php if (!$notif['is_read']): ?>
                                            <div class="notif-dot"></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <a href="/Italiano/index.php?tab=profile" class="profile-wrapper">
                    <div class="avatar-container">
                        <?php if (!empty($currentUser['avatar']) && !empty($currentUser['discord_id'])): ?>
                            <img src="https://cdn.discordapp.com/avatars/<?php echo htmlspecialchars($currentUser['discord_id']); ?>/<?php echo htmlspecialchars($currentUser['avatar']); ?>.png?size=40" alt="Profile">
                        <?php else: ?>
                            <div class="fallback"><?php echo strtoupper(substr($currentUser['username'] ?? 'U', 0, 1)); ?></div>
                        <?php endif; ?>
                        <span class="status-dot"></span>
                    </div>
                    <span class="profile-name"><?php echo htmlspecialchars($currentUser['username'] ?? 'مستخدم'); ?></span>
                </a>

                <?php if ($canAccessDashboard): ?>
                    <a href="/Italiano/index.php?tab=dashboard" class="dashboard-icon" title="لوحة التحكم"><i class="fas fa-th"></i></a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <a href="/Italiano/auth/discord.php" class="btn btn-discord"><i class="fab fa-discord"></i> دخول عبر ديسكورد</a>
        <?php endif; ?>
    </div>
</header>

<!-- ===== هيرو بانر ===== -->
<div class="hero-section" style="background-image: url('/Italiano/uploads/slider/slider_6a679ba8052f38.30631397.png');">
    <div class="hero-overlay"></div>
    <div class="container hero-content">
        <h1>⚖️ قوانين <span>Italiano</span></h1>
        <p>يرجى قراءة القوانين بعناية والالتزام بها للحفاظ على بيئة ممتعة للجميع.</p>
        <p style="font-size:14px; color:#64748b; margin-top:10px;">آخر تحديث: <?php echo date('d/m/Y'); ?></p>
    </div>
</div>

<!-- ===== المحتوى ===== -->
<div class="container">
    <div class="rules-grid">
        <div class="rules-card">
            <div class="card-icon"><i class="fas fa-users"></i></div>
            <h3>القوانين العامة</h3>
            <ul>
                <li><span class="num">1</span><span class="text"><strong>الاحترام المتبادل</strong> - يجب على جميع الأعضاء التعامل مع بعضهم البعض باحترام وأدب.</span></li>
                <li><span class="num">2</span><span class="text"><strong>اللغة المناسبة</strong> - يمنع استخدام الألفاظ النابية أو المسيئة في المحادثات.</span></li>
                <li><span class="num">3</span><span class="text"><strong>عدم الغش</strong> - يمنع استخدام أي برامج أو طرق غير قانونية في الألعاب أو المسابقات.</span></li>
                <li><span class="num">4</span><span class="text"><strong>الالتزام بالتعليمات</strong> - يجب اتباع تعليمات المشرفين والإداريين في جميع الأوقات.</span></li>
            </ul>
        </div>

        <div class="rules-card">
            <div class="card-icon"><i class="fas fa-gamepad"></i></div>
            <h3>قوانين الألعاب والمسابقات</h3>
            <ul>
                <li><span class="num">1</span><span class="text"><strong>اللاعب الواحد</strong> - يمنع استخدام أكثر من حساب في أي مسابقة أو لعبة.</span></li>
                <li><span class="num">2</span><span class="text"><strong>الروح الرياضية</strong> - يجب قبول نتائج المسابقات بروح رياضية وعدم الاعتراض بشكل غير لائق.</span></li>
                <li><span class="num">3</span><span class="text"><strong>المواعيد النهائية</strong> - يجب الالتزام بالمواعيد النهائية للتسجيل والمشاركة في المسابقات.</span></li>
            </ul>
        </div>

        <div class="rules-card">
            <div class="card-icon"><i class="fas fa-store"></i></div>
            <h3>قوانين المتجر والمشتريات</h3>
            <ul>
                <li><span class="num">1</span><span class="text"><strong>الدفع المسبق</strong> - يتم الدفع مسبقاً عند شراء أي منتج من المتجر.</span></li>
                <li><span class="num">2</span><span class="text"><strong>سياسة الاسترجاع</strong> - لا يمكن استرجاع المنتجات بعد شرائها إلا في حالات عطل فني.</span></li>
                <li><span class="num">3</span><span class="text"><strong>وقت التسليم</strong> - يتم تسليم المنتجات خلال 24-48 ساعة من وقت الدفع.</span></li>
            </ul>
        </div>

        <div class="rules-card penalties">
            <div class="card-icon"><i class="fas fa-gavel"></i></div>
            <h3>عقوبات المخالفات</h3>
            <ul>
                <li><span class="num">1</span><span class="text"><strong>الإنذار الأول</strong> - تنبيه كتابي للمخالف.</span></li>
                <li><span class="num">2</span><span class="text"><strong>الإنذار الثاني</strong> - منع من المشاركة في الفعاليات لمدة أسبوع.</span></li>
                <li><span class="num">3</span><span class="text"><strong>الإنذار الثالث</strong> - حظر نهائي من المجتمع.</span></li>
            </ul>
        </div>
    </div>
</div>

<!-- ===== الفوتر ===== -->
<footer class="footer">
    <div class="footer-container">
        <div class="footer-col">
            <div class="footer-logo"><img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png" alt="Italiano" class="footer-logo-img"></div>
            <p class="footer-desc">عائلة Italiano، واحدة من أعرق العائلات في عالم وناسة تايم. نقدم تجربة فريدة تجمع بين المتعة والإبداع.</p>
            <div class="footer-social">
                <a href="https://discord.gg/BdqPsR3ATm" target="_blank" class="social-link"><i class="fab fa-discord"></i></a>
                <a href="https://www.youtube.com/@ITaliaNo.wnashtime" target="_blank" class="social-link"><i class="fab fa-youtube"></i></a>

            </div>
        </div>
        <div class="footer-col">
            <h4 class="footer-title">السيرفر</h4>
            <ul class="footer-links">
                <li><a href="/Italiano/index.php?tab=store">المتجر</a></li>
                <li><a href="/Italiano/index.php?tab=applications">التقديمات</a></li>
                <li><a href="/Italiano/index.php?tab=farms">المزارع</a></li>
                <li><a href="/Italiano/pages/members.php">الأعضاء</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4 class="footer-title">الدعم الفني</h4>
            <ul class="footer-links">
                <li><a href="/Italiano/pages/rules.php?tab=rules">القوانين</a></li>
                <li><a href="https://discord.gg/BdqPsR3ATm" target="_blank">ديسكورد</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="footer-bottom-container">
            <span class="footer-copy">© 2026 Italiano. جميع الحقوق محفوظة.</span>
            <span class="footer-dev">تم التطوير بواسطة <strong>M_550</strong></span>
        </div>
    </div>
</footer>

<script>
function toggleNotifications() {
    let dropdown = document.getElementById('notifDropdown');
    if (dropdown) dropdown.classList.toggle('show');
}

function markRead(id) {
    let fd = new FormData();
    fd.append('action', 'mark_notification_read');
    fd.append('notification_id', id);
    fd.append('csrf_token', '<?php echo $csrfToken; ?>');
    fetch('/Italiano/api/api.php', { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            let items = document.querySelectorAll('.notif-item');
            items.forEach(item => { let dot = item.querySelector('.notif-dot'); if (dot) dot.remove(); item.classList.remove('unread'); });
            let badge = document.querySelector('.bell-badge');
            if (badge) {
                let count = parseInt(badge.textContent) - 1;
                if (count > 0) { badge.textContent = count > 99 ? '99+' : count; } else { badge.remove(); }
            }
        }
    })
    .catch(() => {});
}

function markAllRead() {
    let fd = new FormData();
    fd.append('action', 'mark_notification_read');
    fd.append('notification_id', 0);
    fd.append('csrf_token', '<?php echo $csrfToken; ?>');
    fetch('/Italiano/api/api.php', { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            let items = document.querySelectorAll('.notif-item');
            items.forEach(item => { let dot = item.querySelector('.notif-dot'); if (dot) dot.remove(); item.classList.remove('unread'); });
            let badge = document.querySelector('.bell-badge');
            if (badge) badge.remove();
        }
    })
    .catch(() => {});
}

document.addEventListener('click', function(event) {
    let container = document.querySelector('.notif-container');
    let dropdown = document.getElementById('notifDropdown');
    if (container && dropdown && !container.contains(event.target)) {
        dropdown.classList.remove('show');
    }
});

function deleteReadNotifications() {
    if (!confirm('هل أنت متأكد من حذف جميع الإشعارات المقروءة؟')) return;
    let fd = new FormData();
    fd.append('action', 'delete_read_notifications');
    fd.append('csrf_token', '<?php echo $csrfToken; ?>');
    fetch('/Italiano/api/api.php', { method: 'POST', body: fd })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            let items = document.querySelectorAll('.notif-item');
            items.forEach(item => {
                let dot = item.querySelector('.notif-dot');
                if (!dot) {
                    item.remove();
                }
            });
            alert('✅ ' + data.message);
        } else {
            alert('❌ ' + data.message);
        }
    });
}
</script>
</body>
</html>