<?php
// ====== تمكين عرض الأخطاء ======
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../error.log');

// ====== تضمين الدوال والاتصال بقاعدة البيانات ======
require_once __DIR__ . '/../inc/functions.php';
require_once __DIR__ . '/../inc/config.php';
generateCSRFToken();

// ====== التحقق من وجود معرف التقديم ======
$appId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($appId <= 0) {
    die('❌ معرف التقديم غير صحيح');
}

// ====== جلب بيانات نوع التقديم ======
$app = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM application_types WHERE id = ?");
    $stmt->execute([$appId]);
    $app = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب بيانات التقديم: ' . $e->getMessage());
}

// ====== التحقق من وجود التقديم ======
if (!$app) {
    die('❌ نوع التقديم غير موجود');
}

// ====== التحقق من أن التقديم مفتوح ======
if (!$app['is_open']) {
    die('❌ هذا التقديم مغلق حالياً');
}

// ====== جلب الأسئلة الخاصة بهذا التقديم ======
$questions = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM application_questions WHERE type_id = ? ORDER BY id");
    $stmt->execute([$appId]);
    $questions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب الأسئلة: ' . $e->getMessage());
}

// ====== التحقق من تسجيل الدخول ======
if (!isLoggedIn()) {
    header('Location: /Italiano/auth/discord.php');
    exit;
}

$currentUser = getCurrentUser();
$userRoles = $currentUser['roles'] ?? [];

// ====== معالجة تقديم الطلب ======
$submitted = false;
$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // التحقق من CSRF
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!verifyCSRFToken($csrf_token)) {
        $error = 'طلب غير صالح (CSRF)';
    } else {
        // تجميع الإجابات
        $answers = [];
        $uploadErrors = [];
        
        foreach ($questions as $q) {
            $qid = $q['id'];
            $fieldType = $q['field_type'] ?? 'text';
            
            if ($fieldType === 'file') {
                // معالجة رفع الملف
                if (isset($_FILES['answer_' . $qid]) && $_FILES['answer_' . $qid]['error'] !== UPLOAD_ERR_NO_FILE) {
                    $uploadResult = uploadImage('answer_' . $qid, 'applications');
                    if ($uploadResult['success']) {
                        $answers[$qid] = $uploadResult['path'];
                    } else {
                        $uploadErrors[] = 'فشل رفع الملف للسؤال "' . $q['question_text'] . '": ' . $uploadResult['message'];
                    }
                } elseif ($q['required'] == 1) {
                    $uploadErrors[] = 'السؤال "' . $q['question_text'] . '" مطلوب. يرجى رفع ملف.';
                } else {
                    $answers[$qid] = null;
                }
            } else {
                // معالجة الحقول النصية
                $value = trim($_POST['answer_' . $qid] ?? '');
                if ($q['required'] == 1 && empty($value)) {
                    $uploadErrors[] = 'السؤال "' . $q['question_text'] . '" مطلوب.';
                }
                $answers[$qid] = $value;
            }
        }
        
        if (!empty($uploadErrors)) {
            $error = implode('<br>', $uploadErrors);
        } else {
            try {
                // إدراج التقديم في قاعدة البيانات
                $stmt = $pdo->prepare("
                    INSERT INTO submissions (user_id, type_id, answers, status) 
                    VALUES (?, ?, ?, 'pending')
                ");
                $stmt->execute([$currentUser['id'], $appId, json_encode($answers, JSON_UNESCAPED_UNICODE)]);
                $submissionId = $pdo->lastInsertId();
                
                // إشعار للمسؤولين
                $adminStmt = $pdo->query("
                    SELECT DISTINCT u.id 
                    FROM users u
                    JOIN user_roles ur ON u.id = ur.user_id
                    JOIN roles r ON ur.role_id = r.id
                    WHERE r.role_key IN ('founder', 'admin', 'company_apps_manager', 'farm_rental_manager', 'housing_apps_manager')
                ");
                $admins = $adminStmt->fetchAll(PDO::FETCH_COLUMN);
                
                foreach ($admins as $adminId) {
                    addNotification(
                        $pdo,
                        $adminId,
                        'submission',
                        '📝 تقديم جديد',
                        'قام المستخدم ' . $currentUser['username'] . ' بتقديم طلب "' . $app['name'] . '"',
                        '/Italiano/index.php?tab=dashboard&section=submissions'
                    );
                }
                
                // إشعار للمستخدم
                addNotification(
                    $pdo,
                    $currentUser['id'],
                    'submission',
                    '✅ تم إرسال طلبك!',
                    'تم إرسال تقديمك "' . $app['name'] . '" بنجاح، في انتظار المراجعة.'
                );
                
                sendBotDM(
                    $pdo,
                    $currentUser['id'],
                    '✅ تم إرسال طلبك!',
                    'تم إرسال تقديمك "' . $app['name'] . '" بنجاح، في انتظار المراجعة.'
                );
                
                $submitted = true;
                $success = true;
            } catch (PDOException $e) {
                $error = 'حدث خطأ في قاعدة البيانات: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($app['name']); ?> - Italiano</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/Italiano/css/style.css">
</head>
<body>
<div id="app">

    <div class="notification" id="notification">
        <i class="fas fa-check-circle"></i>
        <span id="notification-text">تم التنفيذ بنجاح!</span>
    </div>

    <!-- ===== الهيدر ===== -->
    <header class="header">
        <a href="/Italiano/index.php?tab=home" class="logo" style="display:flex; align-items:center; gap:10px; text-decoration:none;">
            <img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png?ver=2" alt="ITV - Italiano">
        </a>

        <nav class="nav">
            <a href="/Italiano/pages/rules.php?tab=rules"><i class="fas fa-gavel"></i> القوانين</a>
            <a href="/Italiano/index.php?tab=store"><i class="fas fa-store"></i> المتجر</a>
            <a href="/Italiano/index.php?tab=applications"><i class="fas fa-file-signature"></i> التقديمات</a>
            <a href="/Italiano/index.php?tab=giveaways"><i class="fas fa-gift"></i> الجيفاواي</a>
            <a href="/Italiano/index.php?tab=farms"><i class="fas fa-tractor"></i> المزارع</a>
        </nav>

        <div style="display:flex; align-items:center; gap:14px;">
            <?php if (isLoggedIn()): ?>
                <a href="/Italiano/index.php?tab=profile" class="profile-wrapper">
                    <div class="avatar-container">
                        <?php if ($currentUser && $currentUser['discord_id']): ?>
                            <img src="https://cdn.discordapp.com/avatars/<?php echo $currentUser['discord_id']; ?>/<?php echo $currentUser['avatar'] ?? ''; ?>.png?size=40" alt="Profile">
                        <?php else: ?>
                            <div class="fallback"><?php echo $currentUser ? $currentUser['username'][0] : 'U'; ?></div>
                        <?php endif; ?>
                        <span class="status-dot"></span>
                    </div>
                    <span class="profile-name"><?php echo htmlspecialchars($currentUser['username'] ?? 'مستخدم'); ?></span>
                </a>
                <a href="/Italiano/index.php?tab=dashboard" class="dashboard-icon" title="لوحة التحكم">
                    <i class="fas fa-th"></i>
                </a>
            <?php else: ?>
                <a href="/Italiano/auth/discord.php" class="btn btn-discord">
                    <i class="fab fa-discord"></i> دخول عبر ديسكورد
                </a>
            <?php endif; ?>
        </div>
    </header>

    <!-- ===== المحتوى ===== -->
    <div class="container" style="max-width: 800px; margin: 40px auto; padding: 20px;">

        <div class="card" style="padding: 40px;">
            <h2 style="text-align: center; margin-bottom: 10px;">
                <i class="fas fa-file-signature" style="color: var(--accent);"></i>
                <?php echo htmlspecialchars($app['name']); ?>
            </h2>
            
            <?php if (!empty($app['description'])): ?>
                <p style="text-align: center; color: var(--text-secondary); margin-bottom: 20px;">
                    <?php echo htmlspecialchars($app['description']); ?>
                </p>
            <?php endif; ?>

            <!-- ===== عرض الشروط فقط (بدون تحذير) ===== -->
            <div style="background: var(--bg-input); padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                <p><strong>الحالة:</strong> 
                    <span class="badge <?php echo $app['is_open'] ? 'badge-open' : 'badge-closed'; ?>">
                        <?php echo $app['is_open'] ? '✅ مفتوح' : '❌ مغلق'; ?>
                    </span>
                </p>
                <?php if ($app['min_hours'] > 0): ?>
                    <p><strong>الحد الأدنى لساعات اللعب:</strong> <?php echo $app['min_hours']; ?> ساعة</p>
                <?php endif; ?>
                <?php if ($app['min_history'] > 0): ?>
                    <p><strong>الحد الأدنى للهيستوري:</strong> <?php echo $app['min_history']; ?> يوم</p>
                <?php endif; ?>
                <?php if ($app['min_money'] > 0): ?>
                    <p><strong>الحد الأدنى للفل:</strong> $<?php echo $app['min_money']; ?></p>
                <?php endif; ?>
                <?php if (!empty($app['requirements'])): ?>
                    <p><strong>المتطلبات الإضافية:</strong><br><?php echo nl2br(htmlspecialchars($app['requirements'])); ?></p>
                <?php endif; ?>
            </div>

            <?php if ($submitted && $success): ?>
                <div style="background: #10b98120; border: 1px solid #10b98140; border-radius: 10px; padding: 30px; text-align: center; margin-bottom: 20px;">
                    <i class="fas fa-check-circle" style="font-size: 48px; color: #10b981; margin-bottom: 15px;"></i>
                    <h3 style="color: #10b981;">✅ تم إرسال طلبك بنجاح!</h3>
                    <p style="color: var(--text-secondary);">سيتم مراجعة طلبك من قبل الإدارة، وسيتم إشعارك عند البت فيه.</p>
                    <a href="/Italiano/index.php?tab=applications" class="btn btn-primary" style="margin-top: 15px;">
                        <i class="fas fa-arrow-right"></i> العودة للتقديمات
                    </a>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div style="background: #ef444420; border: 1px solid #ef444440; border-radius: 10px; padding: 15px; margin-bottom: 20px; color: #ef4444;">
                    <i class="fas fa-times-circle"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- ===== نموذج التقديم ===== -->
            <?php if ($app['is_open'] && !$submitted): ?>
                <form method="POST" enctype="multipart/form-data" style="margin-top: 20px;">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    
                    <?php foreach ($questions as $index => $q): ?>
                        <div class="question-group" style="margin-bottom: 20px;">
                            <label>
                                <?php echo htmlspecialchars($q['question_text']); ?>
                                <?php if ($q['required'] == 1): ?>
                                    <span style="color: #ef4444;">*</span>
                                <?php endif; ?>
                            </label>
                            
                            <?php
                            $fieldType = $q['field_type'] ?? 'text';
                            $fieldName = 'answer_' . $q['id'];
                            ?>
                            
                            <?php if ($fieldType === 'textarea'): ?>
                                <textarea name="<?php echo $fieldName; ?>" rows="4" placeholder="أكتب إجابتك هنا..." <?php echo $q['required'] == 1 ? 'required' : ''; ?>></textarea>
                            
                            <?php elseif ($fieldType === 'file'): ?>
                                <input type="file" name="<?php echo $fieldName; ?>" accept="image/*" <?php echo $q['required'] == 1 ? 'required' : ''; ?>>
                            
                            <?php elseif ($fieldType === 'select'): ?>
                                <?php $options = json_decode($q['options'] ?? '[]', true); ?>
                                <?php if (is_array($options) && !empty($options)): ?>
                                    <select name="<?php echo $fieldName; ?>" <?php echo $q['required'] == 1 ? 'required' : ''; ?>>
                                        <option value="">اختر...</option>
                                        <?php foreach ($options as $opt): ?>
                                            <option value="<?php echo htmlspecialchars($opt); ?>"><?php echo htmlspecialchars($opt); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php else: ?>
                                    <input type="text" name="<?php echo $fieldName; ?>" placeholder="أكتب إجابتك هنا..." <?php echo $q['required'] == 1 ? 'required' : ''; ?>>
                                <?php endif; ?>
                            
                            <?php elseif ($fieldType === 'number'): ?>
                                <input type="number" name="<?php echo $fieldName; ?>" placeholder="أدخل رقم..." <?php echo $q['required'] == 1 ? 'required' : ''; ?>>
                            
                            <?php elseif ($fieldType === 'url'): ?>
                                <input type="url" name="<?php echo $fieldName; ?>" placeholder="https://example.com" <?php echo $q['required'] == 1 ? 'required' : ''; ?>>
                            
                            <?php else: ?>
                                <input type="text" name="<?php echo $fieldName; ?>" placeholder="أكتب إجابتك هنا..." <?php echo $q['required'] == 1 ? 'required' : ''; ?>>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    
                    <button type="submit" class="btn btn-success" style="width: 100%; padding: 14px; font-size: 18px;">
                        <i class="fas fa-paper-plane"></i> إرسال التقديم
                    </button>
                </form>
            <?php elseif (!$app['is_open'] && !$submitted): ?>
                <div style="background: #ef444420; border: 1px solid #ef444440; border-radius: 10px; padding: 20px; text-align: center;">
                    <i class="fas fa-times-circle" style="font-size: 36px; color: #ef4444; margin-bottom: 10px;"></i>
                    <h4>هذا التقديم مغلق حالياً</h4>
                    <p style="color: var(--text-secondary);">سيتم فتح التقديم في وقت لاحق.</p>
                    <a href="/Italiano/index.php?tab=applications" class="btn btn-outline" style="margin-top: 10px;">
                        <i class="fas fa-arrow-right"></i> العودة للتقديمات
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ===== الفوتر ===== -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-col">
                <div class="footer-logo">
                    <img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png" alt="Italiano" class="footer-logo-img">
                </div>
                <p class="footer-desc">
                    عائلة Italiano، واحدة من أعرق العائلات في عالم وناسة تايم. نقدم تجربة فريدة تجمع بين المتعة والإبداع.
                </p>
                <div class="footer-social">
                    <a href="https://discord.gg/BdqPsR3ATm" target="_blank" class="social-link"><i class="fab fa-discord"></i></a>
                    <a href="https://www.youtube.com/@Italiano" target="_blank" class="social-link"><i class="fab fa-youtube"></i></a>
                </div>
            </div>

            <div class="footer-col">
                <h4 class="footer-title">السيرفر</h4>
                <ul class="footer-links">
                    <li><a href="/Italiano/index.php?tab=store">المتجر</a></li>
                    <li><a href="/Italiano/index.php?tab=applications">التقديمات</a></li>
                    <li><a href="/Italiano/index.php?tab=giveaways">الجيفاواي</a></li>
                    <li><a href="/Italiano/index.php?tab=farms">المزارع</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4 class="footer-title">الدعم الفني</h4>
                <ul class="footer-links">
                    <li><a href="/Italiano/pages/rules.php?tab=rules">القوانين</a></li>
                    <li><a href="https://discord.gg/BdqPsR3ATm" target="_blank">ديسكورد</a></li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="footer-bottom-container">
                <span class="footer-copy">© 2026 Italiano. جميع الحقوق محفوظة.</span>
                <span class="footer-dev">تم التطوير بواسطة <strong>M_550</strong></span>
            </div>
        </div>
    </footer>

</div>

<script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
<script>
// ====== عرض الإشعارات ======
function showNotification(text) {
    let notif = document.getElementById('notification');
    document.getElementById('notification-text').textContent = text;
    notif.classList.add('show');
    setTimeout(() => notif.classList.remove('show'), 3000);
}
</script>
</body>
</html>