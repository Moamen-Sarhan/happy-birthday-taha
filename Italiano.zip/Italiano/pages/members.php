<?php
require_once __DIR__ . '/../inc/functions.php';
require_once __DIR__ . '/../inc/config.php';
generateCSRFToken();

$isLoggedIn = isLoggedIn();
$currentUser = getCurrentUser();

// جلب جميع الأعضاء النشطين
$members = getAllMembers($pdo, true);

$pageTitle = 'أعضاء العائلة - Italiano';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>أعضاء العائلة - Italiano</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/Italiano/css/style.css">
    <style>
        .members-container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .members-header { text-align: center; margin-bottom: 40px; }
        .members-header h1 { font-size: 36px; color: var(--text-primary); }
        .members-header h1 i { color: var(--accent); }
        .members-header p { color: var(--text-secondary); font-size: 18px; }
        .members-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
        }
        .member-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            padding: 25px;
            text-align: center;
            transition: var(--transition);
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
            position: relative;
            overflow: hidden;
        }
        .member-card:hover {
            transform: translateY(-5px);
            border-color: var(--accent);
            box-shadow: 0 8px 30px rgba(220, 38, 38, 0.2);
        }
        .member-card .member-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin: 0 auto 15px;
            border: 3px solid var(--accent);
            overflow: hidden;
            background: var(--bg-input);
        }
        .member-card .member-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .member-card .member-avatar .fallback {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: white;
            background: var(--accent);
        }
        .member-card .member-name {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 5px;
        }
        .member-card .member-position {
            color: var(--accent);
            font-weight: 500;
            font-size: 14px;
            margin-bottom: 12px;
        }
        .member-card .member-bio {
            color: var(--text-secondary);
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 15px;
            min-height: 40px;
        }
        .member-card .member-achievements {
            text-align: right;
            padding: 12px;
            background: var(--bg-input);
            border-radius: var(--radius-sm);
            margin-top: 10px;
        }
        .member-card .member-achievements h5 {
            color: var(--text-secondary);
            font-size: 13px;
            margin-bottom: 5px;
        }
        .member-card .member-achievements ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .member-card .member-achievements ul li {
            color: var(--text-secondary);
            font-size: 13px;
            padding: 2px 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .member-card .member-achievements ul li i {
            color: #fbbf24;
            font-size: 12px;
        }
        .member-card .member-join-date {
            color: var(--text-secondary);
            font-size: 12px;
            margin-top: 12px;
            border-top: 1px solid var(--border-color);
            padding-top: 12px;
        }
        .btn-edit {
            position: absolute;
            top: 10px;
            left: 10px;
            background: rgba(13, 110, 253, 0.9);
            border: none;
            color: white;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            cursor: pointer;
            transition: var(--transition);
            display: none;
            align-items: center;
            justify-content: center;
        }
        .member-card:hover .btn-edit { display: flex; }
        .btn-edit:hover { background: #0b5ed7; transform: scale(1.1); }
        
        .no-members { text-align: center; padding: 60px 20px; color: var(--text-secondary); }
        .no-members i { font-size: 48px; display: block; margin-bottom: 15px; }

        .empty-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin: 0 auto 15px;
            background: var(--bg-input);
            border: 3px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: var(--text-secondary);
        }
    </style>
</head>
<body>

<!-- ===== الهيدر ===== -->
<header class="header">
    <a href="/Italiano/index.php?tab=home" class="logo" style="display:flex; align-items:center; gap:10px; text-decoration:none;">
        <img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png?ver=2" alt="ITV - Italiano">
    </a>
    <nav class="nav">
        <a href="/Italiano/pages/rules.php?tab=rules"><i class="fas fa-gavel"></i> القوانين</a>
        <a href="/Italiano/index.php?tab=store"><i class="fas fa-store"></i> المتجر</a>
        <a href="/Italiano/index.php?tab=applications"><i class="fas fa-file-signature"></i> التقديمات</a>
        <a href="/Italiano/index.php?tab=farms"><i class="fas fa-tractor"></i> المزارع</a>
        <a href="/Italiano/pages/members.php" class="active"><i class="fas fa-users"></i> الأعضاء</a>
    </nav>
    <div style="display:flex; align-items:center; gap:14px;">
        <?php if ($isLoggedIn && $currentUser): ?>
            <a href="/Italiano/index.php?tab=profile" class="profile-wrapper">
                <div class="avatar-container">
                    <?php if (!empty($currentUser['discord_id'])): ?>
                        <img src="https://cdn.discordapp.com/avatars/<?php echo htmlspecialchars($currentUser['discord_id']); ?>/<?php echo htmlspecialchars($currentUser['avatar'] ?? ''); ?>.png?size=40" alt="Profile">
                    <?php else: ?>
                        <div class="fallback"><?php echo strtoupper(substr($currentUser['username'] ?? 'U', 0, 1)); ?></div>
                    <?php endif; ?>
                    <span class="status-dot"></span>
                </div>
                <span class="profile-name"><?php echo htmlspecialchars($currentUser['username'] ?? 'مستخدم'); ?></span>
            </a>
            <a href="/Italiano/index.php?tab=dashboard" class="dashboard-icon" title="لوحة التحكم"><i class="fas fa-th"></i></a>
            <?php if (in_array('founder', $currentUser['roles'] ?? [])): ?>
                <a href="/Italiano/pages/manage_members.php" class="dashboard-icon" title="إدارة الأعضاء" style="color:#10b981;"><i class="fas fa-user-edit"></i></a>
            <?php endif; ?>
        <?php else: ?>
            <a href="/Italiano/auth/discord.php" class="btn btn-discord"><i class="fab fa-discord"></i> دخول عبر ديسكورد</a>
        <?php endif; ?>
    </div>
</header>

<!-- ===== المحتوى ===== -->
<div class="members-container">

    <div class="members-header">
        <h1><i class="fas fa-users"></i> أعضاء عائلة <span style="color:var(--accent);">Italiano</span></h1>
        <p>تعرف على أعضاء عائلة Italiano وأدوارهم وإنجازاتهم</p>
    </div>

    <?php if (empty($members)): ?>
        <div class="no-members">
            <i class="fas fa-users-slash"></i>
            <h3>لا يوجد أعضاء مسجلين حالياً</h3>
            <p>سيتم عرض أعضاء العائلة هنا قريباً.</p>
        </div>
    <?php else: ?>
        <div class="members-grid">
            <?php foreach ($members as $member): ?>
                <div class="member-card">
                    <?php if (in_array('founder', $currentUser['roles'] ?? [])): ?>
                        <a href="/Italiano/pages/manage_members.php?edit=<?php echo $member['id']; ?>" class="btn-edit" title="تعديل">
                            <i class="fas fa-pen"></i>
                        </a>
                    <?php endif; ?>
                    
                    <div class="member-avatar">
                        <?php
                        $avatarUrl = getMemberAvatarUrl($member);
                        if ($avatarUrl):
                        ?>
                            <img src="<?php echo $avatarUrl; ?>" alt="<?php echo htmlspecialchars($member['display_name']); ?>">
                        <?php else: ?>
                            <div class="fallback"><?php echo htmlspecialchars(mb_substr($member['display_name'], 0, 1)); ?></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="member-name"><?php echo htmlspecialchars($member['display_name']); ?></div>
                    <div class="member-position"><?php echo htmlspecialchars(getMemberPosition($member)); ?></div>
                    
                    <div class="member-bio">
                        <?php echo nl2br(htmlspecialchars(getMemberBio($member))); ?>
                    </div>
                    
                    <?php
                    $achievements = getMemberAchievements($member);
                    if (!empty($achievements)):
                    ?>
                        <div class="member-achievements">
                            <h5><i class="fas fa-trophy" style="color:#fbbf24;"></i> الإنجازات</h5>
                            <ul>
                                <?php foreach ($achievements as $ach): ?>
                                    <?php if (!empty(trim($ach))): ?>
                                        <li><i class="fas fa-star"></i> <?php echo htmlspecialchars(trim($ach)); ?></li>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($member['join_date'])): ?>
                        <div class="member-join-date">
                            <i class="fas fa-calendar-alt"></i> انضم في: <?php echo date('d/m/Y', strtotime($member['join_date'])); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- ===== الفوتر ===== -->
<footer class="footer">
    <div class="footer-container">
        <div class="footer-col">
            <div class="footer-logo"><img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png" alt="Italiano" class="footer-logo-img"></div>
            <p class="footer-desc">عائلة Italiano، واحدة من أعرق العائلات في عالم وناسة تايم.</p>
            <div class="footer-social">
                <a href="#" class="social-link"><i class="fab fa-discord"></i></a>
                <a href="#" class="social-link"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
        <div class="footer-col">
            <h4 class="footer-title">السيرفر</h4>
            <ul class="footer-links">
                <li><a href="/Italiano/index.php?tab=store">المتجر</a></li>
                <li><a href="/Italiano/index.php?tab=applications">التقديمات</a></li>
                <li><a href="/Italiano/pages/members.php">الأعضاء</a></li>
            </ul>
        </div>
        <div class="footer-col">
            <h4 class="footer-title">الدعم الفني</h4>
            <ul class="footer-links">
                <li><a href="/Italiano/pages/rules.php?tab=rules">القوانين</a></li>
                <li><a href="https://discord.gg/BdqPsR3ATm" target="_blank">ديسكورد</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="footer-bottom-container">
            <span class="footer-copy">© 2026 Italiano. جميع الحقوق محفوظة.</span>
            <span class="footer-dev">تم التطوير بواسطة <strong>M_550</strong></span>
        </div>
    </div>
</footer>

</body>
</html>