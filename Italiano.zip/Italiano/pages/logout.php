<?php
// logout.php
require_once __DIR__ . '/../inc/functions.php';
require_once __DIR__ . '/../inc/config.php';
logout();
?>
