<?php
$host = 'localhost';
$dbname = 'italiano_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    $count = $stmt->fetchColumn();
    echo "✅ الاتصال ناجح! عدد المستخدمين: $count";
} catch (PDOException $e) {
    echo "❌ فشل: " . $e->getMessage();
}
?>