<?php
// ====== تمكين عرض الأخطاء ======
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../error.log');

// ====== تضمين الدوال والاتصال بقاعدة البيانات ======
require_once __DIR__ . '/../inc/functions.php';
require_once __DIR__ . '/../inc/config.php';
generateCSRFToken();

// ===== قراءة التبويب المطلوب من الرابط =====
$activeTab = $_GET['tab'] ?? 'home';
$validTabs = ['home', 'store', 'applications', 'profile', 'dashboard', 'farms'];
if (!in_array($activeTab, $validTabs)) {
    $activeTab = 'home';
}

// ============================================================
// 🌾 إنهاء حجوزات المزارع المنتهية وإرسال تذكير قبل 24 ساعة
// ============================================================
autoCompleteFarmBookings($pdo);

// ====== معالجة طلبات AJAX ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log("🟢 TEST: تم استلام إجراء: " . ($_POST['action'] ?? 'غير معروف'));

    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!verifyCSRFToken($csrf_token)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'طلب غير صالح (CSRF)']);
        exit;
    }

    $action = $_POST['action'] ?? '';
    $response = ['success' => false, 'message' => 'حدث خطأ'];

    $userId = $_SESSION['user_id'] ?? 0;
    $sessionRoles = [];

    if ($userId) {
        $sessionRoles = getUserRolesFromDB($userId, $pdo);
        $_SESSION['roles'] = $sessionRoles;
    }

    try {
        $isFounder = in_array('founder', $sessionRoles, true);
        $isSkinDesigner = in_array('skin_designer', $sessionRoles, true);
        $isEngineSeller = in_array('engine_seller', $sessionRoles, true);
        $isFarmManager = in_array('farm_rental_manager', $sessionRoles, true);
        $isHousingManager = in_array('housing_apps_manager', $sessionRoles, true);
        
        $canManageAppType = function($managerRoleKey) use ($sessionRoles, $isFounder) {
            if ($isFounder) return true;
            if (!$managerRoleKey) return false;
            return in_array($managerRoleKey, $sessionRoles, true);
        };

        // ===== حذف طلب شراء =====
        if ($action === 'delete_purchase') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $purchaseId = intval($_POST['purchase_id'] ?? 0);
                $chkStmt = $pdo->prepare("
                    SELECT pr.category 
                    FROM purchases p 
                    JOIN products pr ON p.product_id = pr.id 
                    WHERE p.id = ?
                ");
                $chkStmt->execute([$purchaseId]);
                $cat = $chkStmt->fetchColumn();
                
                if (!$isFounder) {
                    if ($cat === 'engines' && !$isEngineSeller) {
                        $response = ['success' => false, 'message' => 'فقط الفاوندر وبائع المحركات يمكنهم حذف طلبات المحركات'];
                        echo json_encode($response);
                        exit;
                    }
                    if (($cat === 'male_skins' || $cat === 'female_skins') && !$isSkinDesigner) {
                        $response = ['success' => false, 'message' => 'فقط الفاوندر ومصمم السكنات يمكنهم حذف طلبات السكنات'];
                        echo json_encode($response);
                        exit;
                    }
                }
                $stmt = $pdo->prepare("DELETE FROM purchases WHERE id = ?");
                $stmt->execute([$purchaseId]);
                $response = ['success' => true, 'message' => 'تم حذف طلب الشراء'];
            }
        }
        // ===== حذف تقديم =====
        elseif ($action === 'delete_submission') {
            $submissionId = intval($_POST['submission_id'] ?? 0);
            
            $chk = $pdo->prepare("
                SELECT a.manager_role_key 
                FROM submissions s 
                JOIN application_types a ON s.type_id = a.id 
                WHERE s.id = ?
            ");
            $chk->execute([$submissionId]);
            $row = $chk->fetch(PDO::FETCH_ASSOC);
            $managerRoleKey = $row['manager_role_key'] ?? null;
            
            if (!$canManageAppType($managerRoleKey)) {
                $response = ['success' => false, 'message' => 'غير مصرح لك بحذف هذا الطلب'];
            } else {
                $stmt = $pdo->prepare("DELETE FROM submissions WHERE id = ?");
                $stmt->execute([$submissionId]);
                $response = ['success' => true, 'message' => 'تم حذف التقديم'];
            }
        }
        // ===== تحديث حالة المنتج =====
        elseif ($action === 'update_product_status') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $status = $_POST['status'] ?? 'available';
                $allowed = ['available', 'sold', 'pending'];
                if (!in_array($status, $allowed)) {
                    $response = ['success' => false, 'message' => 'حالة غير صالحة'];
                } else {
                    $stmt = $pdo->prepare("UPDATE products SET status = ? WHERE id = ?");
                    $stmt->execute([$status, $id]);
                    $response = ['success' => true, 'message' => 'تم تحديث حالة المنتج'];
                }
            }
        }
        // ===== إضافة منتج =====
        elseif ($action === 'add_product') {
            $userId = $_SESSION['user_id'] ?? 0;
            $sessionRoles = [];
            if ($userId) {
                $sessionRoles = getUserRolesFromDB($userId, $pdo);
                $_SESSION['roles'] = $sessionRoles;
            }

            $isFounder = in_array('founder', $sessionRoles, true);
            $isSkinDesigner = in_array('skin_designer', $sessionRoles, true);
            $isEngineSeller = in_array('engine_seller', $sessionRoles, true);
            
            $name = trim($_POST['name'] ?? '');
            $category = trim($_POST['category'] ?? 'male_skins');
            $price = floatval($_POST['price'] ?? 0);
            $iban = trim($_POST['iban'] ?? '');

            if ($category === 'engines' && !$isFounder && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'فقط الفاوندر وبائع المحركات يمكنهم إضافة المحركات'];
                echo json_encode($response);
                exit;
            }
            if (($category === 'male_skins' || $category === 'female_skins') && !$isFounder && !$isSkinDesigner) {
                $response = ['success' => false, 'message' => 'فقط الفاوندر ومصمم السكنات يمكنهم إضافة السكنات'];
                echo json_encode($response);
                exit;
            }

            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => '❌ غير مصرح! رتبك الحالية: ' . implode(', ', $sessionRoles)];
                echo json_encode($response);
                exit;
            }

            $uploadResult = uploadImage('image', 'products');
            $imagePath = null;
            if ($uploadResult['success']) {
                $imagePath = $uploadResult['path'];
            } elseif (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
                $response = ['success' => false, 'message' => 'فشل رفع الصورة: ' . $uploadResult['message']];
                echo json_encode($response);
                exit;
            }
            
            $stmt = $pdo->prepare("INSERT INTO products (name, category, price, iban, image, status) VALUES (?, ?, ?, ?, ?, 'available')");
            $stmt->execute([$name, $category, $price, $iban, $imagePath]);
            $response = ['success' => true, 'message' => 'تمت الإضافة', 'id' => $pdo->lastInsertId(), 'image' => $imagePath];
        }
        elseif ($action === 'delete_product') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
                $stmt->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ===== شراء منتج =====
        elseif ($action === 'purchase_product') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول أولاً'];
            } else {
                $product_id = intval($_POST['product_id'] ?? 0);
                
                if (!isset($_FILES['payment_image']) || $_FILES['payment_image']['error'] === UPLOAD_ERR_NO_FILE) {
                    $response = ['success' => false, 'message' => 'يرجى رفع صورة إثبات الدفع'];
                } else {
                    $uploadResult = uploadImage('payment_image', 'payments');
                    if (!$uploadResult['success']) {
                        $response = ['success' => false, 'message' => 'فشل رفع الصورة: ' . $uploadResult['message']];
                    } else {
                        $imagePath = $uploadResult['path'];
                        
                        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND status = 'available'");
                        $stmt->execute([$product_id]);
                        $product = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if (!$product) {
                            $response = ['success' => false, 'message' => 'المنتج غير متاح أو تم بيعه'];
                        } else {
                            try {
                                $stmt = $pdo->prepare("INSERT INTO purchases (product_id, user_id, amount, iban_used, payment_image, status) VALUES (?, ?, ?, ?, ?, 'pending')");
                                $stmt->execute([$product_id, $userId, $product['price'], $product['iban'] ?? '', $imagePath]);
                                
                                $response = ['success' => true, 'message' => 'تم إرسال طلب الشراء بنجاح، في انتظار مراجعة الإدارة'];
                            } catch (PDOException $e) {
                                error_log('Purchase error: ' . $e->getMessage());
                                $response = ['success' => false, 'message' => 'حدث خطأ أثناء معالجة الطلب'];
                            }
                        }
                    }
                }
            }
        }
        // ===== جلب طلبات الشراء =====
        elseif ($action === 'get_purchases') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $stmt = $pdo->prepare("
                    SELECT p.*, u.username as user_name, pr.name as product_name, pr.category
                    FROM purchases p
                    JOIN users u ON p.user_id = u.id
                    JOIN products pr ON p.product_id = pr.id
                    ORDER BY p.created_at DESC
                ");
                $stmt->execute();
                $purchases = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                if (!$isFounder) {
                    if ($isSkinDesigner) {
                        $purchases = array_filter($purchases, function($p) {
                            return $p['category'] === 'male_skins' || $p['category'] === 'female_skins';
                        });
                    } elseif ($isEngineSeller) {
                        $purchases = array_filter($purchases, function($p) {
                            return $p['category'] === 'engines';
                        });
                    } else {
                        $purchases = [];
                    }
                }
                
                $response = ['success' => true, 'purchases' => array_values($purchases)];
            }
        }
        // ===== تحديث طلب شراء =====
        elseif ($action === 'update_purchase') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $purchase_id = intval($_POST['purchase_id'] ?? 0);
                $status = $_POST['status'] ?? 'pending';
                $delivery_link = trim($_POST['delivery_link'] ?? '');
                $admin_notes = trim($_POST['admin_notes'] ?? '');
                
                $stmt = $pdo->prepare("SELECT p.*, pr.category, pr.id as product_id, pr.name as product_name, p.user_id FROM purchases p JOIN products pr ON p.product_id = pr.id WHERE p.id = ?");
                $stmt->execute([$purchase_id]);
                $purchase = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$purchase) {
                    $response = ['success' => false, 'message' => 'الطلب غير موجود'];
                } else {
                    if (!$isFounder) {
                        if ($purchase['category'] === 'engines' && !$isEngineSeller) {
                            $response = ['success' => false, 'message' => 'فقط الفاوندر وبائع المحركات يمكنهم مراجعة طلبات المحركات'];
                            echo json_encode($response);
                            exit;
                        }
                        if (($purchase['category'] === 'male_skins' || $purchase['category'] === 'female_skins') && !$isSkinDesigner) {
                            $response = ['success' => false, 'message' => 'فقط الفاوندر ومصمم السكنات يمكنهم مراجعة طلبات السكنات'];
                            echo json_encode($response);
                            exit;
                        }
                    }

                    $stmt = $pdo->prepare("UPDATE purchases SET status = ?, admin_notes = ?, delivery_link = ? WHERE id = ?");
                    $stmt->execute([$status, $admin_notes, $delivery_link, $purchase_id]);
                    
                    if ($purchase['category'] !== 'male_skins' && $purchase['category'] !== 'female_skins') {
                        if ($status === 'approved' || $status === 'delivered') {
                            $stmt = $pdo->prepare("UPDATE products SET status = 'sold' WHERE id = ?");
                            $stmt->execute([$purchase['product_id']]);
                        } elseif ($status === 'rejected') {
                            $stmt = $pdo->prepare("UPDATE products SET status = 'available' WHERE id = ?");
                            $stmt->execute([$purchase['product_id']]);
                        }
                    }
                    
                    if ($status === 'approved' && $purchase['category'] === 'engines') {
                        $userStmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                        $userStmt->execute([$purchase['user_id']]);
                        $user = $userStmt->fetch(PDO::FETCH_ASSOC);
                        
                        createBotTicket($pdo, $purchase['user_id'], 'engine',
                            'استلام محرك - ' . $user['username'],
                            'تم تأكيد شراء المحرك "' . $purchase['product_name'] . '". يرجى التواصل مع الإدارة لاستلام المحرك.'
                        );
                    }
                    
                    if ($status === 'delivered' && !empty($delivery_link)) {
                        $notifStmt = $pdo->prepare("
                            INSERT INTO notifications (user_id, type, title, message, link) 
                            VALUES (?, 'delivery', '✅ تم تسليم طلبك!', ?, ?)
                        ");
                        $notifStmt->execute([
                            $purchase['user_id'],
                            'تم تسليم المنتج "' . $purchase['product_name'] . '"، يمكنك استلامه من خلال الرابط التالي:',
                            $delivery_link
                        ]);

                        sendBotDM($pdo, $purchase['user_id'], 
                            '✅ تم تسليم المنتج!', 
                            'تم تسليم المنتج "' . $purchase['product_name'] . '" الذي اشتريته. يمكنك استلامه من خلال الرابط التالي:',
                            $delivery_link
                        );
                    }
                    
                    if ($status === 'approved' && $purchase['status'] !== 'approved') {
                        $notifStmt = $pdo->prepare("
                            INSERT INTO notifications (user_id, type, title, message, link) 
                            VALUES (?, 'purchase', '✅ تم تأكيد طلب الشراء!', ?, ?)
                        ");
                        $notifStmt->execute([
                            $purchase['user_id'],
                            'تم تأكيد طلب شراء "' . $purchase['product_name'] . '" بنجاح، جاري تجهيز الطلب.',
                            null
                        ]);
                    }
                    
                    $response = ['success' => true, 'message' => 'تم تحديث الطلب'];
                }
            }
        }
        // ===== جلب الإشعارات =====
        elseif ($action === 'get_notifications') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول'];
            } else {
                $stmt = $pdo->prepare("
                    SELECT * FROM notifications 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT 50
                ");
                $stmt->execute([$userId]);
                $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
                $stmt->execute([$userId]);
                $unreadCount = (int) $stmt->fetchColumn();
                
                $response = ['success' => true, 'notifications' => $notifications, 'unread_count' => $unreadCount];
            }
        }
        // ===== تحديد إشعار كمقروء =====
        elseif ($action === 'mark_notification_read') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول'];
            } else {
                $notification_id = intval($_POST['notification_id'] ?? 0);
                if ($notification_id > 0) {
                    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
                    $stmt->execute([$notification_id, $userId]);
                } else {
                    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
                    $stmt->execute([$userId]);
                }
                $response = ['success' => true, 'message' => 'تم التحديث'];
            }
        }
        // ===== حذف الإشعارات المقروءة =====
        elseif ($action === 'delete_read_notifications') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول'];
            } else {
                try {
                    $stmt = $pdo->prepare("DELETE FROM notifications WHERE user_id = ? AND is_read = 1");
                    $stmt->execute([$userId]);
                    $response = ['success' => true, 'message' => 'تم حذف الإشعارات المقروءة بنجاح'];
                } catch (PDOException $e) {
                    $response = ['success' => false, 'message' => 'حدث خطأ أثناء الحذف'];
                }
            }
        }
        // ===== إدارة السلايدر =====
        elseif ($action === 'add_slider') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $title = trim($_POST['title'] ?? '');
                $link = trim($_POST['link'] ?? '');
                
                $uploadResult = uploadImage('slider_image', 'slider');
                if (!$uploadResult['success']) {
                    $response = ['success' => false, 'message' => 'فشل رفع الصورة: ' . $uploadResult['message']];
                } else {
                    $imagePath = $uploadResult['path'];
                    try {
                        $stmt = $pdo->prepare("INSERT INTO sliders (image, title, link, sort_order, is_active) VALUES (?, ?, ?, (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM sliders), 1)");
                        $stmt->execute([$imagePath, $title, $link]);
                        $response = ['success' => true, 'message' => 'تمت إضافة الصورة بنجاح'];
                    } catch (PDOException $e) {
                        error_log('Slider insert error (first attempt): ' . $e->getMessage());
                        try {
                            $stmt = $pdo->prepare("INSERT INTO sliders (image, title, link, is_active) VALUES (?, ?, ?, 1)");
                            $stmt->execute([$imagePath, $title, $link]);
                            $response = ['success' => true, 'message' => 'تمت إضافة الصورة بنجاح (بدون ترتيب)'];
                        } catch (PDOException $e2) {
                            error_log('Slider insert error (second attempt): ' . $e2->getMessage());
                            try {
                                $stmt = $pdo->prepare("INSERT INTO sliders (image, title, link) VALUES (?, ?, ?)");
                                $stmt->execute([$imagePath, $title, $link]);
                                $response = ['success' => true, 'message' => 'تمت إضافة الصورة بنجاح (بدون ترتيب وحالة)'];
                            } catch (PDOException $e3) {
                                error_log('Slider insert error (final attempt): ' . $e3->getMessage());
                                $response = ['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e3->getMessage()];
                            }
                        }
                    }
                }
            }
        }
        elseif ($action === 'delete_slider') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("DELETE FROM sliders WHERE id = ?");
                $stmt->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        elseif ($action === 'toggle_slider_status') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $is_active = intval($_POST['is_active'] ?? 1);
                
                try {
                    $stmt = $pdo->prepare("UPDATE sliders SET is_active = ? WHERE id = ?");
                    $stmt->execute([$is_active, $id]);
                    $response = ['success' => true, 'message' => 'تم تحديث الحالة'];
                } catch (PDOException $e) {
                    error_log('Toggle slider status error: ' . $e->getMessage());
                    $response = ['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()];
                }
            }
        }
        // ===== باقي الإجراءات =====
        elseif ($action === 'toggle_app') {
            $id = intval($_POST['id'] ?? 0);
            $is_open = intval($_POST['is_open'] ?? 1);
            
            $chk = $pdo->prepare("SELECT manager_role_key, name FROM application_types WHERE id = ?");
            $chk->execute([$id]);
            $row = $chk->fetch(PDO::FETCH_ASSOC);
            $managerRoleKey = $row['manager_role_key'] ?? null;
            
            if (!$isFounder && !in_array($managerRoleKey, $sessionRoles, true)) {
                $response = ['success' => false, 'message' => 'غير مصرح لك بإدارة هذا التقديم'];
            } else {
                $stmt = $pdo->prepare("UPDATE application_types SET is_open = ? WHERE id = ?");
                $stmt->execute([$is_open, $id]);
                
                if ($is_open == 1) {
                    $appName = $row['name'] ?? 'تقديم';
                    $title = '📢 تم فتح تقديم جديد!';
                    $message = 'تم فتح تقديم "' . $appName . '" في الموقع. يمكنك التقديم الآن من خلال قسم التقديمات.';
                    
                    $usersStmt = $pdo->query("SELECT id FROM users");
                    $users = $usersStmt->fetchAll(PDO::FETCH_COLUMN);
                    
                    foreach ($users as $userId) {
                        sendBotDM($pdo, $userId, $title, $message);
                    }
                }
                
                $response = ['success' => true, 'message' => 'تم التحديث'];
            }
        }
        // ===== مراجعة التقديم =====
        elseif ($action === 'review_submission') {
            $id = intval($_POST['id'] ?? 0);
            $status = $_POST['status'] ?? 'pending';

            $chk = $pdo->prepare("
                SELECT s.user_id, a.manager_role_key, a.name as type_name, a.id as type_id, s.answers
                FROM submissions s
                JOIN application_types a ON s.type_id = a.id
                WHERE s.id = ?
            ");
            $chk->execute([$id]);
            $row = $chk->fetch(PDO::FETCH_ASSOC);
            $managerRoleKey = $row['manager_role_key'] ?? null;

            if (!$canManageAppType($managerRoleKey)) {
                $response = ['success' => false, 'message' => 'غير مصرح لك بمراجعة هذا الطلب'];
            } else {
                try {
                    $stmt = $pdo->prepare("UPDATE submissions SET status = ? WHERE id = ?");
                    $stmt->execute([$status, $id]);

                    if ($status === 'accepted' || $status === 'rejected') {
                        $title = $status === 'accepted' ? '✅ تم قبول طلبك!' : '❌ تم رفض طلبك';
                        $message = $status === 'accepted'
                            ? 'تم قبول تقديمك "' . $row['type_name'] . '" بنجاح.'
                            : 'تم رفض تقديمك "' . $row['type_name'] . '".';

                        addNotification($pdo, $row['user_id'], 'submission', $title, $message);
                        sendBotDM($pdo, $row['user_id'], $title, $message);

                        if ($status === 'accepted') {
                            $userStmt = $pdo->prepare("SELECT discord_id FROM users WHERE id = ?");
                            $userStmt->execute([$row['user_id']]);
                            $discord_id = $userStmt->fetchColumn();

                            $typeName = $row['type_name'] ?? '';
                            error_log("📝 معالجة تقديم: $typeName (user_id: {$row['user_id']})");

                            // ===== منح رتبة الشركة =====
                            if (mb_strpos($typeName, 'شركة') !== false) {
                                error_log("🏢 تقديم شركة للمستخدم {$row['user_id']}");
                                $roleKeySite = 'company_member';
                                $roleStmt = $pdo->prepare("SELECT id FROM roles WHERE role_key = ?");
                                $roleStmt->execute([$roleKeySite]);
                                $roleId = $roleStmt->fetchColumn();
                                if ($roleId) {
                                    $insRole = $pdo->prepare("INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)");
                                    $insRole->execute([$row['user_id'], $roleId]);
                                    error_log("✅ تم منح رتبة company_member للمستخدم {$row['user_id']}");
                                    
                                    // منح رتبة ديسكورد وتغيير النيكネーム
                                    if ($discord_id) {
                                        $targetDiscordRoleId = '1538718454394257451';
                                        addBotAction($pdo, $row['user_id'], 'give_role', [
                                            'discord_id' => $discord_id,
                                            'role_id' => $targetDiscordRoleId
                                        ]);
                                        error_log("✅ تم إدراج أمر give_role للمستخدم {$row['user_id']}");
                                        
                                        // تغيير النيكネーム
                                        $answers = json_decode($row['answers'] ?? '{}', true);
                                        if (is_array($answers) && !empty($answers)) {
                                            $qStmt = $pdo->prepare("SELECT id, question_text FROM application_questions WHERE type_id = ?");
                                            $qStmt->execute([$row['type_id']]);
                                            $questions = $qStmt->fetchAll(PDO::FETCH_KEY_PAIR);

                                            $name = '';
                                            $idValue = '';
                                            foreach ($questions as $qid => $qtext) {
                                                if (mb_strpos($qtext, 'اسم الشخصية') !== false && isset($answers[$qid])) {
                                                    $name = trim($answers[$qid]);
                                                }
                                                if (mb_strpos($qtext, 'الأيدي') !== false && isset($answers[$qid])) {
                                                    $idValue = trim($answers[$qid]);
                                                }
                                            }

                                            if (!empty($name) && !empty($idValue) && $discord_id) {
                                                $newNick = $name . ' | ' . $idValue;
                                                addBotAction($pdo, $row['user_id'], 'change_nickname', [
                                                    'discord_id' => $discord_id,
                                                    'nickname' => $newNick
                                                ]);
                                                error_log("✅ تم إدراج أمر change_nickname للمستخدم {$row['user_id']} باسم $newNick");
                                            }
                                        }
                                    }
                                } else {
                                    error_log("❌ رتبة company_member غير موجودة في جدول roles!");
                                }
                            }

                            // ===== منح رتبة مصمم سكنات =====
                            if (mb_strpos($typeName, 'مصمم') !== false && mb_strpos($typeName, 'سكنات') !== false) {
                                error_log("🎨 تم التعرف على تقديم مصمم سكنات للمستخدم {$row['user_id']} (اسم التقديم: $typeName)");

                                $roleKeySite = 'skin_designer';
                                $roleStmt = $pdo->prepare("SELECT id FROM roles WHERE role_key = ?");
                                $roleStmt->execute([$roleKeySite]);
                                $roleId = $roleStmt->fetchColumn();
                                if ($roleId) {
                                    $insRole = $pdo->prepare("INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)");
                                    $insRole->execute([$row['user_id'], $roleId]);
                                    error_log("✅ تم منح رتبة skin_designer للمستخدم {$row['user_id']} (role_id: $roleId)");
                                    addNotification($pdo, $row['user_id'], 'submission', '🎨 تم منحك رتبة مصمم سكنات', 'تهانينا! تم قبولك كمصمم سكنات وأضيفت لك الرتبة في الموقع.');
                                } else {
                                    error_log("❌ رتبة skin_designer غير موجودة في جدول roles!");
                                }

                                // (اختياري) منح رتبة ديسكورد لمصممي السكنات
                                // if ($discord_id) {
                                //     $targetDiscordRoleId = 'YOUR_SKIN_DESIGNER_ROLE_ID';
                                //     addBotAction($pdo, $row['user_id'], 'give_role', [
                                //         'discord_id' => $discord_id,
                                //         'role_id' => $targetDiscordRoleId
                                //     ]);
                                // }
                            } else {
                                error_log("ℹ️ التقديم ليس من نوع 'مصمم سكنات' (الاسم: $typeName)");
                            }
                        }
                    }

                    $response = ['success' => true, 'message' => 'تم التحديث بنجاح'];
                } catch (Exception $e) {
                    error_log('🔥 خطأ في review_submission: ' . $e->getMessage());
                    $response = ['success' => false, 'message' => 'حدث خطأ: ' . $e->getMessage()];
                }
            }
        }
        // ===== get_submission_answers =====
        elseif ($action === 'get_submission_answers') {
            $id = intval($_POST['id'] ?? 0);
            $chk = $pdo->prepare("
                SELECT s.*, u.username, a.name as type_name, a.manager_role_key
                FROM submissions s
                JOIN users u ON s.user_id = u.id
                JOIN application_types a ON s.type_id = a.id
                WHERE s.id = ?
            ");
            $chk->execute([$id]);
            $submission = $chk->fetch(PDO::FETCH_ASSOC);
            
            if (!$submission) {
                $response = ['success' => false, 'message' => 'الطلب غير موجود'];
            } else {
                if (!$canManageAppType($submission['manager_role_key'])) {
                    $response = ['success' => false, 'message' => 'غير مصرح بعرض هذا الطلب'];
                } else {
                    $answers = json_decode($submission['answers'] ?? '{}', true);
                    if (!is_array($answers)) $answers = [];
                    $questions = [];
                    if (!empty($answers)) {
                        $qids = array_keys($answers);
                        $placeholders = implode(',', array_fill(0, count($qids), '?'));
                        $qstmt = $pdo->prepare("SELECT id, question_text FROM application_questions WHERE id IN ($placeholders)");
                        $qstmt->execute($qids);
                        $questions = $qstmt->fetchAll(PDO::FETCH_KEY_PAIR);
                    }
                    $response = [
                        'success' => true,
                        'submission' => $submission,
                        'answers' => $answers,
                        'questions' => $questions
                    ];
                }
            }
        }
        // ===== add_question =====
        elseif ($action === 'add_question') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $type_id = intval($_POST['type_id'] ?? 0);
                $text = trim($_POST['text'] ?? 'سؤال جديد');
                $field_type = $_POST['field_type'] ?? 'text';
                $options = $_POST['options'] ?? '[]';
                $required = intval($_POST['required'] ?? 0);
                $stmt = $pdo->prepare("INSERT INTO application_questions (type_id, question_text, field_type, options, required) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$type_id, $text, $field_type, $options, $required]);
                $response = ['success' => true, 'message' => 'تمت الإضافة', 'id' => $pdo->lastInsertId()];
            }
        }
        // ===== update_question =====
        elseif ($action === 'update_question') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $text = trim($_POST['text'] ?? '');
                $field_type = $_POST['field_type'] ?? 'text';
                $options = $_POST['options'] ?? '[]';
                $required = intval($_POST['required'] ?? 0);
                $stmt = $pdo->prepare("UPDATE application_questions SET question_text = ?, field_type = ?, options = ?, required = ? WHERE id = ?");
                $stmt->execute([$text, $field_type, $options, $required, $id]);
                $response = ['success' => true, 'message' => 'تم التحديث'];
            }
        }
        // ===== remove_question =====
        elseif ($action === 'remove_question') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("DELETE FROM application_questions WHERE id = ?");
                $stmt->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ===== update_profile =====
        elseif ($action === 'update_profile') {
            $response = ['success' => false, 'message' => 'تغيير الاسم غير مسموح، اسمك مرتبط بحساب Discord'];
        }
        // ===== update_user_roles =====
        elseif ($action === 'update_user_roles') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'فقط الفاوندر يقدر يعدل الرتب'];
            } else {
                $target_user_id = intval($_POST['user_id'] ?? 0);
                $role_ids = json_decode($_POST['role_ids'] ?? '[]', true);
                if (!is_array($role_ids)) $role_ids = [];
                $role_ids = array_map('intval', $role_ids);

                $pdo->prepare("DELETE FROM user_roles WHERE user_id = ?")->execute([$target_user_id]);
                $ins = $pdo->prepare("INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)");
                foreach ($role_ids as $rid) {
                    $ins->execute([$target_user_id, $rid]);
                }
                $response = ['success' => true, 'message' => 'تم تحديث الرتب'];
            }
        }
        // ===== add_job =====
        elseif ($action === 'add_job') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $name = trim($_POST['name'] ?? '');
                if (empty($name)) {
                    $response = ['success' => false, 'message' => 'أدخل اسم الوظيفة'];
                } else {
                    $stmt = $pdo->prepare("INSERT INTO job_titles (name) VALUES (?)");
                    $stmt->execute([$name]);
                    $response = ['success' => true, 'message' => 'تمت الإضافة', 'id' => $pdo->lastInsertId()];
                }
            }
        }
        // ===== delete_job =====
        elseif ($action === 'delete_job') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $pdo->prepare("DELETE FROM job_titles WHERE id = ?")->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ===== update_user_jobs =====
        elseif ($action === 'update_user_jobs') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $user_id = intval($_POST['user_id'] ?? 0);
                $job_ids = json_decode($_POST['job_ids'] ?? '[]', true);
                if (!is_array($job_ids)) $job_ids = [];
                $job_ids = array_map('intval', $job_ids);
                $pdo->prepare("DELETE FROM user_jobs WHERE user_id = ?")->execute([$user_id]);
                $ins = $pdo->prepare("INSERT IGNORE INTO user_jobs (user_id, job_id) VALUES (?, ?)");
                foreach ($job_ids as $jid) {
                    $ins->execute([$user_id, $jid]);
                }
                $response = ['success' => true, 'message' => 'تم تحديث الوظائف'];
            }
        }
        // ===== add_application_type =====
        elseif ($action === 'add_application_type') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $name = trim($_POST['name'] ?? '');
                $desc = trim($_POST['description'] ?? '');
                $manager_role_key = trim($_POST['manager_role_key'] ?? '');
                $min_hours = intval($_POST['min_hours'] ?? 0);
                $min_history = intval($_POST['min_history'] ?? 0);
                $min_money = intval($_POST['min_money'] ?? 0);
                $requirements = trim($_POST['requirements'] ?? '');
                if (empty($name)) {
                    $response = ['success' => false, 'message' => 'أدخل اسم التقديم'];
                } else {
                    $stmt = $pdo->prepare("INSERT INTO application_types (name, description, manager_role_key, min_hours, min_history, min_money, requirements) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$name, $desc, $manager_role_key ?: null, $min_hours, $min_history, $min_money, $requirements]);
                    $response = ['success' => true, 'message' => 'تمت الإضافة', 'id' => $pdo->lastInsertId()];
                }
            }
        }
        // ===== update_application_type =====
        elseif ($action === 'update_application_type') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $name = trim($_POST['name'] ?? '');
                $desc = trim($_POST['description'] ?? '');
                $manager_role_key = trim($_POST['manager_role_key'] ?? '');
                $min_hours = intval($_POST['min_hours'] ?? 0);
                $min_history = intval($_POST['min_history'] ?? 0);
                $min_money = intval($_POST['min_money'] ?? 0);
                $requirements = trim($_POST['requirements'] ?? '');
                if (empty($name)) {
                    $response = ['success' => false, 'message' => 'أدخل اسم التقديم'];
                } else {
                    $stmt = $pdo->prepare("UPDATE application_types SET name = ?, description = ?, manager_role_key = ?, min_hours = ?, min_history = ?, min_money = ?, requirements = ? WHERE id = ?");
                    $stmt->execute([$name, $desc, $manager_role_key ?: null, $min_hours, $min_history, $min_money, $requirements, $id]);
                    $response = ['success' => true, 'message' => 'تم التحديث'];
                }
            }
        }
        // ===== delete_application_type =====
        elseif ($action === 'delete_application_type') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $pdo->prepare("DELETE FROM application_types WHERE id = ?")->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ============================================================
        // 🌾 إجراءات نظام المزارع
        // ============================================================
        elseif ($action === 'add_farm') {
            if (!$isFarmManager && !$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $name = trim($_POST['name'] ?? '');
                $location = trim($_POST['location'] ?? '');
                $price_per_day = intval($_POST['price_per_day'] ?? 0);
                $assistant_price_per_day = intval($_POST['assistant_price_per_day'] ?? 0);
                if (empty($name) || $price_per_day <= 0) {
                    $response = ['success' => false, 'message' => 'يرجى ملء جميع الحقول الأساسية'];
                } else {
                    $name = htmlspecialchars($name, ENT_QUOTES, 'UTF-8');
                    $location = htmlspecialchars($location, ENT_QUOTES, 'UTF-8');
                    
                    $uploadResult = uploadImage('farm_image', 'farms');
                    $imagePath = null;
                    if ($uploadResult['success']) {
                        $imagePath = $uploadResult['path'];
                    } elseif (isset($_FILES['farm_image']) && $_FILES['farm_image']['error'] !== UPLOAD_ERR_NO_FILE) {
                        $response = ['success' => false, 'message' => 'فشل رفع الصورة: ' . $uploadResult['message']];
                        echo json_encode($response);
                        exit;
                    }
                    
                    $available_from = date('Y-m-d H:i:s', strtotime('+1 day'));
                    
                    $stmt = $pdo->prepare("INSERT INTO farms (name, location, image, price_per_day, assistant_price_per_day, available_from) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$name, $location, $imagePath, $price_per_day, $assistant_price_per_day, $available_from]);
                    $response = ['success' => true, 'message' => 'تمت إضافة المزرعة. ستكون متاحة للحجز بعد 24 ساعة.', 'id' => $pdo->lastInsertId()];
                }
            }
        }
        elseif ($action === 'delete_farm') {
            if (!$isFarmManager && !$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("DELETE FROM farms WHERE id = ?");
                $stmt->execute([$id]);
                $response = ['success' => true, 'message' => 'تم حذف المزرعة'];
            }
        }
        elseif ($action === 'get_farms') {
            $stmt = $pdo->prepare("SELECT * FROM farms WHERE is_active = 1 AND (available_from IS NULL OR available_from <= NOW()) ORDER BY name");
            $stmt->execute();
            $farms = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $response = ['success' => true, 'farms' => $farms];
        }
        elseif ($action === 'get_farm_bookings') {
            if (!$isFarmManager && !$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $stmt = $pdo->prepare("
                    SELECT fb.*, u.username, f.name as farm_name 
                    FROM farm_bookings fb
                    JOIN users u ON fb.user_id = u.id
                    JOIN farms f ON fb.farm_id = f.id
                    ORDER BY fb.created_at DESC
                ");
                $stmt->execute();
                $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $response = ['success' => true, 'bookings' => $bookings];
            }
        }
        elseif ($action === 'book_farm') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول أولاً'];
            } else {
                $farm_id = intval($_POST['farm_id'] ?? 0);
                $days = intval($_POST['days'] ?? 1);
                $assistants = intval($_POST['assistants'] ?? 0);
                
                if ($days < 1 || $days > 3) {
                    $response = ['success' => false, 'message' => 'عدد الأيام يجب أن يكون بين 1 و 3'];
                } else {
                    $stmt = $pdo->prepare("SELECT price_per_day, assistant_price_per_day, name, available_from FROM farms WHERE id = ? AND is_active = 1 AND (available_from IS NULL OR available_from <= NOW())");
                    $stmt->execute([$farm_id]);
                    $farm = $stmt->fetch(PDO::FETCH_ASSOC);
                    if (!$farm) {
                        $response = ['success' => false, 'message' => 'المزرعة غير موجودة أو غير متاحة بعد (انتظر 24 ساعة من وقت الإضافة)'];
                    } else {
                        $stmt = $pdo->prepare("SELECT MAX(end_date) as last_end_date FROM farm_bookings WHERE farm_id = ? AND status IN ('pending', 'approved')");
                        $stmt->execute([$farm_id]);
                        $lastBooking = $stmt->fetch(PDO::FETCH_ASSOC);
                        $today = date('Y-m-d');
                        if ($lastBooking && $lastBooking['last_end_date']) {
                            $start_date = date('Y-m-d', strtotime($lastBooking['last_end_date'] . ' + 1 day'));
                            if ($start_date < $today) {
                                $start_date = $today;
                            }
                        } else {
                            $start_date = $today;
                        }
                        
                        if ($farm['available_from'] && strtotime($start_date) < strtotime($farm['available_from'])) {
                            $start_date = date('Y-m-d', strtotime($farm['available_from']));
                        }
                        
                        $end_date = date('Y-m-d', strtotime($start_date . ' + ' . ($days - 1) . ' days'));
                        
                        $availabilityCheck = $pdo->prepare("
                            SELECT COUNT(*) FROM farm_bookings 
                            WHERE farm_id = ? 
                              AND status IN ('pending', 'approved')
                              AND start_date <= ? 
                              AND end_date >= ?
                        ");
                        $availabilityCheck->execute([$farm_id, $end_date, $start_date]);
                        if ($availabilityCheck->fetchColumn() > 0) {
                            $response = ['success' => false, 'message' => 'حدث خطأ غير متوقع، حاول مرة أخرى'];
                        } else {
                            $total_cost = ($farm['price_per_day'] + ($farm['assistant_price_per_day'] * $assistants)) * $days;
                            $stmt = $pdo->prepare("INSERT INTO farm_bookings (farm_id, user_id, start_date, end_date, days, assistants, total_cost, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
                            $stmt->execute([$farm_id, $userId, $start_date, $end_date, $days, $assistants, $total_cost]);
                            $booking_id = $pdo->lastInsertId();
                            
                            $ticketTitle = 'طلب حجز مزرعة - ' . $farm['name'];
                            $ticketMessage = "تفاصيل طلب الحجز:\nالمزرعة: " . $farm['name'] . "\nالمستخدم: " . $_SESSION['username'] . "\nتاريخ البدء المقترح: " . $start_date . "\nعدد الأيام: " . $days . "\nعدد المساعدين: " . $assistants . "\nالتكلفة الإجمالية: $" . $total_cost . "\n\nفي انتظار موافقة الإدارة لبدء التأجير.";
                            createBotTicket($pdo, $userId, 'farm_booking', $ticketTitle, $ticketMessage);
                            
                            addNotification($pdo, $userId, 'farm', 'طلب حجز مزرعة', 'تم إرسال طلب حجز المزرعة "' . $farm['name'] . '" بنجاح. يرجى متابعة التذكرة لتأكيد الدفع وبدء التأجير.');
                            sendBotDM($pdo, $userId, 'طلب حجز مزرعة', 'تم إرسال طلب حجز المزرعة "' . $farm['name'] . '" في ' . $start_date . ' لمدة ' . $days . ' يوم. سيتم إنشاء تذكرة لتأكيد الدفع والموافقة.');
                            
                            $response = ['success' => true, 'message' => 'تم إرسال طلب الحجز. تم إنشاء تذكرة للمراجعة.', 'booking_id' => $booking_id, 'start_date' => $start_date];
                        }
                    }
                }
            }
        }
        elseif ($action === 'get_farm_next_available_date') {
            $farm_id = intval($_POST['farm_id'] ?? 0);
            $stmt = $pdo->prepare("SELECT available_from FROM farms WHERE id = ? AND is_active = 1");
            $stmt->execute([$farm_id]);
            $farm = $stmt->fetch(PDO::FETCH_ASSOC);
            $available_from = $farm['available_from'] ?? null;
            
            $stmt = $pdo->prepare("
                SELECT MAX(end_date) as last_end_date 
                FROM farm_bookings 
                WHERE farm_id = ? AND status IN ('pending', 'approved')
            ");
            $stmt->execute([$farm_id]);
            $lastBooking = $stmt->fetch(PDO::FETCH_ASSOC);
            $today = date('Y-m-d');
            if ($lastBooking && $lastBooking['last_end_date']) {
                $next_date = date('Y-m-d', strtotime($lastBooking['last_end_date'] . ' + 1 day'));
                if ($next_date < $today) {
                    $next_date = $today;
                }
            } else {
                $next_date = $today;
            }
            if ($available_from && strtotime($next_date) < strtotime($available_from)) {
                $next_date = date('Y-m-d', strtotime($available_from));
            }
            $response = ['success' => true, 'next_start_date' => $next_date];
        }
        elseif ($action === 'approve_booking') {
            if (!$isFarmManager && !$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $booking_id = intval($_POST['booking_id'] ?? 0);
                $stmt = $pdo->prepare("
                    SELECT fb.*, u.username, u.discord_id, f.name as farm_name 
                    FROM farm_bookings fb
                    JOIN users u ON fb.user_id = u.id
                    JOIN farms f ON fb.farm_id = f.id
                    WHERE fb.id = ?
                ");
                $stmt->execute([$booking_id]);
                $booking = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$booking) {
                    $response = ['success' => false, 'message' => 'الحجز غير موجود'];
                } else {
                    $stmt = $pdo->prepare("UPDATE farm_bookings SET status = 'approved' WHERE id = ?");
                    $stmt->execute([$booking_id]);
                    
                    $startDateTime = date('Y-m-d H:i:s');
                    $endDateTime = date('Y-m-d H:i:s', strtotime("+{$booking['days']} days"));
                    
                    $stmt = $pdo->prepare("UPDATE farm_bookings SET start_date = ?, end_date = ? WHERE id = ?");
                    $stmt->execute([$startDateTime, $endDateTime, $booking_id]);
                    
                    $ticketStmt = $pdo->prepare("
                        SELECT id FROM support_tickets 
                        WHERE user_id = ? AND section = 'farm_booking' 
                        ORDER BY created_at DESC LIMIT 1
                    ");
                    $ticketStmt->execute([$booking['user_id']]);
                    $ticket = $ticketStmt->fetch(PDO::FETCH_ASSOC);
                    if ($ticket) {
                        $updateTicket = $pdo->prepare("UPDATE support_tickets SET status = 'resolved' WHERE id = ?");
                        $updateTicket->execute([$ticket['id']]);
                        $replyStmt = $pdo->prepare("INSERT INTO ticket_replies (ticket_id, user_id, reply) VALUES (?, NULL, ?)");
                        $replyMsg = "✅ تم قبول طلب الحجز الخاص بك.\n\n";
                        $replyMsg .= "تفاصيل التأجير:\n";
                        $replyMsg .= "المزرعة: " . $booking['farm_name'] . "\n";
                        $replyMsg .= "تاريخ البدء: " . date('Y-m-d H:i', strtotime($startDateTime)) . "\n";
                        $replyMsg .= "تاريخ الانتهاء: " . date('Y-m-d H:i', strtotime($endDateTime)) . "\n";
                        $replyMsg .= "عدد الأيام: " . $booking['days'] . "\n";
                        $replyMsg .= "المساعدين: " . $booking['assistants'] . "\n";
                        $replyMsg .= "التكلفة الإجمالية: $" . $booking['total_cost'] . "\n\n";
                        $replyMsg .= "سيتم إرسال تذكير قبل 24 ساعة من انتهاء الحجز.";
                        $replyStmt->execute([$ticket['id'], $replyMsg]);
                    }
                    
                    $title = '✅ تم بدء تأجير المزرعة!';
                    $message = "تم قبول حجزك للمزرعة \"" . $booking['farm_name'] . "\".\n\n";
                    $message .= "📅 تاريخ البدء: " . date('Y-m-d H:i', strtotime($startDateTime)) . "\n";
                    $message .= "📅 تاريخ الانتهاء: " . date('Y-m-d H:i', strtotime($endDateTime)) . "\n";
                    $message .= "⏳ المدة: " . $booking['days'] . " يوم\n";
                    $message .= "👥 المساعدين: " . $booking['assistants'] . "\n";
                    $message .= "💰 التكلفة الإجمالية: $" . $booking['total_cost'] . "\n\n";
                    $message .= "سيتم إرسال تذكير قبل 24 ساعة من موعد الانتهاء.";
                    
                    addNotification($pdo, $booking['user_id'], 'farm', $title, $message);
                    sendBotDM($pdo, $booking['user_id'], $title, $message);
                    
                    $response = ['success' => true, 'message' => 'تم قبول الحجز وإرسال الإشعارات'];
                }
            }
        }
        elseif ($action === 'reject_booking') {
            if (!$isFarmManager && !$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $booking_id = intval($_POST['booking_id'] ?? 0);
                $stmt = $pdo->prepare("SELECT fb.user_id, f.name as farm_name FROM farm_bookings fb JOIN farms f ON fb.farm_id = f.id WHERE fb.id = ?");
                $stmt->execute([$booking_id]);
                $booking = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($booking) {
                    $stmt = $pdo->prepare("UPDATE farm_bookings SET status = 'rejected' WHERE id = ?");
                    $stmt->execute([$booking_id]);
                    addNotification($pdo, $booking['user_id'], 'farm', '❌ تم رفض حجز المزرعة', 'تم رفض طلب حجزك للمزرعة "' . $booking['farm_name'] . '".');
                    sendBotDM($pdo, $booking['user_id'], '❌ تم رفض حجز المزرعة', 'تم رفض طلب حجزك للمزرعة "' . $booking['farm_name'] . '".');
                    $response = ['success' => true, 'message' => 'تم رفض الحجز'];
                } else {
                    $response = ['success' => false, 'message' => 'الحجز غير موجود'];
                }
            }
        }
        else {
            $response = ['success' => false, 'message' => 'إجراء غير معروف'];
        }
    } catch (PDOException $e) {
        error_log('Database error in index.php POST: ' . $e->getMessage());
        $response = ['success' => false, 'message' => 'حدث خطأ في قاعدة البيانات: ' . $e->getMessage()];
    } catch (Exception $e) {
        error_log('General error in index.php POST: ' . $e->getMessage());
        $response = ['success' => false, 'message' => 'حدث خطأ غير متوقع: ' . $e->getMessage()];
    }

    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// ====== جلب البيانات من قاعدة البيانات ======
$products = [];
$apps = [];
$submissions = [];
$users = [];
$allRoles = [];
$jobs = [];
$properties = [];
$vehicles = [];
$sliders = [];
$memberCount = 0;
$farms = [];
$farmBookings = [];

try {
    $stmt = $pdo->prepare("SELECT * FROM products");
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب المنتجات: ' . $e->getMessage());
}

try {
    $stmt = $pdo->prepare("SELECT * FROM application_types");
    $stmt->execute();
    $apps = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب أنواع التقديم: ' . $e->getMessage());
}

foreach ($apps as &$app) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM application_questions WHERE type_id = ?");
        $stmt->execute([$app['id']]);
        $app['questions'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $app['questions'] = [];
        error_log('Error fetching questions for app ' . $app['id'] . ': ' . $e->getMessage());
    }
}
unset($app);

try {
    $stmt = $pdo->prepare("
        SELECT s.*, u.username as user_name, a.name as type_name, a.manager_role_key
        FROM submissions s
        JOIN users u ON s.user_id = u.id
        JOIN application_types a ON s.type_id = a.id
        ORDER BY s.created_at DESC
    ");
    $stmt->execute();
    $submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب التقديمات: ' . $e->getMessage());
}

try {
    $stmt = $pdo->prepare("SELECT * FROM users");
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب المستخدمين: ' . $e->getMessage());
}

try {
    $stmt = $pdo->prepare("SELECT * FROM roles ORDER BY sort_order");
    $stmt->execute();
    $allRoles = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب الرتب: ' . $e->getMessage());
}

try {
    $stmt = $pdo->prepare("SELECT * FROM job_titles ORDER BY name");
    $stmt->execute();
    $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب الوظائف: ' . $e->getMessage());
}

foreach ($users as &$u) {
    try {
        $rstmt = $pdo->prepare("SELECT role_id FROM user_roles WHERE user_id = ?");
        $rstmt->execute([$u['id']]);
        $u['role_ids'] = array_map('intval', $rstmt->fetchAll(PDO::FETCH_COLUMN));
    } catch (PDOException $e) {
        $u['role_ids'] = [];
        error_log('Error fetching roles for user ' . $u['id'] . ': ' . $e->getMessage());
    }
    
    try {
        $jstmt = $pdo->prepare("SELECT job_id FROM user_jobs WHERE user_id = ?");
        $jstmt->execute([$u['id']]);
        $u['job_ids'] = array_map('intval', $jstmt->fetchAll(PDO::FETCH_COLUMN));
    } catch (PDOException $e) {
        $u['job_ids'] = [];
        error_log('Error fetching jobs for user ' . $u['id'] . ': ' . $e->getMessage());
    }
}
unset($u);

try {
    $stmt = $pdo->prepare("SELECT * FROM properties ORDER BY created_at DESC");
    $stmt->execute();
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب العقارات: ' . $e->getMessage());
}

try {
    $stmt = $pdo->prepare("SELECT * FROM vehicles ORDER BY created_at DESC");
    $stmt->execute();
    $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب السيارات: ' . $e->getMessage());
}

try {
    $stmt = $pdo->prepare("SELECT * FROM sliders ORDER BY sort_order ASC");
    $stmt->execute();
    $sliders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('❌ خطأ في جلب السلايدر: ' . $e->getMessage());
}

try {
    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT ur.user_id)
        FROM user_roles ur
        JOIN roles r ON ur.role_id = r.id
        WHERE r.role_key = 'company_member'
    ");
    $stmt->execute();
    $memberCount = (int) $stmt->fetchColumn();
} catch (PDOException $e) {
    $memberCount = 0;
    error_log('Error fetching member count: ' . $e->getMessage());
}

// 🌾 جلب بيانات المزارع المتاحة فقط
try {
    $stmt = $pdo->prepare("SELECT * FROM farms WHERE is_active = 1 AND (available_from IS NULL OR available_from <= NOW()) ORDER BY name");
    $stmt->execute();
    $farms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $farms = [];
    error_log('Error fetching farms: ' . $e->getMessage());
}

// 🌾 جلب بيانات حجوزات المزارع
try {
    $stmt = $pdo->prepare("
        SELECT fb.*, u.username, f.name as farm_name 
        FROM farm_bookings fb
        JOIN users u ON fb.user_id = u.id
        JOIN farms f ON fb.farm_id = f.id
        ORDER BY fb.created_at DESC
    ");
    $stmt->execute();
    $farmBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $farmBookings = [];
    error_log('Error fetching farm bookings: ' . $e->getMessage());
}

$isLoggedIn = isLoggedIn();
if ($isLoggedIn) {
    $user_id = $_SESSION['user_id'];
}

$currentUser = getCurrentUser();
if ($currentUser) {
    $currentUser['roles'] = getUserRolesFromDB($currentUser['id'], $pdo);
    $_SESSION['roles'] = $currentUser['roles'];
}
$userRoles = $currentUser['roles'] ?? [];

$admins = [];
if (in_array('founder', $userRoles, true) || in_array('admin', $userRoles, true) || in_array('farm_rental_manager', $userRoles, true) || in_array('housing_apps_manager', $userRoles, true)) {
    try {
        $stmt = $pdo->query("
            SELECT DISTINCT u.id, u.username 
            FROM users u
            JOIN user_roles ur ON u.id = ur.user_id
            JOIN roles r ON ur.role_id = r.id
            WHERE r.role_key IN ('founder', 'admin', 'company_apps_manager', 'housing_apps_manager', 'support_apps_manager', 'farm_rental_manager')
            ORDER BY u.username
        ");
        $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $admins = [];
        error_log('Error fetching admins: ' . $e->getMessage());
    }
}

$purchases = [];
if ($currentUser && (in_array('founder', $currentUser['roles'], true) || in_array('skin_designer', $currentUser['roles'], true) || in_array('engine_seller', $currentUser['roles'], true))) {
    try {
        $stmt = $pdo->prepare("
            SELECT p.*, u.username as user_name, pr.name as product_name, pr.category
            FROM purchases p
            JOIN users u ON p.user_id = u.id
            JOIN products pr ON p.product_id = pr.id
            ORDER BY p.created_at DESC
        ");
        $stmt->execute();
        $purchases = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $purchases = [];
        error_log('Error fetching purchases: ' . $e->getMessage());
    }
}

$notifications = [];
$unreadCount = 0;
if ($currentUser && $currentUser['id']) {
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM notifications 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT 50
        ");
        $stmt->execute([$currentUser['id']]);
        $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$currentUser['id']]);
        $unreadCount = (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        $notifications = [];
        $unreadCount = 0;
        error_log('Error fetching notifications: ' . $e->getMessage());
    }
}

$products = $products ?: [];
$apps = $apps ?: [];
$submissions = $submissions ?: [];
$users = $users ?: [];
$properties = $properties ?: [];
$vehicles = $vehicles ?: [];
$sliders = $sliders ?: [];

$csrfToken = generateCSRFToken();

$stats = [
    'submissions' => count($submissions),
    'pending' => count(array_filter($submissions, fn($s) => $s['status'] === 'pending')),
    'purchases' => count($purchases),
    'users' => count($users),
    'products' => count($products)
];

$safeCurrentUser = $currentUser ?: (object)[
    'id' => null,
    'username' => '',
    'avatar' => null,
    'discord_id' => null,
    'roles' => []
];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Italiano - شركة العائلة</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/Italiano/css/style.css">
</head>
<body>
<div id="app">

    <div class="notification" id="notification">
        <i class="fas fa-check-circle"></i>
        <span id="notification-text">تم التنفيذ بنجاح!</span>
    </div>

    <!-- ===== مودال عرض إجابات التقديم ===== -->
    <div class="modal-overlay" id="answersModal">
        <div class="modal-box">
            <h2>
                <span><i class="fas fa-list-alt"></i> مراجعة التقديم</span>
                <button class="close-btn" @click="closeAnswersModal"><i class="fas fa-times"></i></button>
            </h2>
            <div style="margin-bottom:15px;">
                <p><strong>المتقدم:</strong> {{ viewingSubmission ? viewingSubmission.user_name : '' }}</p>
                <p><strong>نوع التقديم:</strong> {{ viewingSubmission ? viewingSubmission.type_name : '' }}</p>
                <p><strong>الحالة:</strong> 
                    <span class="badge" :class="viewingSubmission && viewingSubmission.status === 'accepted' ? 'badge-open' : viewingSubmission && viewingSubmission.status === 'rejected' ? 'badge-closed' : ''">
                        {{ viewingSubmission ? (viewingSubmission.status === 'pending' ? '⏳ قيد المراجعة' : viewingSubmission.status === 'accepted' ? '✅ مقبول' : '❌ مرفوض') : '' }}
                    </span>
                </p>
            </div>
            <hr style="border-color:#ffffff20; margin:15px 0;">
            <h4 style="margin-bottom:15px;"><i class="fas fa-question-circle"></i> الإجابات:</h4>
            <div v-if="viewingAnswers && Object.keys(viewingAnswers).length > 0">
                <div class="answer-item" v-for="(answer, qid) in viewingAnswers" :key="qid">
                    <div class="q-text">{{ viewingQuestions[qid] || 'سؤال' }}:</div>
                    <div class="a-text">{{ answer || 'لا توجد إجابة' }}</div>
                </div>
            </div>
            <p v-else style="color:#94a3b8;">لا توجد إجابات مسجلة.</p>
            <div style="margin-top:20px; display:flex; gap:10px; justify-content:center; flex-wrap:wrap;">
                <button class="btn btn-success" @click="reviewSubmissionFromModal('accepted')" v-if="viewingSubmission && viewingSubmission.status === 'pending'">
                    <i class="fas fa-check"></i> قبول
                </button>
                <button class="btn btn-danger" @click="reviewSubmissionFromModal('rejected')" v-if="viewingSubmission && viewingSubmission.status === 'pending'">
                    <i class="fas fa-times"></i> رفض
                </button>
                <button class="btn btn-outline" @click="closeAnswersModal"><i class="fas fa-times"></i> إغلاق</button>
            </div>
        </div>
    </div>

    <!-- ===== مودال إضافة المنتج ===== -->
    <div class="modal-overlay" id="productModal">
        <div class="modal-box">
            <h2><span><i class="fas fa-plus-circle"></i> إضافة منتج جديد</span> <button class="close-btn" @click="closeProductModal"><i class="fas fa-times"></i></button></h2>
            <form @submit.prevent="saveProduct">
                <input type="hidden" name="csrf_token" :value="csrfToken">
                <div class="form-group">
                    <label>اسم المنتج</label>
                    <input type="text" v-model="newProduct.name" placeholder="أدخل اسم المنتج..." required>
                </div>
                <div class="form-group">
                    <label>السعر ($)</label>
                    <input type="number" v-model="newProduct.price" placeholder="0" required>
                </div>
                <div class="form-group">
                    <label>التصنيف</label>
                    <select v-model="newProduct.category">
                        <option value="male_skins">سكنات رجالي</option>
                        <option value="female_skins">سكنات حريمي</option>
                        <option value="engines">محركات</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>رقم IBAN (للتحويل البنكي)</label>
                    <input type="text" v-model="newProduct.iban" placeholder="مثال: SA1234567890...">
                </div>
                <div class="form-group">
                    <label>صورة المنتج</label>
                    <input type="file" accept="image/*" @change="onProductImageChange">
                </div>
                <button class="btn btn-primary" style="width:100%; margin-top:10px;" type="submit">
                    <i class="fas fa-save"></i> حفظ المنتج
                </button>
            </form>
        </div>
    </div>

    <!-- ===== مودال شراء المنتج ===== -->
    <div class="modal-overlay" id="purchaseModal">
        <div class="modal-box">
            <h2>
                <span><i class="fas fa-shopping-cart"></i> شراء المنتج</span>
                <button class="close-btn" @click="closePurchaseModal"><i class="fas fa-times"></i></button>
            </h2>
            <div v-if="purchasingProduct">
                <div style="background:#020205; padding:15px; border-radius:10px; margin-bottom:15px;">
                    <h3>{{ purchasingProduct.name }}</h3>
                    <p style="color:#fbbf24; font-size:24px; font-weight:bold;">${{ purchasingProduct.price }}</p>
                </div>
                <div style="background:#f59e0b20; border:1px solid #f59e0b40; border-radius:10px; padding:15px; margin-bottom:20px;">
                    <p style="color:#f59e0b; font-weight:bold;"><i class="fas fa-info-circle"></i> تعليمات الدفع:</p>
                    <p>يرجى تحويل المبلغ المطلوب إلى الرقم البنكي التالي:</p>
                    <p style="direction:ltr; text-align:left; background:#020205; padding:10px; border-radius:8px; font-family:monospace; font-size:18px; color:#10b981;">
                        {{ purchasingProduct.iban || 'لا يوجد IBAN محدد لهذا المنتج، يرجى التواصل مع الإدارة' }}
                    </p>
                </div>
                <form @submit.prevent="submitPurchase">
                    <input type="hidden" name="product_id" :value="purchasingProduct.id">
                    <div class="form-group">
                        <label>رفع إثبات الدفع (صورة)</label>
                        <input type="file" accept="image/*" @change="onPaymentImageChange" required>
                    </div>
                    <button type="submit" class="btn btn-success" style="width:100%;" :disabled="purchasingLoading">
                        <i class="fas fa-check-circle"></i> {{ purchasingLoading ? 'جاري الإرسال...' : 'تأكيد الدفع' }}
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- ===== مودال إضافة/تعديل سؤال ===== -->
    <div class="modal-overlay" id="questionModal">
        <div class="modal-box">
            <h2>
                <span><i class="fas fa-question-circle"></i> <span v-if="editingQuestion">تعديل</span><span v-else>إضافة</span> سؤال</span>
                <button class="close-btn" @click="closeQuestionModal"><i class="fas fa-times"></i></button>
            </h2>
            <form @submit.prevent="saveQuestion">
                <input type="hidden" name="csrf_token" :value="csrfToken">
                <input type="hidden" v-model="questionForm.id">
                <div class="form-group">
                    <label>نص السؤال</label>
                    <input type="text" v-model="questionForm.text" placeholder="أدخل نص السؤال...">
                </div>
                <div class="form-group">
                    <label>نوع السؤال</label>
                    <select v-model="questionForm.field_type" @change="onFieldTypeChange">
                        <option value="text">📝 نص قصير</option>
                        <option value="textarea">📄 فقرة</option>
                        <option value="number">🔢 رقم</option>
                        <option value="select">📋 اختيار من متعدد</option>
                        <option value="file">🖼️ رفع صورة</option>
                        <option value="url">🔗 رابط</option>
                    </select>
                </div>
                <div class="form-group" v-if="questionForm.field_type === 'select'">
                    <label>الخيارات</label>
                    <div v-for="(opt, idx) in questionForm.optionsArray" :key="idx" class="option-item">
                        <input type="text" v-model="questionForm.optionsArray[idx]" placeholder="خيار">
                        <button class="btn-sm btn-danger" @click.prevent="removeOption(idx)"><i class="fas fa-times"></i></button>
                    </div>
                    <button class="btn btn-primary" @click.prevent="addOption" style="margin-top:5px;"><i class="fas fa-plus"></i> إضافة خيار</button>
                </div>
                <div class="form-group checkbox-group">
                    <input type="checkbox" v-model="questionForm.required">
                    <label style="margin:0;">سؤال إلزامي</label>
                </div>
                <button class="btn btn-primary" style="width:100%; margin-top:10px;" type="submit">
                    <i class="fas fa-save"></i> حفظ
                </button>
            </form>
        </div>
    </div>

    <!-- ===== مودال إضافة/تعديل نوع تقديم ===== -->
    <div class="modal-overlay" id="appTypeModal">
        <div class="modal-box">
            <h2>
                <span><i class="fas fa-plus-circle"></i> <span v-if="editingAppType">تعديل</span><span v-else>إضافة</span> نوع تقديم</span>
                <button class="close-btn" @click="closeAppTypeModal"><i class="fas fa-times"></i></button>
            </h2>
            <form @submit.prevent="saveAppType">
                <input type="hidden" name="csrf_token" :value="csrfToken">
                <input type="hidden" v-model="appTypeForm.id">
                <div class="form-group">
                    <label>اسم التقديم</label>
                    <input type="text" v-model="appTypeForm.name" placeholder="مثلاً: بطولة التيمات الكبرى">
                </div>
                <div class="form-group">
                    <label>الوصف (اختياري)</label>
                    <textarea v-model="appTypeForm.description" placeholder="وصف هذا النوع من التقديم"></textarea>
                </div>
                <div class="form-group">
                    <label>رتبة المسؤول (اختياري)</label>
                    <select v-model="appTypeForm.manager_role_key">
                        <option value="">بدون مسؤول محدد</option>
                        <option v-for="r in rolesList" :key="r.id" :value="r.role_key">{{ r.role_name }}</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>الحد الأدنى لساعات اللعب</label>
                    <input type="number" v-model="appTypeForm.min_hours" placeholder="0">
                </div>
                <div class="form-group">
                    <label>الحد الأدنى للهيستوري</label>
                    <input type="number" v-model="appTypeForm.min_history" placeholder="0">
                </div>
                <div class="form-group">
                    <label>الحد الأدنى للفل</label>
                    <input type="number" v-model="appTypeForm.min_money" placeholder="0">
                </div>
                <div class="form-group">
                    <label>المتطلبات الإضافية (نص)</label>
                    <textarea v-model="appTypeForm.requirements" rows="4" placeholder="أكتب المتطلبات هنا..."></textarea>
                </div>
                <button class="btn btn-primary" style="width:100%; margin-top:10px;" type="submit">
                    <i class="fas fa-save"></i> حفظ
                </button>
            </form>
        </div>
    </div>

    <!-- ===== مودال إضافة صورة سلايدر ===== -->
    <div class="modal-overlay" id="sliderModal">
        <div class="modal-box">
            <h2>
                <span><i class="fas fa-image"></i> إضافة صورة سلايدر</span>
                <button class="close-btn" @click="closeSliderModal"><i class="fas fa-times"></i></button>
            </h2>
            <form @submit.prevent="saveSlider">
                <input type="hidden" name="csrf_token" :value="csrfToken">
                <div class="form-group">
                    <label>صورة السلايدر (1400×400 يفضل)</label>
                    <input type="file" accept="image/*" ref="sliderInput" @change="onSliderImageChange" required>
                </div>
                <div class="form-group">
                    <label>العنوان (اختياري)</label>
                    <input type="text" v-model="newSlider.title" placeholder="عنوان الصورة">
                </div>
                <div class="form-group">
                    <label>رابط (اختياري)</label>
                    <input type="url" v-model="newSlider.link" placeholder="https://example.com">
                </div>
                <button class="btn btn-primary" style="width:100%; margin-top:10px;" type="submit">
                    <i class="fas fa-save"></i> حفظ الصورة
                </button>
            </form>
        </div>
    </div>

    <!-- ===== مودال حجز المزرعة ===== -->
    <div class="modal-overlay" id="bookingModal">
        <div class="modal-box">
            <h2>
                <span><i class="fas fa-tractor"></i> حجز مزرعة</span>
                <button class="close-btn" @click="closeBookingModal"><i class="fas fa-times"></i></button>
            </h2>
            <div v-if="selectedFarm">
                <h3 style="margin-bottom:10px;">{{ selectedFarm.name }}</h3>
                <p style="color:var(--text-secondary);">{{ selectedFarm.location }}</p>
                
                <div style="background:var(--accent-glow); padding:15px; border-radius:10px; margin:15px 0;">
                    <h4 style="color:var(--accent);"><i class="fas fa-calendar-check"></i> تاريخ البدء التلقائي:</h4>
                    <p style="font-size:20px; font-weight:bold;">
                        {{ calculatedStartDate || 'جاري الحساب...' }}
                    </p>
                    <p style="font-size:13px; color:var(--text-secondary);">
                        سيتم حجز المزرعة تلقائياً في هذا التاريخ (اليوم التالي لانتهاء آخر حجز).
                    </p>
                </div>
                
                <div style="background:var(--bg-input); padding:15px; border-radius:10px; margin:15px 0;">
                    <p><strong>سعر اليوم:</strong> ${{ selectedFarm.price_per_day }}</p>
                    <p><strong>سعر المساعد/يوم:</strong> ${{ selectedFarm.assistant_price_per_day }}</p>
                </div>
                
                <form @submit.prevent="submitBooking">
                    <div class="form-group">
                        <label>عدد الأيام (1-3)</label>
                        <input type="number" v-model="bookingForm.days" min="1" max="3" required>
                    </div>
                    <div class="form-group">
                        <label>عدد المساعدين</label>
                        <input type="number" v-model="bookingForm.assistants" min="0" max="5">
                    </div>
                    <div style="background:var(--accent-glow); padding:15px; border-radius:10px; margin:15px 0;">
                        <h4>التكلفة التقديرية:</h4>
                        <p style="font-size:24px; font-weight:bold; color:var(--accent);">
                            ${{ estimatedCost }}
                        </p>
                    </div>
                    <button type="submit" class="btn btn-success" style="width:100%;" :disabled="bookingLoading || !calculatedStartDate">
                        <i class="fas fa-paper-plane"></i> {{ bookingLoading ? 'جاري الإرسال...' : 'إرسال طلب الحجز' }}
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- ===== مودال إضافة مزرعة ===== -->
    <div class="modal-overlay" id="addFarmModal">
        <div class="modal-box">
            <h2>
                <span><i class="fas fa-tractor"></i> إضافة مزرعة جديدة</span>
                <button class="close-btn" @click="closeAddFarmModal"><i class="fas fa-times"></i></button>
            </h2>
            <form @submit.prevent="saveFarm">
                <div class="form-group">
                    <label>اسم المزرعة *</label>
                    <input type="text" v-model="newFarm.name" required>
                </div>
                <div class="form-group">
                    <label>الموقع (اختياري)</label>
                    <input type="text" v-model="newFarm.location">
                </div>
                <div class="form-group">
                    <label>سعر اليوم ($) *</label>
                    <input type="number" v-model="newFarm.price_per_day" min="1" required>
                </div>
                <div class="form-group">
                    <label>سعر المساعد في اليوم ($) *</label>
                    <input type="number" v-model="newFarm.assistant_price_per_day" min="0" required>
                </div>
                <div class="form-group">
                    <label>صورة المزرعة</label>
                    <input type="file" accept="image/*" ref="farmImageInput" @change="onFarmImageChange">
                </div>
                <button class="btn btn-primary" style="width:100%; margin-top:10px;" type="submit">
                    <i class="fas fa-save"></i> حفظ المزرعة
                </button>
            </form>
        </div>
    </div>

    <!-- ===== الهيدر ===== -->
    <header class="header">
        <a href="/Italiano/index.php?tab=home" class="logo" style="display:flex; align-items:center; gap:10px; text-decoration:none;">
            <img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png?ver=2" alt="ITV - Italiano">
        </a>

        <nav class="nav">
            <a href="/Italiano/pages/rules.php?tab=rules"><i class="fas fa-gavel"></i> القوانين</a>
            <a href="/Italiano/index.php?tab=store" :class="{active: activeTab === 'store'}"><i class="fas fa-store"></i> المتجر</a>
            <a href="/Italiano/index.php?tab=applications" :class="{active: activeTab === 'applications'}"><i class="fas fa-file-signature"></i> التقديمات</a>
            <a href="/Italiano/index.php?tab=farms" :class="{active: activeTab === 'farms'}"><i class="fas fa-tractor"></i> المزارع</a>
            <a href="/Italiano/pages/members.php"><i class="fas fa-users"></i> الأعضاء</a>
        </nav>

        <div style="display:flex; align-items:center; gap:14px;">
            <div v-if="isLoggedIn" style="display:flex; align-items:center; gap:14px;">

                <div class="notif-container" v-clickoutside="closeNotifications">
                    <i class="fas fa-bell bell-btn" @click="toggleNotifications"></i>
                    <span class="bell-badge" v-if="unreadCount > 0">
                        {{ unreadCount > 99 ? '99+' : unreadCount }}
                    </span>
                    <div class="notif-dropdown" :class="{ show: showNotifications }">
                        <div class="notif-header">
                            <span style="font-weight:700; color:white; font-size:16px;">الإشعارات</span>
                            <div style="display:flex; gap:5px;">
                                <button @click.stop="markAllRead" class="btn btn-sm btn-outline" style="font-size:11px; padding:4px 14px; border-radius:20px; background:transparent; border:1px solid #ffffff20; color:#94a3b8; cursor:pointer;">
                                    تحديد الكل كمقروء
                                </button>
                                <button @click.stop="deleteReadNotifications" class="btn btn-sm btn-danger" style="font-size:11px; padding:4px 14px; border-radius:20px; background:#ef4444; color:white; border:none; cursor:pointer;">
                                    <i class="fas fa-trash"></i> حذف المقروءة
                                </button>
                            </div>
                        </div>
                        <div v-if="notifications.length === 0" class="notif-empty">
                            <i class="fas fa-bell-slash"></i>
                            لا توجد إشعارات
                        </div>
                        <div v-for="notif in notifications" :key="notif.id" 
                            class="notif-item" :class="{ unread: !notif.is_read }"
                            @click="markRead(notif.id)">
                            <div style="display:flex; gap:12px; align-items:flex-start;">
                                <div class="notif-icon">
                                    <i v-if="notif.type === 'delivery'" class="fas fa-box" style="color:#10b981;"></i>
                                    <i v-else-if="notif.type === 'ticket'" class="fas fa-headset" style="color:#f59e0b;"></i>
                                    <i v-else-if="notif.type === 'purchase'" class="fas fa-shopping-cart" style="color:#3b82f6;"></i>
                                    <i v-else class="fas fa-bell" style="color:#ce2b37;"></i>
                                </div>
                                <div style="flex:1;">
                                    <div class="notif-title">{{ notif.title }}</div>
                                    <div class="notif-message">{{ notif.message }}</div>
                                    <div class="notif-time">
                                        <i class="far fa-clock"></i> {{ formatDate(notif.created_at) }}
                                    </div>
                                    <div class="notif-link" v-if="notif.link">
                                        <a :href="notif.link" target="_blank" @click.stop>
                                            <i class="fas fa-external-link-alt"></i> عرض الرابط
                                        </a>
                                    </div>
                                </div>
                                <div class="notif-dot" v-if="!notif.is_read"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <a href="/Italiano/index.php?tab=profile" class="profile-wrapper">
                    <div class="avatar-container">
                        <img v-if="currentUser && currentUser.discord_id" 
                            :src="currentUser.avatar ? 'https://cdn.discordapp.com/avatars/' + currentUser.discord_id + '/' + currentUser.avatar + '.png?size=40' : 'https://cdn.discordapp.com/embed/avatars/' + (parseInt(currentUser.discord_id) % 5) + '.png'" 
                            alt="Profile"
                            @error="handleAvatarError">
                        <div v-else class="fallback">
                            {{ currentUser ? currentUser.username.charAt(0).toUpperCase() : 'U' }}
                        </div>
                        <span class="status-dot"></span>
                    </div>
                    <span class="profile-name">{{ currentUser ? currentUser.username : 'مستخدم' }}</span>
                </a>

                <a v-if="canAccessDashboard" href="/Italiano/index.php?tab=dashboard" 
                   class="dashboard-icon" title="لوحة التحكم">
                    <i class="fas fa-th"></i>
                </a>



            </div>
            <a v-else href="/Italiano/auth/discord.php" class="btn btn-discord">
                <i class="fab fa-discord"></i> دخول عبر ديسكورد
            </a>
        </div>
    </header>

    <!-- ===== السلايدر ===== -->
    <div class="slider-container" id="slider">
        <?php if (!empty($sliders)): ?>
            <?php foreach ($sliders as $index => $slide): ?>
                <?php if ($slide['is_active']): ?>
                    <img src="/Italiano/<?php echo htmlspecialchars($slide['image']); ?>" 
                         class="<?php echo $index === 0 ? 'active' : ''; ?>" 
                         alt="<?php echo htmlspecialchars($slide['title'] ?? 'Slider'); ?>"
                         <?php if (!empty($slide['link'])): ?>
                             onclick="window.location.href='<?php echo htmlspecialchars($slide['link']); ?>'"
                             style="cursor:pointer;"
                         <?php endif; ?>
                    >
                <?php endif; ?>
            <?php endforeach; ?>
        <?php else: ?>
            <img src="https://via.placeholder.com/1400x550/1a1a2e/ce2b37?text=Italiano+1" class="active" alt="Slider 1">
            <img src="https://via.placeholder.com/1400x550/2a2a3e/ce2b37?text=Italiano+2" alt="Slider 2">
            <img src="https://via.placeholder.com/1400x550/3a3a4e/ce2b37?text=Italiano+3" alt="Slider 3">
        <?php endif; ?>
    </div>

    <!-- ===== المحتوى ===== -->
    <div class="container">

        <!-- ===== الصفحة الرئيسية ===== -->
        <div class="tab" id="tab-home" :class="{active: activeTab === 'home'}">
            <div class="about-section" style="position:relative; overflow:hidden;">
                <div style="position:absolute; top:0; left:0; right:0; height:4px; display:flex; z-index:2;">
                    <span style="flex:1; background:#009246;"></span>
                    <span style="flex:1; background:#ffffff;"></span>
                    <span style="flex:1; background:#ce2b37;"></span>
                </div>
                <div style="position:relative; z-index:1;">
                    <h2>مرحباً بك في <span>Italiano</span></h2>
                        <p>
                        تعود أصول عائلة <strong>Italiano</strong> إلى إيطاليا، حيث اشتهرت عبر الأجيال بالانضباط، والشرف، والقيادة. ومع ازدياد الفرص داخل مدينة <strong>Los Santos</strong>، هاجرت العائلة إليها بهدف التطوير، والعمل، والتوسع في مختلف المجالات. وبفضل خبراتها وكفاءة أفرادها، استطاعت أن تثبت مكانتها داخل المدينة، حيث يشغل أبناؤها مناصب ومراتب قيادية في القطاعات الحكومية، والأمنية، والقضائية، والإدارية، إلى جانب ريادة الأعمال والاستثمارات. واليوم تُعد عائلة <strong>Italiano</strong> رمزًا للهيبة والاحترام، وتسعى دائمًا إلى بناء إرثٍ قوي قائم على الولاء، والاحترافية، وخدمة المدينة.
                        </p>                    <div style="display:flex; gap:15px; flex-wrap:wrap;">
                        <a href="/Italiano/index.php?tab=applications" style="display:inline-block; padding:14px 32px; background:#6866ff; color:white; border-radius:30px; font-weight:700; text-decoration:none; transition:0.3s; border:none; cursor:pointer; box-shadow:0 4px 20px rgba(104,102,255,0.3);">
                            <i class="fas fa-file-signature"></i> تقدم للانضمام
                        </a>
                        <a href="https://discord.gg/BdqPsR3ATm" target="_blank" style="display:inline-block; padding:14px 32px; background:#5865F2; color:white; border-radius:30px; font-weight:700; text-decoration:none; transition:0.3s; border:none; cursor:pointer; box-shadow:0 4px 20px rgba(88,101,242,0.3);">
                            <i class="fab fa-discord"></i> انضم لديسكورد العائلة
                        </a>
                    </div>
                </div>
            </div>

            <div class="grid" style="grid-template-columns: repeat(3, 1fr); margin-top:30px;">
                <a href="/Italiano/pages/members.php" class="card stat-card"><h3><i class="fas fa-users"></i> <?php echo htmlspecialchars($memberCount); ?></h3><p>عضو في العائلة</p></a>
                <a href="/Italiano/pages/properties.php" class="card stat-card"><h3><i class="fas fa-building"></i> <?php echo htmlspecialchars(count($properties)); ?></h3><p>عقار تملكه الشركة</p></a>
                <a href="/Italiano/pages/vehicles.php" class="card stat-card"><h3><i class="fas fa-car"></i> <?php echo htmlspecialchars(count($vehicles)); ?></h3><p>سيارة في الشركة</p></a>
            </div>

            <?php if (count($properties) > 0): ?>
            <div class="section-head">
                <h2><i class="fas fa-building"></i> ممتلكات الشركة</h2>
                <a href="/Italiano/pages/properties.php">عرض الكل <i class="fas fa-arrow-left"></i></a>
            </div>
            <div class="grid" style="grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));">
                <?php foreach (array_slice($properties, 0, 4) as $p): ?>
                <a class="mini-card" href="/Italiano/pages/properties.php">
                    <img src="/Italiano/<?php echo htmlspecialchars($p['image'] ?: 'https://via.placeholder.com/300x200/1a1a2e/ce2b37?text=Italiano'); ?>" alt="">
                    <div class="mini-body"><h4><?php echo htmlspecialchars($p['name']); ?></h4></div>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if (count($vehicles) > 0): ?>
            <div class="section-head">
                <h2><i class="fas fa-car"></i> سيارات الشركة</h2>
                <a href="/Italiano/pages/vehicles.php">عرض الكل <i class="fas fa-arrow-left"></i></a>
            </div>
            <div class="grid" style="grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));">
                <?php foreach (array_slice($vehicles, 0, 4) as $v): ?>
                <a class="mini-card" href="/Italiano/pages/vehicles.php">
                    <img src="/Italiano/<?php echo htmlspecialchars($v['image'] ?: 'https://via.placeholder.com/300x200/1a1a2e/ce2b37?text=Italiano'); ?>" alt="">
                    <div class="mini-body"><h4><?php echo htmlspecialchars($v['name']); ?></h4></div>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- ===== المتجر ===== -->
        <div class="tab" id="tab-store" :class="{active: activeTab === 'store'}">
            <?php
            $showAddButton = false;
            if ($isLoggedIn && $currentUser) {
                $userRoles = $currentUser['roles'] ?? [];
                if (in_array('founder', $userRoles, true) || in_array('skin_designer', $userRoles, true) || in_array('engine_seller', $userRoles, true)) {
                    $showAddButton = true;
                }
            }
            ?>

            <div style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 20px; width:100%;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                    <h2><i class="fas fa-store"></i> المتجر</h2>
                    <?php if ($showAddButton): ?>
                        <button class="btn btn-primary" onclick="document.getElementById('productModal').classList.add('active')">
                            <i class="fas fa-plus"></i> إضافة منتج
                        </button>
                    <?php endif; ?>
                </div>
                
                <div style="display: flex; gap: 10px; flex-wrap:wrap; border-bottom: 1px solid #ffffff20; padding-bottom: 10px;">
                    <button class="btn btn-outline" :class="{'active': filterCategory === 'all'}" @click="filterCategory='all'">الكل</button>
                    <button class="btn btn-outline" :class="{'active': filterCategory === 'skins' || filterCategory === 'male_skins' || filterCategory === 'female_skins'}" @click="filterCategory='skins'">السكنات</button>
                    <button class="btn btn-outline" :class="{'active': filterCategory === 'engines'}" @click="filterCategory='engines'">محركات</button>
                </div>

                <div v-if="filterCategory === 'skins' || filterCategory === 'male_skins' || filterCategory === 'female_skins'" style="display: flex; gap: 10px; flex-wrap:wrap; margin-top: 5px;">
                    <button class="btn btn-sm btn-outline" :class="{'active': filterCategory === 'skins'}" @click="filterCategory='skins'">كل السكنات</button>
                    <button class="btn btn-sm btn-outline" :class="{'active': filterCategory === 'male_skins'}" @click="filterCategory='male_skins'">رجالي</button>
                    <button class="btn btn-sm btn-outline" :class="{'active': filterCategory === 'female_skins'}" @click="filterCategory='female_skins'">حريمي</button>
                </div>
            </div>

            <div class="grid">
                <div class="product-card" v-for="p in filteredProducts" :key="p.id">
                    <button class="delete-btn" v-if="isFounder || isSkinDesigner || isEngineSeller" @click="deleteProduct(p.id)"><i class="fas fa-trash"></i></button>
                    <img :src="p.image ? '/Italiano/' + p.image : 'https://via.placeholder.com/300x180/1a1a2e/ce2b37?text=منتج'" alt="">
                    <div class="product-body">
                        <span class="badge" :class="p.status === 'available' ? 'badge-open' : p.status === 'pending' ? 'badge-pending' : 'badge-closed'">
                            {{ p.status === 'available' ? 'متاح' : p.status === 'pending' ? 'قيد المراجعة' : 'تم البيع' }}
                        </span>
                        <h3>{{ p.name }}</h3>
                        <p style="color:#94a3b8; font-size:14px;">
                            {{ p.category === 'male_skins' ? 'رجالي' : p.category === 'female_skins' ? 'حريمي' : p.category === 'engines' ? 'محركات' : p.category }}
                        </p>
                        <div class="price">${{ p.price }}</div>
                        <button class="btn btn-primary" style="width:100%; margin-top:10px;" 
                                @click="openPurchaseModal(p)" 
                                :disabled="p.status !== 'available'">
                            <i class="fas fa-shopping-cart"></i> {{ p.status === 'available' ? 'شراء الآن' : 'غير متاح' }}
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== التقديمات ===== -->
        <div class="tab" id="tab-applications" :class="{active: activeTab === 'applications'}">
            <h2><i class="fas fa-file-signature"></i> التقديمات</h2>
            <p style="color:#94a3b8; margin-bottom:20px;">قدم على مختلف المناصب والأدوار داخل مجتمعنا. اختر تقديمًا أدناه للبدء.</p>
            <div class="grid" style="grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); margin-top: 20px;">
                <div class="card" v-for="app in applicationTypes" :key="app.id">
                    <h3>{{ app.name }}</h3>
                    <span class="badge" :class="app.is_open ? 'badge-open' : 'badge-closed'">
                        {{ app.is_open ? 'مفتوح' : 'مغلق' }}
                    </span>
                    <p style="color:#94a3b8; margin: 15px 0;">{{ app.description || 'تقديم' }}</p>
                    <button class="btn btn-outline" style="width:100%;" @click="goTo('/Italiano/pages/application_detail.php?id=' + app.id)">
                        <i class="fas fa-info-circle"></i> عرض التفاصيل
                    </button>
                    <button class="btn btn-outline" style="margin-top:10px; width:100%;" v-if="canManageAppType(app.manager_role_key)" @click="toggleApp(app.id)">
                        {{ app.is_open ? 'إغلاق التقديم' : 'فتح التقديم' }}
                    </button>
                </div>
            </div>
        </div>

        <!-- ===== المزارع ===== -->
        <div class="tab" id="tab-farms" :class="{active: activeTab === 'farms'}">
            <h2><i class="fas fa-tractor"></i> تأجير المزارع</h2>
            <p style="color:var(--text-secondary); margin-bottom:20px;">اختر مزرعة واحجزها لفترة تصل إلى 3 أيام مع إمكانية إضافة مساعدين. (نظام حجز تسلسلي تلقائي)</p>
            
            <div class="grid" id="farm-list">
                <div class="card" v-for="farm in farms" :key="farm.id">
                    <img :src="farm.image ? '/Italiano/' + farm.image : 'https://via.placeholder.com/300x200/cccccc/333?text=مزرعة'" alt="مزرعة" style="width:100%; height:180px; object-fit:cover; border-radius:10px; margin-bottom:10px;">
                    <h3>{{ farm.name }}</h3>
                    <p style="color:var(--text-secondary);">{{ farm.location || 'لا يوجد موقع محدد' }}</p>
                    <div style="display:flex; justify-content:space-between; margin:10px 0;">
                        <span><i class="fas fa-dollar-sign"></i> السعر/يوم: {{ farm.price_per_day }}</span>
                        <span><i class="fas fa-user-plus"></i> المساعد/يوم: {{ farm.assistant_price_per_day }}</span>
                    </div>
                    <button class="btn btn-primary" @click="openBookingModal(farm)" style="width:100%;">
                        <i class="fas fa-calendar-plus"></i> حجز الآن
                    </button>
                </div>
            </div>
            <p v-if="farms.length === 0" style="color:var(--text-secondary); text-align:center; padding:40px 0;">لا توجد مزارع متاحة حالياً.</p>
        </div>

        <!-- ===== البروفايل ===== -->
        <div class="tab" id="tab-profile" :class="{active: activeTab === 'profile'}">
            <div class="profile-container">
                <div class="profile-card-new">
                    <div class="avatar-big">
                        <img v-if="currentUser && currentUser.discord_id" 
                            :src="currentUser.avatar ? 'https://cdn.discordapp.com/avatars/' + currentUser.discord_id + '/' + currentUser.avatar + '.png?size=120' : 'https://cdn.discordapp.com/embed/avatars/' + (parseInt(currentUser.discord_id) % 5) + '.png'" 
                            alt="Avatar"
                            @error="handleAvatarError">
                        <span v-else>{{ currentUser ? currentUser.username.charAt(0).toUpperCase() : 'U' }}</span>
                    </div>
                    
                    <div class="username">{{ currentUser ? currentUser.username : 'مستخدم' }}</div>
                    
                    <div class="discord-id">
                        <i class="fab fa-discord"></i> {{ currentUser ? currentUser.discord_id || 'غير مرتبط' : '' }}
                    </div>
                    
                    <div class="role-badges">
                        <span class="role-badge" v-for="rk in (currentUser.roles || [])" :key="rk">{{ roleLabel(rk) }}</span>
                    </div>
                    
                    <hr class="divider">
                    
                    <div style="text-align: center; color: #94a3b8; padding: 10px 0; border-top: 1px solid #ffffff10; margin-top: 15px;">
                        <i class="fas fa-info-circle" style="color: #ce2b37;"></i> 
                        الاسم المعروض هو اسم حسابك في Discord ولا يمكن تغييره.
                        <br><br>
                        <span style="color: #f59e0b;"><i class="fas fa-exclamation-triangle"></i> تنبيه:</span>
                        لاستلام إشعارات البوت، تأكد من أنك تسمح باستقبال الرسائل الخاصة من أعضاء السيرفر في إعدادات Discord.
                        إذا كنت تواجه مشكلة في استلام الرسائل، يرجى فتح DMs من إعدادات الخصوصية.
                    </div>
                    
                    <div class="btn-actions" style="margin-top: 15px;">
                        <a href="/Italiano/pages/logout.php" class="btn btn-logout"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===== لوحة التحكم ===== -->
        <div class="tab" id="tab-dashboard" :class="{active: activeTab === 'dashboard'}">
            <h2><i class="fas fa-cog"></i> لوحة التحكم</h2>
            <p style="color:#94a3b8; margin-bottom:20px;">نظرة عامة سريعة على إحصائيات الموقع.</p>
            
            <div class="dashboard-grid-new">
                <div class="dash-card" @click="dashSection = 'submissions'" v-if="canViewSubmissions">
                    <div class="dash-icon"><i class="fas fa-file-signature"></i></div>
                    <div class="dash-number">{{ stats.submissions }}</div>
                    <div class="dash-label">جميع الطلبات</div>
                </div>
                <div class="dash-card" @click="dashSection = 'pending'" v-if="canViewSubmissions">
                    <div class="dash-icon"><i class="fas fa-clock" style="color:#f59e0b;"></i></div>
                    <div class="dash-number">{{ stats.pending }}</div>
                    <div class="dash-label">قيد المراجعة</div>
                </div>
                <div class="dash-card" @click="dashSection = 'purchases'; fetchPurchases()" v-if="isFounder || isSkinDesigner || isEngineSeller">
                    <div class="dash-icon"><i class="fas fa-receipt" style="color:#3b82f6;"></i></div>
                    <div class="dash-number">{{ stats.purchases }}</div>
                    <div class="dash-label">طلبات الشراء</div>
                </div>
                <div class="dash-card" @click="dashSection = 'users'" v-if="isFounder">
                    <div class="dash-icon"><i class="fas fa-users" style="color:#8b5cf6;"></i></div>
                    <div class="dash-number">{{ stats.users }}</div>
                    <div class="dash-label">المستخدمين</div>
                </div>
                <div class="dash-card" @click="dashSection = 'manage_questions'" v-if="isFounder">
                    <div class="dash-icon"><i class="fas fa-boxes" style="color:#f59e0b;"></i></div>
                    <div class="dash-number">{{ stats.products }}</div>
                    <div class="dash-label">تعديل الأسئلة</div>
                </div>
                <div class="dash-card" @click="dashSection = 'sliders'; fetchSliders()" v-if="isFounder">
                    <div class="dash-icon"><i class="fas fa-images" style="color:#ef4444;"></i></div>
                    <div class="dash-number">{{ slidersList.length }}</div>
                    <div class="dash-label">السلايدر</div>
                </div>
                <div class="dash-card" @click="dashSection = 'app_types'; fetchAppTypes()" v-if="isFounder">
                    <div class="dash-icon"><i class="fas fa-layer-group" style="color:#06b6d4;"></i></div>
                    <div class="dash-number">{{ applicationTypes.length }}</div>
                    <div class="dash-label">أنواع التقديم</div>
                </div>
                <div class="dash-card" @click="dashSection = 'products'" v-if="isFounder || isSkinDesigner || isEngineSeller">
                    <div class="dash-icon"><i class="fas fa-boxes" style="color:#f59e0b;"></i></div>
                    <div class="dash-number">{{ products.length }}</div>
                    <div class="dash-label">إدارة المنتجات</div>
                </div>
                <div class="dash-card" @click="dashSection = 'farm_management'" v-if="isFarmManager || isFounder">
                    <div class="dash-icon"><i class="fas fa-tractor" style="color:#28a745;"></i></div>
                    <div class="dash-number">{{ farmBookingsCount }}</div>
                    <div class="dash-label">إدارة المزارع</div>
                </div>
            </div>

            <div style="margin-top:30px;">
                <!-- ===== الطلبات ===== -->
                <div v-if="(dashSection === 'submissions' || dashSection === 'pending' || dashSection === 'accepted' || dashSection === 'rejected') && canViewSubmissions">
                    <h3 v-if="dashSection === 'submissions'"><i class="fas fa-list"></i> جميع الطلبات</h3>
                    <h3 v-if="dashSection === 'pending'"><i class="fas fa-clock"></i> قيد المراجعة</h3>
                    <h3 v-if="dashSection === 'accepted'"><i class="fas fa-check-circle"></i> المقبولة</h3>
                    <h3 v-if="dashSection === 'rejected'"><i class="fas fa-times-circle"></i> المرفوضة</h3>
                    <div class="submission-item" v-for="sub in filteredSubmissionsBySection" :key="sub.id">
                        <div class="info">
                            <strong>{{ sub.user_name || 'مستخدم' }}</strong>
                            <span style="color:#94a3b8;">{{ sub.type_name || 'تقديم' }}</span>
                            <span class="badge" :class="{'badge-open': sub.status === 'accepted', 'badge-closed': sub.status === 'rejected'}">
                                {{ sub.status === 'pending' ? '⏳ قيد المراجعة' : sub.status === 'accepted' ? '✅ مقبول' : '❌ مرفوض' }}
                            </span>
                        </div>
                        <div class="actions">
                            <button class="btn btn-outline" @click="viewAnswers(sub.id)"><i class="fas fa-eye"></i> عرض</button>
                            <button class="btn btn-success" @click="reviewSubmission(sub.id, 'accepted')" v-if="canManageSubmission(sub) && sub.status === 'pending'"><i class="fas fa-check"></i> قبول</button>
                            <button class="btn btn-danger" @click="reviewSubmission(sub.id, 'rejected')" v-if="canManageSubmission(sub) && sub.status === 'pending'"><i class="fas fa-times"></i> رفض</button>
                            <button class="btn btn-danger" @click="deleteSubmission(sub.id)" v-if="canManageSubmission(sub)">
                                <i class="fas fa-trash"></i> حذف
                            </button>
                        </div>
                    </div>
                    <p v-if="filteredSubmissionsBySection.length === 0" style="color:#94a3b8;">لا يوجد طلبات هنا حالياً.</p>
                </div>

                <!-- ===== طلبات الشراء ===== -->
                <div v-if="dashSection === 'purchases'">
                    <h3><i class="fas fa-receipt"></i> طلبات الشراء</h3>
                    <p style="color:#94a3b8; margin-bottom:15px;">مراجعة طلبات الشراء وتأكيدها أو إرسال رابط التسليم.</p>
                    <div class="purchase-item" v-for="purchase in purchasesList" :key="purchase.id">
                        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                            <div>
                                <strong>#{{ purchase.id }} - {{ purchase.product_name }}</strong>
                                <span class="badge" :class="purchase.status === 'pending' ? 'badge-pending' : purchase.status === 'approved' ? 'badge-open' : purchase.status === 'delivered' ? 'badge-resolved' : 'badge-closed'">
                                    {{ purchase.status === 'pending' ? '⏳ قيد المراجعة' : purchase.status === 'approved' ? '✅ تم التأكيد' : purchase.status === 'delivered' ? '📦 تم التسليم' : '❌ مرفوض' }}
                                </span>
                                <span style="color:#94a3b8; font-size:13px; margin-right:10px;">
                                    <i class="fas fa-user"></i> {{ purchase.user_name }}
                                </span>
                                <span style="color:#fbbf24; font-size:14px; font-weight:bold; margin-right:10px;">
                                    ${{ purchase.amount }}
                                </span>
                            </div>
                            <small style="color:#94a3b8;">{{ formatDate(purchase.created_at) }}</small>
                        </div>
                        <div v-if="purchase.payment_image" style="margin:10px 0;">
                            <a :href="'/Italiano/' + purchase.payment_image" target="_blank" style="color:#ce2b37;">
                                <i class="fas fa-image"></i> عرض إثبات الدفع
                            </a>
                            <img :src="'/Italiano/' + purchase.payment_image" style="max-height:100px; border-radius:8px; margin-top:5px; display:block;" alt="إثبات الدفع">
                        </div>
                        <div v-if="purchase.delivery_link && purchase.status === 'delivered'" style="background:#10b98120; border:1px solid #10b98140; border-radius:10px; padding:12px; margin:10px 0;">
                            <strong style="color:#10b981;"><i class="fas fa-check-circle"></i> تم التسليم!</strong>
                            <p style="color:#94a3b8; margin-top:5px;">
                                <strong>رابط السكن:</strong> 
                                <a :href="purchase.delivery_link" target="_blank" style="color:#10b981; text-decoration:underline;">{{ purchase.delivery_link }}</a>
                            </p>
                        </div>
                        <div v-if="purchase.admin_notes" style="background:#020205; padding:8px; border-radius:8px; margin:5px 0; color:#94a3b8;">
                            <strong>ملاحظات الإدارة:</strong> {{ purchase.admin_notes }}
                        </div>
                        <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:10px;" v-if="isFounder || isSkinDesigner || isEngineSeller">
                            <button class="btn btn-success btn-sm" @click="updatePurchase(purchase.id, 'approved', '', '')" v-if="purchase.status === 'pending'">
                                <i class="fas fa-check"></i> تأكيد الدفع
                            </button>
                            <button class="btn btn-danger btn-sm" @click="updatePurchase(purchase.id, 'rejected', '', '')" v-if="purchase.status === 'pending'">
                                <i class="fas fa-times"></i> رفض
                            </button>
                            <button class="btn btn-danger btn-sm" @click="deletePurchase(purchase.id)">
                                <i class="fas fa-trash"></i> حذف
                            </button>
                        </div>
                        <div v-if="isFounder || isSkinDesigner && purchase.status === 'approved' && (purchase.category === 'male_skins' || purchase.category === 'female_skins')" style="margin-top:10px; background:#020205; padding:10px; border-radius:10px; border:1px solid #f59e0b30;">
                            <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                                <input type="text" v-model="purchase.delivery_link_temp" placeholder="رابط السكن للتسليم" style="flex:1; padding:8px; background:#0a0a0f; border:1px solid #ffffff20; border-radius:8px; color:white; min-width:200px;">
                                <button class="btn btn-primary btn-sm" @click="updatePurchase(purchase.id, 'delivered', purchase.delivery_link_temp, '')">
                                    <i class="fas fa-link"></i> إرسال الرابط وتسليم
                                </button>
                            </div>
                        </div>
                        <div style="margin-top:5px;">
                            <span style="color:#94a3b8; font-size:13px;">
                                <i class="fas fa-user"></i> للتواصل مع المستخدم: <strong>{{ purchase.user_name }}</strong>
                            </span>
                        </div>
                    </div>
                    <p v-if="purchasesList.length === 0" style="color:#94a3b8; text-align:center; padding:20px;">لا توجد طلبات شراء.</p>
                </div>

                <!-- ===== السلايدر ===== -->
                <div v-if="dashSection === 'sliders'">
                    <h3><i class="fas fa-images"></i> إدارة السلايدر</h3>
                    <p style="color:#94a3b8; margin-bottom:15px;">إضافة وإدارة صور السلايدر التي تظهر في الصفحة الرئيسية.</p>
                    <button class="btn btn-primary" @click="openSliderModal" style="margin-bottom:15px;">
                        <i class="fas fa-plus"></i> إضافة صورة جديدة
                    </button>
                    <div v-for="slide in slidersList" :key="slide.id" class="slider-item">
                        <img :src="'/Italiano/' + slide.image" :alt="slide.title || 'Slider'">
                        <div class="slider-info">
                            <div class="title">{{ slide.title || 'بدون عنوان' }}</div>
                            <div class="link" v-if="slide.link">{{ slide.link }}</div>
                            <div style="display:flex; gap:8px; margin-top:4px; flex-wrap:wrap;">
                                <span class="badge" :class="slide.is_active ? 'badge-open' : 'badge-closed'">
                                    {{ slide.is_active ? 'مفعل' : 'غير مفعل' }}
                                </span>
                                <span style="color:#94a3b8; font-size:12px;">ترتيب: {{ slide.sort_order }}</span>
                            </div>
                        </div>
                        <div style="display:flex; gap:8px; flex-wrap:wrap;">
                            <button class="btn btn-sm btn-warning" @click="toggleSliderStatus(slide.id, slide.is_active)">
                                {{ slide.is_active ? 'إلغاء التفعيل' : 'تفعيل' }}
                            </button>
                            <button class="btn btn-sm btn-danger" @click="deleteSlider(slide.id)">
                                <i class="fas fa-trash"></i> حذف
                            </button>
                        </div>
                    </div>
                    <p v-if="slidersList.length === 0" style="color:#94a3b8; text-align:center; padding:20px;">لا توجد صور سلايدر مضافة.</p>
                </div>

                <!-- ===== المستخدمين ===== -->
                <div v-if="dashSection === 'users'">
                    <h3><i class="fas fa-users-cog"></i> إدارة المستخدمين</h3>
                    <p style="color:#94a3b8; margin-bottom:15px;">إدارة رتب الموقع والوظائف:</p>
                    <div class="card" v-for="user in usersList" :key="user.id" style="margin-bottom:15px;">
                        <strong>{{ user.username }}</strong>
                        <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:12px;">
                            <label class="role-checkbox" v-for="r in rolesList" :key="r.id">
                                <input type="checkbox" :checked="user.role_ids.includes(r.id)" @change="toggleUserRole(user, r.id)">
                                {{ r.role_name }}
                            </label>
                            <label class="role-checkbox job-checkbox" v-for="j in jobsList" :key="j.id">
                                <input type="checkbox" :checked="user.job_ids && user.job_ids.includes(j.id)" @change="toggleUserJob(user, j.id)">
                                <i class="fas fa-briefcase"></i> {{ j.name }}
                            </label>
                        </div>
                    </div>
                </div>

                <!-- ===== تعديل الأسئلة ===== -->
                <div v-if="dashSection === 'manage_questions'">
                    <h3><i class="fas fa-edit"></i> تعديل الأسئلة</h3>
                    <p style="color:#94a3b8;">أضف أو عدل أسئلة أي نموذج تقديم:</p>
                    <div class="card" v-for="app in applicationTypes" :key="app.id" style="margin-bottom:15px;">
                        <h4>{{ app.name }}</h4>
                        <div v-for="(q, idx) in app.questions" style="display:flex; gap:10px; align-items:center; background:#020205; padding:10px; border-radius:10px; margin-bottom:8px; flex-wrap:wrap;">
                            <span>{{ idx+1 }}.</span>
                            <input type="text" v-model="q.question_text" style="flex:1; background:transparent; border:1px solid #ffffff20; padding:8px; border-radius:8px; color:white; min-width:120px;">
                            <select v-model="q.field_type" style="background:#020205; border:1px solid #ffffff20; padding:8px; border-radius:8px; color:white;">
                                <option value="text">نص قصير</option>
                                <option value="textarea">فقرة</option>
                                <option value="number">رقم</option>
                                <option value="select">اختيار من متعدد</option>
                                <option value="file">رفع صورة</option>
                                <option value="url">رابط</option>
                            </select>
                            <input v-if="q.field_type === 'select'" type="text" placeholder="خيارات" v-model="q.options" style="background:#020205; border:1px solid #ffffff20; padding:8px; border-radius:8px; color:white; min-width:120px;">
                            <label style="display:flex; align-items:center; gap:5px; font-size:12px;">
                                <input type="checkbox" v-model="q.required"> إلزامي
                            </label>
                            <button class="btn btn-primary" @click="editQuestion(app.id, idx)"><i class="fas fa-pen"></i></button>
                            <button class="btn btn-danger" @click="removeQuestion(app.id, idx)"><i class="fas fa-trash"></i></button>
                        </div>
                        <button class="btn btn-primary" @click="addQuestion(app.id)"><i class="fas fa-plus"></i> إضافة سؤال</button>
                    </div>
                </div>

                <!-- ===== الوظائف ===== -->
                <div v-if="dashSection === 'jobs'">
                    <h3><i class="fas fa-briefcase"></i> إدارة الوظائف</h3>
                    <div style="display:flex; gap:10px; margin-bottom:15px;">
                        <input type="text" v-model="newJob" placeholder="اسم الوظيفة الجديدة (مثل: سائق، محاسب)" style="flex:1; padding:10px; background:#020205; border:1px solid #ffffff15; border-radius:10px; color:white;">
                        <button class="btn btn-primary" @click="addJob"><i class="fas fa-plus"></i> إضافة</button>
                    </div>
                    <div v-for="job in jobsList" :key="job.id" style="display:flex; justify-content:space-between; align-items:center; background:#0a0a0f; padding:10px; border-radius:10px; margin-bottom:8px;">
                        <span><i class="fas fa-briefcase"></i> {{ job.name }}</span>
                        <div>
                            <button class="btn btn-danger" @click="deleteJob(job.id)"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                    <p v-if="jobsList.length === 0" style="color:#94a3b8;">لا توجد وظائف مضافة بعد.</p>
                </div>

                <!-- ===== أنواع التقديم ===== -->
                <div v-if="dashSection === 'app_types'">
                    <h3><i class="fas fa-layer-group"></i> أنواع التقديم</h3>
                    <p style="color:#94a3b8; margin-bottom:15px;">إدارة أنواع التقديم المتاحة في الموقع:</p>
                    <button class="btn btn-primary" @click="openAppTypeModal()" style="margin-bottom:15px;"><i class="fas fa-plus"></i> إضافة نوع جديد</button>
                    <div v-for="app in applicationTypes" :key="app.id" style="display:flex; justify-content:space-between; align-items:center; background:#0a0a0f; padding:15px; border-radius:10px; margin-bottom:8px;">
                        <div>
                            <strong>{{ app.name }}</strong>
                            <span style="color:#94a3b8; margin-right:15px;">{{ app.description || '' }}</span>
                            <span class="badge" :class="app.is_open ? 'badge-open' : 'badge-closed'">{{ app.is_open ? 'مفتوح' : 'مغلق' }}</span>
                        </div>
                        <div>
                            <button class="btn btn-primary" @click="editAppType(app.id)"><i class="fas fa-pen"></i></button>
                            <button class="btn btn-danger" @click="deleteAppType(app.id)"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                </div>
                
                <!-- ===== إدارة المنتجات ===== -->
                <div v-if="dashSection === 'products'">
                    <h3><i class="fas fa-boxes"></i> إدارة المنتجات</h3>
                    <p style="color:#94a3b8; margin-bottom:15px;">تغيير حالة المنتجات (متاح، قيد المراجعة، تم البيع).</p>
                    <div v-for="p in products" :key="p.id" style="background:#0a0a0f; border:1px solid #ffffff10; border-radius:10px; padding:15px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                        <div>
                            <strong>{{ p.name }}</strong> - <span style="color:#94a3b8;">{{ p.category === 'male_skins' ? 'رجالي' : 'حريمي' }}</span>
                            <span class="badge" :class="p.status === 'available' ? 'badge-open' : p.status === 'pending' ? 'badge-pending' : 'badge-closed'">
                                {{ p.status === 'available' ? 'متاح' : p.status === 'pending' ? 'قيد المراجعة' : 'تم البيع' }}
                            </span>
                        </div>
                        <div style="display:flex; gap:8px; flex-wrap:wrap;">
                            <select v-model="p.status" @change="updateProductStatus(p.id, p.status)" style="background:#020205; border:1px solid #ffffff20; border-radius:8px; color:white; padding:6px 12px;">
                                <option value="available">متاح</option>
                                <option value="pending">قيد المراجعة</option>
                                <option value="sold">تم البيع</option>
                            </select>
                            <button class="btn btn-danger btn-sm" @click="deleteProduct(p.id)">
                                <i class="fas fa-trash"></i> حذف
                            </button>
                        </div>
                    </div>
                </div>

                <!-- ===== إدارة المزارع ===== -->
                <div v-if="dashSection === 'farm_management'">
                    <h3><i class="fas fa-tractor"></i> إدارة المزارع والحجوزات</h3>
                    <button class="btn btn-primary" @click="openAddFarmModal" style="margin:15px 0;">
                        <i class="fas fa-plus"></i> إضافة مزرعة جديدة
                    </button>
                    
                    <h4 style="margin-top:20px;">المزارع الحالية</h4>
                    <div v-for="farm in farms" :key="farm.id" style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:10px; padding:15px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                        <div style="display:flex; align-items:center; gap:15px;">
                            <img :src="farm.image ? '/Italiano/' + farm.image : 'https://via.placeholder.com/60/cccccc/333?text=مزرعة'" style="width:60px; height:60px; object-fit:cover; border-radius:8px;">
                            <div>
                                <strong>{{ farm.name }}</strong>
                                <span style="color:var(--text-secondary); margin-left:10px;">{{ farm.location }}</span>
                                <div style="font-size:13px; color:var(--text-secondary);">
                                    <span>السعر/يوم: ${{ farm.price_per_day }}</span>
                                    <span style="margin-left:15px;">المساعد/يوم: ${{ farm.assistant_price_per_day }}</span>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-danger" @click="deleteFarm(farm.id)"><i class="fas fa-trash"></i></button>
                    </div>
                    
                    <h4 style="margin-top:30px;">طلبات الحجز</h4>
                    <div v-for="booking in farmBookings" :key="booking.id" style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:10px; padding:15px; margin-bottom:10px;">
                        <div style="display:flex; justify-content:space-between; flex-wrap:wrap; gap:10px;">
                            <div>
                                <strong>{{ booking.farm_name }}</strong>
                                <span style="color:var(--text-secondary);"> - {{ booking.username }}</span>
                                <span class="badge" :class="{'badge-open': booking.status === 'approved', 'badge-closed': booking.status === 'rejected', 'badge-pending': booking.status === 'pending', 'badge-resolved': booking.status === 'completed'}">
                                    {{ booking.status === 'pending' ? 'قيد المراجعة' : booking.status === 'approved' ? 'مقبول' : booking.status === 'rejected' ? 'مرفوض' : 'مكتمل' }}
                                </span>
                            </div>
                            <small style="color:var(--text-secondary);">{{ formatDate(booking.created_at) }}</small>
                        </div>
                        <div style="display:flex; flex-wrap:wrap; gap:15px; margin-top:5px; color:var(--text-secondary);">
                            <span><i class="fas fa-calendar-alt"></i> من {{ booking.start_date }} إلى {{ booking.end_date }}</span>
                            <span><i class="fas fa-users"></i> مساعدين: {{ booking.assistants }}</span>
                            <span style="color:var(--accent); font-weight:bold;">التكلفة: ${{ booking.total_cost }}</span>
                        </div>
                        <div style="margin-top:10px; display:flex; gap:10px; flex-wrap:wrap;" v-if="booking.status === 'pending'">
                            <button class="btn btn-success" @click="approveBooking(booking.id)"><i class="fas fa-check"></i> قبول</button>
                            <button class="btn btn-danger" @click="rejectBooking(booking.id)"><i class="fas fa-times"></i> رفض</button>
                        </div>
                    </div>
                    <p v-if="farmBookings.length === 0" style="color:var(--text-secondary); text-align:center; padding:20px;">لا توجد حجوزات حالياً.</p>
                </div>
            </div>
        </div>

    </div>

    <!-- ===== الفوتر ===== -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-col">
                <div class="footer-logo">
                    <img src="/Italiano/images/ccb23a57d5d5e3a5ac1fe980c8a9543e.png" alt="Italiano" class="footer-logo-img">
                </div>
                <p class="footer-desc">
                    عائلة Italiano، واحدة من أعرق العائلات في عالم وناسة تايم. نقدم تجربة فريدة تجمع بين المتعة والإبداع.
                </p>
                <div class="footer-social">
                    <a href="https://discord.gg/BdqPsR3ATm" target="_blank" class="social-link"><i class="fab fa-discord"></i></a>
                    <a href="https://www.youtube.com/@Italiano" target="_blank" class="social-link"><i class="fab fa-youtube"></i></a>
                </div>
            </div>

            <div class="footer-col">
                <h4 class="footer-title">السيرفر</h4>
                <ul class="footer-links">
                    <li><a href="/Italiano/index.php?tab=store">المتجر</a></li>
                    <li><a href="/Italiano/index.php?tab=applications">التقديمات</a></li>
                    <li><a href="/Italiano/index.php?tab=farms">المزارع</a></li>
                </ul>
            </div>

            <div class="footer-col">
                <h4 class="footer-title">الدعم الفني</h4>
                <ul class="footer-links">
                    <li><a href="/Italiano/pages/rules.php?tab=rules">القوانين</a></li>
                    <li><a href="https://discord.gg/BdqPsR3ATm" target="_blank">ديسكورد</a></li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="footer-bottom-container">
                <span class="footer-copy">© 2026 Italiano. جميع الحقوق محفوظة.</span>
                <span class="footer-dev">تم التطوير بواسطة <strong>M_550</strong></span>
            </div>
        </div>
    </footer>

</div>

<script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
<script>
// ============================================================
// توجيه clickoutside
// ============================================================
Vue.directive('clickoutside', {
    bind(el, binding) {
        el.clickOutsideEvent = function(event) {
            if (!(el === event.target || el.contains(event.target))) {
                binding.value();
            }
        };
        document.addEventListener('click', el.clickOutsideEvent);
    },
    unbind(el) {
        document.removeEventListener('click', el.clickOutsideEvent);
    }
});

// ============================================================
// بيانات Vue
// ============================================================
var appData = {
    products: <?php echo json_encode($products, JSON_HEX_TAG); ?>,
    applicationTypes: <?php echo json_encode($apps, JSON_HEX_TAG); ?>,
    submissions: <?php echo json_encode($submissions, JSON_HEX_TAG); ?>,
    usersList: <?php echo json_encode($users, JSON_HEX_TAG); ?>,
    roles: <?php echo json_encode($allRoles, JSON_HEX_TAG); ?>,
    jobs: <?php echo json_encode($jobs, JSON_HEX_TAG); ?>,
    purchasesList: <?php echo json_encode($purchases, JSON_HEX_TAG); ?>,
    notifications: <?php echo json_encode($notifications, JSON_HEX_TAG); ?>,
    unreadCount: <?php echo $unreadCount; ?>,
    sliders: <?php echo json_encode($sliders, JSON_HEX_TAG); ?>,
    stats: <?php echo json_encode($stats, JSON_HEX_TAG); ?>,
    activeTab: <?php echo json_encode($activeTab); ?>,
    farms: <?php echo json_encode($farms, JSON_HEX_TAG); ?>,
    farmBookings: <?php echo json_encode($farmBookings, JSON_HEX_TAG); ?>
};

appData.applicationTypes.forEach(app => {
    if (!app.questions) app.questions = [];
});

var userData = {
    isLoggedIn: <?php echo $isLoggedIn ? 'true' : 'false'; ?>,
    currentUser: <?php echo json_encode($safeCurrentUser, JSON_HEX_TAG); ?>
};

var csrfToken = <?php echo json_encode($csrfToken, JSON_HEX_TAG); ?>;

new Vue({
    el: '#app',
    data: {
        isLoggedIn: userData.isLoggedIn,
        currentUser: userData.currentUser,
        activeTab: appData.activeTab || 'home',
        dashSection: 'submissions',
        selectedApp: null,
        filterCategory: 'all',
        products: appData.products,
        applicationTypes: appData.applicationTypes,
        submissions: appData.submissions,
        usersList: appData.usersList,
        rolesList: appData.roles,
        jobsList: appData.jobs,
        purchasesList: appData.purchasesList,
        csrfToken: csrfToken,
        adminsList: <?php echo json_encode($admins, JSON_HEX_TAG); ?>,

        notifications: appData.notifications,
        unreadCount: appData.unreadCount,
        showNotifications: false,

        slidersList: appData.sliders,
        newSlider: { title: '', link: '' },
        sliderImageFile: null,

        stats: appData.stats,

        purchasingProduct: null,
        purchasingLoading: false,
        paymentImageFile: null,

        questionForm: { id: null, text: '', field_type: 'text', optionsArray: [], required: false },
        editingQuestion: false,
        currentAppId: null,
        currentQuestionIdx: null,

        appTypeForm: { id: null, name: '', description: '', manager_role_key: '', min_hours: 0, min_history: 0, min_money: 0, requirements: '' },
        editingAppType: false,

        viewingSubmission: null,
        viewingAnswers: null,
        viewingQuestions: {},

        newProduct: { name: '', price: 0, category: 'male_skins', iban: '' },
        productImageFile: null,
        newJob: '',
        
        // بيانات المزارع
        farms: appData.farms,
        farmBookings: appData.farmBookings,
        selectedFarm: null,
        bookingForm: { days: 1, assistants: 0 },
        bookingLoading: false,
        newFarm: { name: '', location: '', price_per_day: 0, assistant_price_per_day: 0 },
        farmImageFile: null,
        calculatedStartDate: '',
        
        refreshInterval: null
    },
    computed: {
        isFounder() {
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes('founder'));
        },
        isSkinDesigner() {
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes('skin_designer'));
        },
        isEngineSeller() {
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes('engine_seller'));
        },
        isFarmManager() {
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes('farm_rental_manager'));
        },
        isHousingManager() {
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes('housing_apps_manager'));
        },
        canViewSubmissions() {
            if (!this.currentUser || !this.currentUser.roles) return false;
            const submissionManagers = ['founder', 'company_apps_manager', 'housing_apps_manager', 'support_apps_manager', 'farm_rental_manager'];
            return this.currentUser.roles.some(r => submissionManagers.includes(r));
        },
        canAccessDashboard() {
            if (!this.currentUser || !this.currentUser.roles) return false;
            return this.currentUser.roles.some(r => r !== 'member');
        },
        filteredProducts() {
            if (this.filterCategory === 'all') return this.products;
            if (this.filterCategory === 'skins') {
                return this.products.filter(p => p.category === 'male_skins' || p.category === 'female_skins');
            }
            return this.products.filter(p => p.category === this.filterCategory);
        },
        filteredSubmissionsBySection() {
            let statusMap = { 'submissions': 'all', 'pending': 'pending', 'accepted': 'accepted', 'rejected': 'rejected' };
            let targetStatus = statusMap[this.dashSection] || 'all';
            let list = this.submissions;
            
            if (!this.isFounder) {
                let userRoles = this.currentUser ? this.currentUser.roles : [];
                list = list.filter(s => {
                    if (!s.manager_role_key) return false;
                    return userRoles.includes(s.manager_role_key);
                });
            }
            
            if (targetStatus === 'all') return list;
            return list.filter(s => s.status === targetStatus);
        },
        farmBookingsCount() {
            return this.farmBookings.filter(b => b.status === 'pending').length;
        },
        estimatedCost() {
            if (!this.selectedFarm) return 0;
            let days = this.bookingForm.days || 1;
            let assistants = this.bookingForm.assistants || 0;
            return (this.selectedFarm.price_per_day + (this.selectedFarm.assistant_price_per_day * assistants)) * days;
        }
    },
    methods: {
        saveTabState(tab) {
            try {
                localStorage.setItem('activeTab', tab);
            } catch(e) {}
        },
        getSavedTab() {
            try {
                return localStorage.getItem('activeTab') || 'home';
            } catch(e) {
                return 'home';
            }
        },
        handleAvatarError(e) {
            e.target.style.display = 'none';
            const parent = e.target.parentElement;
            if (parent) {
                let fallback = parent.querySelector('.fallback');
                if (!fallback) {
                    fallback = document.createElement('span');
                    fallback.className = 'fallback';
                    fallback.textContent = this.currentUser ? this.currentUser.username.charAt(0).toUpperCase() : 'U';
                    parent.appendChild(fallback);
                }
            }
        },
        canManageAppType(managerRoleKey) {
            if (this.isFounder) return true;
            if (!managerRoleKey) return false;
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes(managerRoleKey));
        },
        deletePurchase(purchaseId) {
            if (!confirm('هل أنت متأكد من حذف طلب الشراء هذا؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_purchase');
            fd.append('purchase_id', purchaseId);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.fetchPurchases();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        deleteSubmission(submissionId) {
            if (!confirm('هل أنت متأكد من حذف هذا التقديم؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_submission');
            fd.append('submission_id', submissionId);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.submissions = this.submissions.filter(s => s.id !== submissionId);
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        updateProductStatus(productId, status) {
            let fd = new FormData();
            fd.append('action', 'update_product_status');
            fd.append('id', productId);
            fd.append('status', status);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                } else {
                    this.showNotification('❌ ' + data.message);
                    this.fetchProducts();
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        fetchProducts() {
            fetch('/Italiano/api/api.php?action=getProducts')
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) this.products = data;
            })
            .catch(() => {});
        },
        showNotification(text) {
            let notif = document.getElementById('notification');
            document.getElementById('notification-text').textContent = text;
            notif.classList.add('show');
            setTimeout(() => notif.classList.remove('show'), 3000);
        },
        goTo(url) { window.location.href = url; },
        roleLabel(roleKey) {
            let r = this.rolesList.find(x => x.role_key === roleKey);
            return r ? r.role_name : roleKey;
        },
        canManageSubmission(sub) {
            if (this.isFounder) return true;
            if (!sub.manager_role_key) return false;
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes(sub.manager_role_key));
        },
        formatDate(date) {
            if (!date) return '';
            let d = new Date(date);
            return d.toLocaleDateString('ar-EG') + ' ' + d.toLocaleTimeString('ar-EG', {hour: '2-digit', minute:'2-digit'});
        },
        switchTab(tab) {
            this.activeTab = tab;
            this.saveTabState(tab);
            
            document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
            let target = document.getElementById('tab-' + tab);
            if (target) target.classList.add('active');
            
            if (tab === 'home') this.selectedApp = null;
            if (tab === 'dashboard') this.dashSection = 'submissions';
        },
        filterProducts(cat) { this.filterCategory = cat; },
        fetchNotifications() {
            let fd = new FormData();
            fd.append('action', 'get_notifications');
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.notifications = data.notifications || [];
                    this.unreadCount = data.unread_count || 0;
                }
            })
            .catch(() => {});
        },
        toggleNotifications() {
            this.showNotifications = !this.showNotifications;
            if (this.showNotifications) {
                this.fetchNotifications();
            }
        },
        closeNotifications() {
            this.showNotifications = false;
        },
        markRead(notificationId) {
            let fd = new FormData();
            fd.append('action', 'mark_notification_read');
            fd.append('notification_id', notificationId);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let notif = this.notifications.find(n => n.id === notificationId);
                    if (notif) notif.is_read = 1;
                    this.unreadCount = Math.max(0, this.unreadCount - 1);
                }
            })
            .catch(() => {});
        },
        markAllRead() {
            let fd = new FormData();
            fd.append('action', 'mark_notification_read');
            fd.append('notification_id', 0);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.notifications.forEach(n => n.is_read = 1);
                    this.unreadCount = 0;
                    this.showNotification('✅ تم تحديد الكل كمقروء');
                }
            })
            .catch(() => {});
        },
        deleteReadNotifications() {
            if (!confirm('هل أنت متأكد من حذف جميع الإشعارات المقروءة؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_read_notifications');
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.notifications = this.notifications.filter(n => !n.is_read);
                    this.showNotification('✅ ' + data.message);
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        fetchSliders() {
            fetch('/Italiano/api/api.php?action=getSliders')
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) {
                    this.slidersList = data;
                }
            })
            .catch(() => {});
        },
        openSliderModal() {
            this.newSlider = { title: '', link: '' };
            this.sliderImageFile = null;
            document.getElementById('sliderModal').classList.add('active');
        },
        closeSliderModal() {
            document.getElementById('sliderModal').classList.remove('active');
        },
        onSliderImageChange(e) {
            const file = e.target.files[0];
            if (file) {
                this.sliderImageFile = file;
            } else {
                this.sliderImageFile = null;
            }
        },
        saveSlider() {
            let file = this.sliderImageFile;
            
            if (!file && this.$refs.sliderInput) {
                const input = this.$refs.sliderInput;
                if (input.files && input.files.length > 0) {
                    file = input.files[0];
                    this.sliderImageFile = file;
                }
            }
            
            if (!file) {
                this.showNotification('❌ يرجى اختيار صورة');
                return;
            }
            
            const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
            if (!allowedTypes.includes(file.type)) {
                this.showNotification('❌ نوع الملف غير مسموح. الأنواع المسموحة: JPG, PNG, WEBP, GIF');
                return;
            }
            
            if (file.size > 5 * 1024 * 1024) {
                this.showNotification('❌ حجم الملف يتجاوز 5 ميجابايت');
                return;
            }
            
            let fd = new FormData();
            fd.append('action', 'add_slider');
            fd.append('title', this.newSlider.title || '');
            fd.append('link', this.newSlider.link || '');
            fd.append('slider_image', file);
            fd.append('csrf_token', this.csrfToken);
            
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.closeSliderModal();
                    location.reload();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(err => {
                this.showNotification('❌ حدث خطأ في الاتصال');
            });
        },
        deleteSlider(id) {
            if (!confirm('تأكيد حذف هذه الصورة؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_slider');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.slidersList = this.slidersList.filter(s => s.id !== id);
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        toggleSliderStatus(id, currentStatus) {
            let newStatus = currentStatus ? 0 : 1;
            let fd = new FormData();
            fd.append('action', 'toggle_slider_status');
            fd.append('id', id);
            fd.append('is_active', newStatus);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let slide = this.slidersList.find(s => s.id === id);
                    if (slide) slide.is_active = newStatus;
                    this.showNotification('✅ ' + data.message);
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        openProductModal() {
            this.newProduct = { name: '', price: 0, category: 'male_skins', iban: '' };
            this.productImageFile = null;
            document.getElementById('productModal').classList.add('active');
        },
        closeProductModal() {
            document.getElementById('productModal').classList.remove('active');
        },
        onProductImageChange(e) {
            this.productImageFile = e.target.files[0] || null;
        },
        saveProduct() {
            if (!this.newProduct.name.trim() || this.newProduct.price <= 0) {
                this.showNotification('❌ يرجى ملء جميع الحقول بشكل صحيح');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'add_product');
            fd.append('name', this.newProduct.name);
            fd.append('price', this.newProduct.price);
            fd.append('category', this.newProduct.category);
            fd.append('iban', this.newProduct.iban || '');
            fd.append('csrf_token', this.csrfToken);
            if (this.productImageFile) fd.append('image', this.productImageFile);

            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.products.push({
                        id: data.id,
                        name: this.newProduct.name,
                        price: parseFloat(this.newProduct.price),
                        category: this.newProduct.category,
                        iban: this.newProduct.iban || '',
                        status: 'available',
                        image: data.image || ''
                    });
                    this.showNotification('✅ تمت الإضافة بنجاح');
                    this.closeProductModal();
                } else this.showNotification('❌ ' + (data.message || 'فشلت الإضافة'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        deleteProduct(id) {
            if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_product');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.products = this.products.filter(p => p.id !== id);
                    this.showNotification('✅ تم الحذف');
                } else this.showNotification('❌ ' + (data.message || 'فشل الحذف'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        openPurchaseModal(product) {
            if (product.status !== 'available') {
                this.showNotification('❌ هذا المنتج غير متاح للشراء');
                return;
            }
            this.purchasingProduct = product;
            this.paymentImageFile = null;
            document.getElementById('purchaseModal').classList.add('active');
        },
        closePurchaseModal() {
            document.getElementById('purchaseModal').classList.remove('active');
            this.purchasingProduct = null;
            this.paymentImageFile = null;
        },
        onPaymentImageChange(e) {
            this.paymentImageFile = e.target.files[0] || null;
        },
        submitPurchase() {
            if (!this.paymentImageFile) {
                this.showNotification('❌ يرجى رفع صورة إثبات الدفع');
                return;
            }
            const productId = this.purchasingProduct ? this.purchasingProduct.id : null;
            if (!productId) {
                this.showNotification('❌ حدث خطأ، يرجى المحاولة مرة أخرى');
                return;
            }
            
            this.purchasingLoading = true;
            let fd = new FormData();
            fd.append('action', 'purchase_product');
            fd.append('product_id', productId);
            fd.append('payment_image', this.paymentImageFile);
            fd.append('csrf_token', this.csrfToken);
            
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                this.purchasingLoading = false;
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.closePurchaseModal();
                    let product = this.products.find(p => p.id === productId);
                    if (product && product.category !== 'skins') {
                        product.status = 'pending';
                    }
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch((err) => {
                this.purchasingLoading = false;
                this.showNotification('❌ حدث خطأ في الاتصال: ' + err.message);
            });
        },
        fetchPurchases() {
            let fd = new FormData();
            fd.append('action', 'get_purchases');
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.purchasesList = data.purchases.map(p => ({ ...p, delivery_link_temp: p.delivery_link || '' }));
                }
            })
            .catch(() => {});
        },
        updatePurchase(purchaseId, status, deliveryLink, adminNotes) {
            if (!confirm('تأكيد تحديث حالة الطلب؟')) return;
            let fd = new FormData();
            fd.append('action', 'update_purchase');
            fd.append('purchase_id', purchaseId);
            fd.append('status', status);
            fd.append('delivery_link', deliveryLink || '');
            fd.append('admin_notes', adminNotes || '');
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.fetchPurchases();
                    fetch('/Italiano/api/api.php?action=getProducts')
                    .then(res => res.json())
                    .then(data => {
                        if (Array.isArray(data)) this.products = data;
                    })
                    .catch(() => {});
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        toggleUserRole(user, roleId) {
            if (!this.isFounder) {
                this.showNotification('❌ فقط الفاوندر يمكنه تعديل الرتب');
                return;
            }
            let idx = user.role_ids.indexOf(roleId);
            if (idx === -1) user.role_ids.push(roleId); else user.role_ids.splice(idx, 1);

            let fd = new FormData();
            fd.append('action', 'update_user_roles');
            fd.append('user_id', user.id);
            fd.append('role_ids', JSON.stringify(user.role_ids));
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) this.showNotification('✅ تم تحديث الرتب');
                else this.showNotification('❌ ' + (data.message || 'فشل التحديث'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        toggleUserJob(user, jobId) {
            if (!this.isFounder) {
                this.showNotification('❌ فقط الفاوندر يمكنه تعديل الوظائف');
                return;
            }
            if (!user.job_ids) user.job_ids = [];
            let idx = user.job_ids.indexOf(jobId);
            if (idx === -1) user.job_ids.push(jobId); else user.job_ids.splice(idx, 1);

            let fd = new FormData();
            fd.append('action', 'update_user_jobs');
            fd.append('user_id', user.id);
            fd.append('job_ids', JSON.stringify(user.job_ids));
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) this.showNotification('✅ تم تحديث الوظائف');
                else this.showNotification('❌ ' + (data.message || 'فشل التحديث'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        fetchJobs() {
            fetch('/Italiano/api/api.php?action=getJobTitles')
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) this.jobsList = data;
            })
            .catch(() => {});
        },
        addJob() {
            if (!this.newJob.trim()) {
                this.showNotification('❌ أدخل اسم الوظيفة');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'add_job');
            fd.append('name', this.newJob.trim());
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.jobsList.push({ id: data.id, name: this.newJob.trim() });
                    this.newJob = '';
                    this.showNotification('✅ تمت إضافة الوظيفة');
                } else this.showNotification('❌ ' + (data.message || 'فشلت الإضافة'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        deleteJob(id) {
            if (!confirm('تأكيد حذف الوظيفة؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_job');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.jobsList = this.jobsList.filter(j => j.id !== id);
                    this.showNotification('✅ تم الحذف');
                } else this.showNotification('❌ ' + (data.message || 'فشل الحذف'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        fetchAppTypes() { },
        openAppTypeModal(app = null) {
            if (app) {
                this.editingAppType = true;
                this.appTypeForm = {
                    id: app.id,
                    name: app.name,
                    description: app.description || '',
                    manager_role_key: app.manager_role_key || '',
                    min_hours: app.min_hours || 0,
                    min_history: app.min_history || 0,
                    min_money: app.min_money || 0,
                    requirements: app.requirements || ''
                };
            } else {
                this.editingAppType = false;
                this.appTypeForm = { id: null, name: '', description: '', manager_role_key: '', min_hours: 0, min_history: 0, min_money: 0, requirements: '' };
            }
            document.getElementById('appTypeModal').classList.add('active');
        },
        closeAppTypeModal() {
            document.getElementById('appTypeModal').classList.remove('active');
        },
        saveAppType() {
            if (!this.appTypeForm.name.trim()) {
                this.showNotification('❌ أدخل اسم التقديم');
                return;
            }
            let action = this.editingAppType ? 'update_application_type' : 'add_application_type';
            let fd = new FormData();
            fd.append('action', action);
            fd.append('name', this.appTypeForm.name);
            fd.append('description', this.appTypeForm.description);
            fd.append('manager_role_key', this.appTypeForm.manager_role_key || '');
            fd.append('min_hours', this.appTypeForm.min_hours || 0);
            fd.append('min_history', this.appTypeForm.min_history || 0);
            fd.append('min_money', this.appTypeForm.min_money || 0);
            fd.append('requirements', this.appTypeForm.requirements || '');
            if (this.editingAppType) fd.append('id', this.appTypeForm.id);
            fd.append('csrf_token', this.csrfToken);

            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (this.editingAppType) {
                        let app = this.applicationTypes.find(a => a.id === this.appTypeForm.id);
                        if (app) {
                            app.name = this.appTypeForm.name;
                            app.description = this.appTypeForm.description;
                            app.manager_role_key = this.appTypeForm.manager_role_key || null;
                            app.min_hours = this.appTypeForm.min_hours || 0;
                            app.min_history = this.appTypeForm.min_history || 0;
                            app.min_money = this.appTypeForm.min_money || 0;
                            app.requirements = this.appTypeForm.requirements || '';
                        }
                        this.showNotification('✅ تم التحديث');
                    } else {
                        this.applicationTypes.push({
                            id: data.id,
                            name: this.appTypeForm.name,
                            description: this.appTypeForm.description,
                            is_open: 1,
                            manager_role_key: this.appTypeForm.manager_role_key || null,
                            min_hours: this.appTypeForm.min_hours || 0,
                            min_history: this.appTypeForm.min_history || 0,
                            min_money: this.appTypeForm.min_money || 0,
                            requirements: this.appTypeForm.requirements || '',
                            questions: []
                        });
                        this.showNotification('✅ تمت إضافة نوع التقديم');
                    }
                    this.closeAppTypeModal();
                } else this.showNotification('❌ ' + (data.message || 'فشلت العملية'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        editAppType(id) {
            let app = this.applicationTypes.find(a => a.id === id);
            if (app) this.openAppTypeModal(app);
        },
        deleteAppType(id) {
            if (!confirm('تأكيد حذف نوع التقديم؟ سيتم حذف جميع أسئلته أيضاً!')) return;
            let fd = new FormData();
            fd.append('action', 'delete_application_type');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.applicationTypes = this.applicationTypes.filter(a => a.id !== id);
                    this.showNotification('✅ تم الحذف');
                } else this.showNotification('❌ ' + (data.message || 'فشل الحذف'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        addQuestion(appId) {
            this.editingQuestion = false;
            this.currentAppId = appId;
            this.currentQuestionIdx = null;
            this.questionForm = { id: null, text: '', field_type: 'text', optionsArray: [], required: false };
            document.getElementById('questionModal').classList.add('active');
        },
        editQuestion(appId, idx) {
            let app = this.applicationTypes.find(a => a.id === appId);
            if (!app) return;
            let q = app.questions[idx];
            if (!q) return;
            this.editingQuestion = true;
            this.currentAppId = appId;
            this.currentQuestionIdx = idx;
            this.questionForm = {
                id: q.id,
                text: q.question_text,
                field_type: q.field_type,
                optionsArray: JSON.parse(q.options || '[]'),
                required: q.required == 1
            };
            document.getElementById('questionModal').classList.add('active');
        },
        closeQuestionModal() {
            document.getElementById('questionModal').classList.remove('active');
        },
        onFieldTypeChange() {
            if (this.questionForm.field_type !== 'select') {
                this.questionForm.optionsArray = [];
            }
        },
        addOption() {
            this.questionForm.optionsArray.push('');
        },
        removeOption(idx) {
            this.questionForm.optionsArray.splice(idx, 1);
        },
        saveQuestion() {
            if (!this.questionForm.text.trim()) {
                this.showNotification('❌ يرجى كتابة نص السؤال');
                return;
            }
            let optionsJson = JSON.stringify(this.questionForm.optionsArray);
            let action = this.editingQuestion ? 'update_question' : 'add_question';
            let fd = new FormData();
            fd.append('action', action);
            fd.append('type_id', this.currentAppId);
            fd.append('text', this.questionForm.text);
            fd.append('field_type', this.questionForm.field_type);
            fd.append('options', optionsJson);
            fd.append('required', this.questionForm.required ? 1 : 0);
            if (this.editingQuestion) fd.append('id', this.questionForm.id);
            fd.append('csrf_token', this.csrfToken);

            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let app = this.applicationTypes.find(a => a.id === this.currentAppId);
                    if (!app) return;
                    if (this.editingQuestion) {
                        let q = app.questions[this.currentQuestionIdx];
                        if (q) {
                            q.question_text = this.questionForm.text;
                            q.field_type = this.questionForm.field_type;
                            q.options = optionsJson;
                            q.required = this.questionForm.required ? 1 : 0;
                        }
                        this.showNotification('✅ تم التحديث');
                    } else {
                        app.questions.push({
                            id: data.id,
                            question_text: this.questionForm.text,
                            field_type: this.questionForm.field_type,
                            options: optionsJson,
                            required: this.questionForm.required ? 1 : 0
                        });
                        this.showNotification('✅ تمت الإضافة');
                    }
                    this.closeQuestionModal();
                } else this.showNotification('❌ ' + (data.message || 'فشلت العملية'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        removeQuestion(appId, idx) {
            let app = this.applicationTypes.find(a => a.id === appId);
            if (!app) return;
            let q = app.questions[idx];
            if (!q) return;
            if (!confirm('هل أنت متأكد من حذف هذا السؤال؟')) return;
            let fd = new FormData();
            fd.append('action', 'remove_question');
            fd.append('id', q.id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    app.questions.splice(idx, 1);
                    this.showNotification('✅ تم الحذف');
                } else this.showNotification('❌ ' + (data.message || 'فشل الحذف'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        viewAnswers(id) {
            let fd = new FormData();
            fd.append('action', 'get_submission_answers');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.viewingSubmission = data.submission;
                    this.viewingAnswers = data.answers;
                    this.viewingQuestions = data.questions;
                    document.getElementById('answersModal').classList.add('active');
                } else {
                    this.showNotification('❌ ' + (data.message || 'فشل جلب البيانات'));
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        closeAnswersModal() {
            document.getElementById('answersModal').classList.remove('active');
            this.viewingSubmission = null;
            this.viewingAnswers = null;
            this.viewingQuestions = {};
        },
        reviewSubmissionFromModal(status) {
            if (!this.viewingSubmission) return;
            this.reviewSubmission(this.viewingSubmission.id, status);
            this.closeAnswersModal();
        },
        reviewSubmission(id, status) {
            if (!this.canManageSubmission({ id: id, manager_role_key: this.submissions.find(s => s.id === id)?.manager_role_key })) {
                this.showNotification('❌ غير مصرح لك بمراجعة هذا الطلب');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'review_submission');
            fd.append('id', id);
            fd.append('status', status);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let sub = this.submissions.find(s => s.id === id);
                    if (sub) sub.status = status;
                    this.showNotification(status === 'accepted' ? '✅ تم القبول' : '❌ تم الرفض');
                } else this.showNotification('❌ ' + (data.message || 'فشل التحديث'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        toggleApp(id) {
            let app = this.applicationTypes.find(a => a.id === id);
            if (!app) return;
            
            if (!this.canManageAppType(app.manager_role_key)) {
                this.showNotification('❌ غير مصرح لك بإدارة هذا التقديم');
                return;
            }
            
            let newStatus = app.is_open ? 0 : 1;
            let fd = new FormData();
            fd.append('action', 'toggle_app');
            fd.append('id', id);
            fd.append('is_open', newStatus);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    app.is_open = !!newStatus;
                    this.showNotification('✅ تم ' + (app.is_open ? 'فتح' : 'غلق') + ' التقديم');
                } else this.showNotification('❌ ' + (data.message || 'فشل التحديث'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        updateProfile() {
            this.showNotification('❌ تغيير الاسم غير مسموح، اسمك مرتبط بحساب Discord');
        },
        // ============================================================
        // دوال المزارع
        // ============================================================
        fetchFarms() {
            let fd = new FormData();
            fd.append('action', 'get_farms');
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) this.farms = data.farms || [];
            })
            .catch(() => {});
        },
        fetchFarmBookings() {
            if (!this.isFarmManager && !this.isFounder) return;
            let fd = new FormData();
            fd.append('action', 'get_farm_bookings');
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.farmBookings = data.bookings || [];
                }
            })
            .catch(() => {});
        },
        openBookingModal(farm) {
            this.selectedFarm = farm;
            this.bookingForm = { days: 1, assistants: 0 };
            this.calculatedStartDate = '';
            
            let fd = new FormData();
            fd.append('action', 'get_farm_next_available_date');
            fd.append('farm_id', farm.id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.calculatedStartDate = data.next_start_date;
                }
            })
            .catch(() => {});
            
            document.getElementById('bookingModal').classList.add('active');
        },
        closeBookingModal() {
            document.getElementById('bookingModal').classList.remove('active');
            this.selectedFarm = null;
        },
        submitBooking() {
            if (!this.selectedFarm) return;
            let fd = new FormData();
            fd.append('action', 'book_farm');
            fd.append('farm_id', this.selectedFarm.id);
            fd.append('days', this.bookingForm.days);
            fd.append('assistants', this.bookingForm.assistants);
            fd.append('csrf_token', this.csrfToken);
            this.bookingLoading = true;
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                this.bookingLoading = false;
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.closeBookingModal();
                    this.fetchFarms();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => {
                this.bookingLoading = false;
                this.showNotification('❌ حدث خطأ');
            });
        },
        openAddFarmModal() {
            this.newFarm = { name: '', location: '', price_per_day: 0, assistant_price_per_day: 0 };
            this.farmImageFile = null;
            document.getElementById('addFarmModal').classList.add('active');
        },
        closeAddFarmModal() {
            document.getElementById('addFarmModal').classList.remove('active');
        },
        onFarmImageChange(e) {
            this.farmImageFile = e.target.files[0] || null;
        },
        saveFarm() {
            if (!this.newFarm.name.trim() || this.newFarm.price_per_day <= 0) {
                this.showNotification('❌ يرجى ملء البيانات الأساسية');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'add_farm');
            fd.append('name', this.newFarm.name);
            fd.append('location', this.newFarm.location || '');
            fd.append('price_per_day', this.newFarm.price_per_day);
            fd.append('assistant_price_per_day', this.newFarm.assistant_price_per_day || 0);
            fd.append('csrf_token', this.csrfToken);
            if (this.farmImageFile) fd.append('farm_image', this.farmImageFile);
            
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.closeAddFarmModal();
                    this.fetchFarms();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        deleteFarm(id) {
            if (!confirm('هل أنت متأكد من حذف هذه المزرعة؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_farm');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.fetchFarms();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        approveBooking(id) {
            if (!confirm('تأكيد قبول هذا الحجز؟')) return;
            let fd = new FormData();
            fd.append('action', 'approve_booking');
            fd.append('booking_id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.fetchFarmBookings();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        rejectBooking(id) {
            if (!confirm('تأكيد رفض هذا الحجز؟')) return;
            let fd = new FormData();
            fd.append('action', 'reject_booking');
            fd.append('booking_id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('/Italiano/index.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.fetchFarmBookings();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        }
    },
    
    mounted() {
        if ('scrollRestoration' in history) {
            history.scrollRestoration = 'manual';
        }
        window.scrollTo(0, 0);
        
        this.switchTab(this.activeTab);
        
        if (this.isLoggedIn) {
            this.fetchNotifications();
        }
        
        this.fetchFarms();
        if (this.isFarmManager || this.isFounder) {
            this.fetchFarmBookings();
        }
        
        this.refreshInterval = setInterval(() => {
            if (this.isLoggedIn && !this.showNotifications) {
                this.fetchNotifications();
            }
            this.fetchFarms();
        }, 30000);
    },
    beforeDestroy() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
    }
});

// ===== السلايدر =====
let currentSlide = 0;
const slides = document.querySelectorAll('#slider img');
if (slides.length > 0) {
    setInterval(() => {
        slides.forEach(img => img.classList.remove('active'));
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].classList.add('active');
    }, 4000);
}
</script>
</body>
</html>