<?php
// test_bot_api.php
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/bot-api.php';

echo "<h2>🧪 اختبار Bot API - Italiano</h2>";

// 1. اختبار حالة البوت
echo "<h3>1. /api/status</h3>";
$status = bot_get_status();
if ($status) {
    echo "<pre style='background:#1a1a2e;padding:10px;border-radius:8px;color:#10b981;'>";
    print_r($status);
    echo "</pre>";
} else {
    echo "<p style='color:#ef4444;'>❌ فشل في جلب حالة البوت</p>";
}

// 2. اختبار جلب المستخدمين
echo "<h3>2. /api/users (أول 5 مستخدمين)</h3>";
$users = bot_get_users();
if ($users && is_array($users)) {
    $sample = array_slice($users, 0, 5);
    echo "<pre style='background:#1a1a2e;padding:10px;border-radius:8px;color:#fbbf24;'>";
    print_r($sample);
    echo "</pre>";
    echo "<p>✅ عدد المستخدمين الكلي: " . count($users) . "</p>";
} else {
    echo "<p style='color:#ef4444;'>❌ فشل في جلب المستخدمين</p>";
}

// 3. اختبار جلب القنوات
echo "<h3>3. /api/channels (أول 5 قنوات)</h3>";
$channels = bot_get_channels();
if ($channels && is_array($channels)) {
    $sample = array_slice($channels, 0, 5);
    echo "<pre style='background:#1a1a2e;padding:10px;border-radius:8px;color:#60a5fa;'>";
    print_r($sample);
    echo "</pre>";
    echo "<p>✅ عدد القنوات الكلي: " . count($channels) . "</p>";
} else {
    echo "<p style='color:#ef4444;'>❌ فشل في جلب القنوات</p>";
}

// 4. اختبار جلب التذاكر
echo "<h3>4. /api/tickets (أول 5 تذاكر)</h3>";
$tickets = bot_get_tickets();
if ($tickets && is_array($tickets)) {
    $sample = array_slice($tickets, 0, 5);
    echo "<pre style='background:#1a1a2e;padding:10px;border-radius:8px;color:#a78bfa;'>";
    print_r($sample);
    echo "</pre>";
    echo "<p>✅ عدد التذاكر الكلي: " . count($tickets) . "</p>";
} else {
    echo "<p style='color:#ef4444;'>❌ فشل في جلب التذاكر</p>";
}
?>