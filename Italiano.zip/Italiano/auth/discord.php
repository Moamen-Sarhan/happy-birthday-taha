<?php
// auth/discord.php - بداية عملية الدخول
require_once __DIR__ . '/../inc/config.php';
require_once __DIR__ . '/../inc/functions.php';

// رابط الدخول إلى Discord
$auth_url = 'https://discord.com/oauth2/authorize?' . http_build_query([
    'client_id' => DISCORD_CLIENT_ID,
    'redirect_uri' => DISCORD_REDIRECT_URI,
    'response_type' => 'code',
    'scope' => 'identify email',
    'prompt' => 'consent'
]);

// التوجيه إلى Discord
header('Location: ' . $auth_url);
exit;
?>