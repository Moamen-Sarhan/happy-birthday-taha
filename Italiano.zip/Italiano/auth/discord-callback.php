<?php
// auth/discord-callback.php - استقبال الرد من Discord
require_once __DIR__ . '/../inc/config.php';
require_once __DIR__ . '/../inc/functions.php';

$code = $_GET['code'] ?? null;
if (!$code) {
    die('❌ لم يتم استلام رمز المصادقة');
}

// ===== 1. تبادل الكود مع التوكن =====
$token_url = 'https://discord.com/api/oauth2/token';

$ch = curl_init($token_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'client_id' => DISCORD_CLIENT_ID,
    'client_secret' => DISCORD_CLIENT_SECRET,
    'grant_type' => 'authorization_code',
    'code' => $code,
    'redirect_uri' => DISCORD_REDIRECT_URI,
]));

$response = curl_exec($ch);
$error = curl_error($ch);
curl_close($ch);

if ($error) {
    die('❌ فشل الاتصال: ' . $error);
}

$token_data = json_decode($response, true);
if (!isset($token_data['access_token'])) {
    die('❌ فشل الحصول على التوكن: ' . $response);
}

$access_token = $token_data['access_token'];

// ===== 2. جلب بيانات المستخدم =====
$user_url = 'https://discord.com/api/users/@me';
$ch = curl_init($user_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $access_token
]);

$user_response = curl_exec($ch);
curl_close($ch);

$user_data = json_decode($user_response, true);
if (!isset($user_data['id'])) {
    die('❌ فشل جلب بيانات المستخدم');
}

// ===== 3. حفظ أو تحديث المستخدم في قاعدة البيانات =====
$username = $user_data['username'] . '#' . ($user_data['discriminator'] ?? '0');
$discord_id = $user_data['id'];
$avatar = $user_data['avatar'] ?? null;

$stmt = $pdo->prepare("SELECT * FROM users WHERE discord_id = ?");
$stmt->execute([$discord_id]);
$existing = $stmt->fetch(PDO::FETCH_ASSOC);

if ($existing) {
    // تحديث المستخدم الحالي
    $stmt = $pdo->prepare("UPDATE users SET username = ?, avatar = ? WHERE id = ?");
    $stmt->execute([$username, $avatar, $existing['id']]);
    $user_id = $existing['id'];
    
    // جلب رتب المستخدم الحالي من قاعدة البيانات
    $roles = getUserRoleKeys($user_id, $pdo);
    if (empty($roles)) $roles = [];
    
} else {
    // ============================================================
    // 🔴 إنشاء مستخدم جديد WITHOUT أي رتبة تلقائياً
    // ============================================================
    // لم نعد نضيف رتبة 'member' تلقائياً
    // المستخدم سيكون بدون أي رتبة حتى يقوم الفاوندر بتعيينها
    $stmt = $pdo->prepare("INSERT INTO users (username, discord_id, avatar, role) VALUES (?, ?, ?, NULL)");
    $stmt->execute([$username, $discord_id, $avatar]);
    $user_id = $pdo->lastInsertId();
    
    // ❌ لا نضيف أي رتبة في جدول user_roles
    // المستخدم الجديد لن يكون لديه أي رتبة
    $roles = [];
}

// ===== 4. بدء الجلسة وتخزين بيانات المستخدم =====
$_SESSION['user_id'] = $user_id;
$_SESSION['username'] = $username;
$_SESSION['discord_id'] = $discord_id;
$_SESSION['avatar'] = $avatar;
$_SESSION['roles'] = $roles; // مصفوفة فارغة للمستخدم الجديد

// ===== 5. التوجيه للصفحة الرئيسية =====
header('Location: /Italiano/index.php?login=success');
exit;
?>