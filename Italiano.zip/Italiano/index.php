<?php
// نقطة الدخول الوحيدة
require_once __DIR__ . '/pages/index.php';