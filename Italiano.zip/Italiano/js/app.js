// js/app.js
Vue.directive('clickoutside', {
    bind(el, binding) {
        el.clickOutsideEvent = function(event) {
            if (!(el === event.target || el.contains(event.target))) {
                binding.value();
            }
        };
        document.addEventListener('click', el.clickOutsideEvent);
    },
    unbind(el) {
        document.removeEventListener('click', el.clickOutsideEvent);
    }
});

// البيانات يتم تمريرها من PHP عبر وسم script في pages/index.php
new Vue({
    el: '#app',
    data: {
        isLoggedIn: userData.isLoggedIn,
        currentUser: userData.currentUser,
        activeTab: 'home',
        dashSection: 'submissions',
        selectedApp: null,
        filterCategory: 'all',
        products: appData.products,
        applicationTypes: appData.applicationTypes,
        submissions: appData.submissions,
        usersList: appData.usersList,
        giveaways: appData.giveaways,
        rolesList: appData.roles,
        jobsList: appData.jobs,
        supportTickets: appData.supportTickets,
        purchasesList: appData.purchasesList,
        csrfToken: csrfToken,
        adminsList: appData.adminsList || [],

        notifications: appData.notifications,
        unreadCount: appData.unreadCount,
        showNotifications: false,

        slidersList: appData.sliders,
        newSlider: { title: '', link: '' },
        sliderImageFile: null,

        stats: appData.stats,

        purchasingProduct: null,
        purchasingLoading: false,
        paymentImageFile: null,

        questionForm: { id: null, text: '', field_type: 'text', optionsArray: [], required: false },
        editingQuestion: false,
        currentAppId: null,
        currentQuestionIdx: null,

        appTypeForm: { id: null, name: '', description: '', manager_role_key: '', min_hours: 0, min_history: 0, min_money: 0, requirements: '' },
        editingAppType: false,

        viewingSubmission: null,
        viewingAnswers: null,
        viewingQuestions: {},

        newProduct: { name: '', price: 0, category: 'general', iban: '' },
        productImageFile: null,
        newGiveaway: { title: '', description: '', prize: '', ends_at: '' },
        newJob: '',
        
        refreshInterval: null
    },
    computed: {
        isFounder() {
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes('founder'));
        },
        isFarmManager() {
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes('farm_rental_manager'));
        },
        isHousingManager() {
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes('housing_apps_manager'));
        },
        canManageSupport() {
            if (!this.currentUser || !this.currentUser.roles) return false;
            return this.isFounder || this.isFarmManager || this.isHousingManager;
        },
        canAccessDashboard() {
            if (!this.currentUser || !this.currentUser.roles) return false;
            return this.currentUser.roles.some(r => r !== 'member');
        },
        filteredProducts() {
            if (this.filterCategory === 'all') return this.products;
            return this.products.filter(p => p.category === this.filterCategory);
        },
        filteredSubmissionsBySection() {
            let statusMap = { 'submissions': 'all', 'pending': 'pending', 'accepted': 'accepted', 'rejected': 'rejected' };
            let targetStatus = statusMap[this.dashSection] || 'all';
            let list = this.submissions;
            
            if (!this.isFounder) {
                let userRoles = this.currentUser ? this.currentUser.roles : [];
                list = list.filter(s => {
                    if (!s.manager_role_key) return false;
                    return userRoles.includes(s.manager_role_key);
                });
            }
            
            if (targetStatus === 'all') return list;
            return list.filter(s => s.status === targetStatus);
        }
    },
    methods: {
        saveTabState(tab) {
            try {
                localStorage.setItem('activeTab', tab);
            } catch(e) {}
        },
        getSavedTab() {
            try {
                return localStorage.getItem('activeTab') || 'home';
            } catch(e) {
                return 'home';
            }
        },
        deleteTicket(ticketId) {
            if (!confirm('هل أنت متأكد من حذف هذه التذكرة؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_ticket');
            fd.append('ticket_id', ticketId);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.fetchTickets();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        deletePurchase(purchaseId) {
            if (!confirm('هل أنت متأكد من حذف طلب الشراء هذا؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_purchase');
            fd.append('purchase_id', purchaseId);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.fetchPurchases();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        deleteSubmission(submissionId) {
            if (!confirm('هل أنت متأكد من حذف هذا التقديم؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_submission');
            fd.append('submission_id', submissionId);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.submissions = this.submissions.filter(s => s.id !== submissionId);
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        updateProductStatus(productId, status) {
            let fd = new FormData();
            fd.append('action', 'update_product_status');
            fd.append('id', productId);
            fd.append('status', status);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                } else {
                    this.showNotification('❌ ' + data.message);
                    this.fetchProducts();
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        fetchProducts() {
            fetch('api/api.php?action=getProducts')
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) this.products = data;
            })
            .catch(() => {});
        },
        showNotification(text) {
            let notif = document.getElementById('notification');
            document.getElementById('notification-text').textContent = text;
            notif.classList.add('show');
            setTimeout(() => notif.classList.remove('show'), 3000);
        },
        goTo(url) { window.location.href = url; },
        roleLabel(roleKey) {
            let r = this.rolesList.find(x => x.role_key === roleKey);
            return r ? r.role_name : roleKey;
        },
        canManageSubmission(sub) {
            if (this.isFounder) return true;
            if (!sub.manager_role_key) return false;
            return !!(this.currentUser && this.currentUser.roles && this.currentUser.roles.includes(sub.manager_role_key));
        },
        canManageTicket(ticket) {
            if (this.isFounder) return true;
            if (ticket.section === 'farm' && this.isFarmManager) return true;
            if (ticket.section === 'purchase' && this.isHousingManager) return true;
            if (ticket.assigned_to == (this.currentUser ? this.currentUser.id : 0)) return true;
            return false;
        },
        getSectionLabel(section) {
            const labels = {
                'prize': 'استلام جائزة',
                'farm': 'استلام مزرعة',
                'purchase': 'استلام مشتريات',
                'site_issue': 'مشكلة بالموقع',
                'general': 'مشاكل عامة'
            };
            return labels[section] || section;
        },
        formatDate(date) {
            if (!date) return '';
            let d = new Date(date);
            return d.toLocaleDateString('ar-EG') + ' ' + d.toLocaleTimeString('ar-EG', {hour: '2-digit', minute:'2-digit'});
        },
        switchTab(tab) {
            this.activeTab = tab;
            this.saveTabState(tab);
            
            document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
            let target = document.getElementById('tab-' + tab);
            if (target) target.classList.add('active');
            
            if (tab === 'home') this.selectedApp = null;
            if (tab === 'dashboard') this.dashSection = 'submissions';
        },
        filterProducts(cat) { this.filterCategory = cat; },
        timeRemaining(g) {
            if (!g.ends_at) return 'غير محدد';
            let end = new Date(g.ends_at);
            let now = new Date();
            let diff = end - now;
            if (diff < 0) return '⏳ انتهى ❌';
            let days = Math.floor(diff / (1000*60*60*24));
            let hours = Math.floor((diff % (1000*60*60*24)) / (1000*60*60));
            let mins = Math.floor((diff % (1000*60*60)) / (1000*60));
            if (days > 0) return `ينتهي بعد ${days} يوم و ${hours} ساعة`;
            if (hours > 0) return `ينتهي بعد ${hours} ساعة و ${mins} دقيقة`;
            return `ينتهي بعد ${mins} دقيقة`;
        },
        isGiveawayEnded(g) {
            if (!g.ends_at) return false;
            return new Date(g.ends_at) < new Date();
        },
        fetchNotifications() {
            let fd = new FormData();
            fd.append('action', 'get_notifications');
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.notifications = data.notifications || [];
                    this.unreadCount = data.unread_count || 0;
                }
            })
            .catch(() => {});
        },
        toggleNotifications() {
            this.showNotifications = !this.showNotifications;
            if (this.showNotifications) {
                this.fetchNotifications();
            }
        },
        closeNotifications() {
            this.showNotifications = false;
        },
        markRead(notificationId) {
            let fd = new FormData();
            fd.append('action', 'mark_notification_read');
            fd.append('notification_id', notificationId);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let notif = this.notifications.find(n => n.id === notificationId);
                    if (notif) notif.is_read = 1;
                    this.unreadCount = Math.max(0, this.unreadCount - 1);
                }
            })
            .catch(() => {});
        },
        markAllRead() {
            let fd = new FormData();
            fd.append('action', 'mark_notification_read');
            fd.append('notification_id', 0);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.notifications.forEach(n => n.is_read = 1);
                    this.unreadCount = 0;
                    this.showNotification('✅ تم تحديد الكل كمقروء');
                }
            })
            .catch(() => {});
        },
        fetchSliders() {
            fetch('api/api.php?action=getSliders')
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) {
                    this.slidersList = data;
                }
            })
            .catch(() => {});
        },
        openSliderModal() {
            this.newSlider = { title: '', link: '' };
            this.sliderImageFile = null;
            document.getElementById('sliderModal').classList.add('active');
        },
        closeSliderModal() {
            document.getElementById('sliderModal').classList.remove('active');
        },
        onSliderImageChange(e) {
            const file = e.target.files[0];
            if (file) {
                this.sliderImageFile = file;
            } else {
                this.sliderImageFile = null;
            }
        },
        saveSlider() {
            let file = this.sliderImageFile;
            if (!file && this.$refs.sliderInput) {
                const input = this.$refs.sliderInput;
                if (input.files && input.files.length > 0) {
                    file = input.files[0];
                    this.sliderImageFile = file;
                }
            }
            if (!file) {
                this.showNotification('❌ يرجى اختيار صورة');
                return;
            }
            const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
            if (!allowedTypes.includes(file.type)) {
                this.showNotification('❌ نوع الملف غير مسموح. الأنواع المسموحة: JPG, PNG, WEBP, GIF');
                return;
            }
            if (file.size > 5 * 1024 * 1024) {
                this.showNotification('❌ حجم الملف يتجاوز 5 ميجابايت');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'add_slider');
            fd.append('title', this.newSlider.title || '');
            fd.append('link', this.newSlider.link || '');
            fd.append('slider_image', file);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.closeSliderModal();
                    location.reload();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(err => {
                this.showNotification('❌ حدث خطأ في الاتصال');
            });
        },
        deleteSlider(id) {
            if (!confirm('تأكيد حذف هذه الصورة؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_slider');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.slidersList = this.slidersList.filter(s => s.id !== id);
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        toggleSliderStatus(id, currentStatus) {
            let newStatus = currentStatus ? 0 : 1;
            let fd = new FormData();
            fd.append('action', 'toggle_slider_status');
            fd.append('id', id);
            fd.append('is_active', newStatus);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let slide = this.slidersList.find(s => s.id === id);
                    if (slide) slide.is_active = newStatus;
                    this.showNotification('✅ ' + data.message);
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        fetchTickets() {
            let fd = new FormData();
            fd.append('action', 'get_tickets');
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.supportTickets = data.tickets;
                }
            })
            .catch(() => {});
        },
        updateTicketStatus(ticketId, status) {
            if (!confirm('تأكيد تغيير حالة التذكرة؟')) return;
            let fd = new FormData();
            fd.append('action', 'update_ticket_status');
            fd.append('ticket_id', ticketId);
            fd.append('status', status);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.fetchTickets();
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        openAssignModal(ticket) {
            if (!this.isFounder && !(ticket.section === 'farm' && this.isFarmManager) && !(ticket.section === 'purchase' && this.isHousingManager)) {
                this.showNotification('❌ غير مصرح لك بتعيين مسؤول');
                return;
            }
            if (this.adminsList.length === 0) {
                this.showNotification('❌ لا يوجد مسؤولين متاحين');
                return;
            }
            let options = this.adminsList.map((a, i) => `${i+1}. ${a.username}`).join('\n');
            let choice = prompt('اختر المسؤول (أدخل الرقم):\n' + options);
            if (choice) {
                let idx = parseInt(choice) - 1;
                if (idx >= 0 && idx < this.adminsList.length) {
                    let adminId = this.adminsList[idx].id;
                    let fd = new FormData();
                    fd.append('action', 'assign_ticket');
                    fd.append('ticket_id', ticket.id);
                    fd.append('admin_id', adminId);
                    fd.append('csrf_token', this.csrfToken);
                    fetch('api/api.php', { method: 'POST', body: fd })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            this.showNotification('✅ ' + data.message);
                            this.fetchTickets();
                        } else {
                            this.showNotification('❌ ' + data.message);
                        }
                    })
                    .catch(() => this.showNotification('❌ حدث خطأ'));
                }
            }
        },
        openProductModal() {
            this.newProduct = { name: '', price: 0, category: 'general', iban: '' };
            this.productImageFile = null;
            document.getElementById('productModal').classList.add('active');
        },
        closeProductModal() {
            document.getElementById('productModal').classList.remove('active');
        },
        onProductImageChange(e) {
            this.productImageFile = e.target.files[0] || null;
        },
        saveProduct() {
            if (!this.newProduct.name.trim() || this.newProduct.price <= 0) {
                this.showNotification('❌ يرجى ملء جميع الحقول بشكل صحيح');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'add_product');
            fd.append('name', this.newProduct.name);
            fd.append('price', this.newProduct.price);
            fd.append('category', this.newProduct.category);
            fd.append('iban', this.newProduct.iban || '');
            fd.append('csrf_token', this.csrfToken);
            if (this.productImageFile) fd.append('image', this.productImageFile);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.products.push({
                        id: data.id,
                        name: this.newProduct.name,
                        price: parseFloat(this.newProduct.price),
                        category: this.newProduct.category,
                        iban: this.newProduct.iban || '',
                        status: 'available',
                        image: data.image || ''
                    });
                    this.showNotification('✅ تمت الإضافة بنجاح');
                    this.closeProductModal();
                } else this.showNotification('❌ ' + (data.message || 'فشلت الإضافة'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        deleteProduct(id) {
            if (!confirm('هل أنت متأكد من حذف هذا المنتج؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_product');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.products = this.products.filter(p => p.id !== id);
                    this.showNotification('✅ تم الحذف');
                } else this.showNotification('❌ ' + (data.message || 'فشل الحذف'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        openPurchaseModal(product) {
            if (product.status !== 'available') {
                this.showNotification('❌ هذا المنتج غير متاح للشراء');
                return;
            }
            this.purchasingProduct = product;
            this.paymentImageFile = null;
            document.getElementById('purchaseModal').classList.add('active');
        },
        closePurchaseModal() {
            document.getElementById('purchaseModal').classList.remove('active');
            this.purchasingProduct = null;
            this.paymentImageFile = null;
        },
        onPaymentImageChange(e) {
            this.paymentImageFile = e.target.files[0] || null;
        },
        submitPurchase() {
            if (!this.paymentImageFile) {
                this.showNotification('❌ يرجى رفع صورة إثبات الدفع');
                return;
            }
            const productId = this.purchasingProduct ? this.purchasingProduct.id : null;
            if (!productId) {
                this.showNotification('❌ حدث خطأ، يرجى المحاولة مرة أخرى');
                return;
            }
            this.purchasingLoading = true;
            let fd = new FormData();
            fd.append('action', 'purchase_product');
            fd.append('product_id', productId);
            fd.append('payment_image', this.paymentImageFile);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                this.purchasingLoading = false;
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.closePurchaseModal();
                    let product = this.products.find(p => p.id === productId);
                    if (product && product.category !== 'skins') {
                        product.status = 'pending';
                    }
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch((err) => {
                this.purchasingLoading = false;
                this.showNotification('❌ حدث خطأ في الاتصال: ' + err.message);
            });
        },
        fetchPurchases() {
            let fd = new FormData();
            fd.append('action', 'get_purchases');
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.purchasesList = data.purchases.map(p => ({ ...p, delivery_link_temp: p.delivery_link || '' }));
                }
            })
            .catch(() => {});
        },
        updatePurchase(purchaseId, status, deliveryLink, adminNotes) {
            if (!confirm('تأكيد تحديث حالة الطلب؟')) return;
            let fd = new FormData();
            fd.append('action', 'update_purchase');
            fd.append('purchase_id', purchaseId);
            fd.append('status', status);
            fd.append('delivery_link', deliveryLink || '');
            fd.append('admin_notes', adminNotes || '');
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ ' + data.message);
                    this.fetchPurchases();
                    fetch('api/api.php?action=getProducts')
                    .then(res => res.json())
                    .then(data => {
                        if (Array.isArray(data)) this.products = data;
                    })
                    .catch(() => {});
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        fetchGiveaways() {
            fetch('api/api.php?action=getGiveaways')
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) {
                    if (this.isLoggedIn) {
                        data.forEach(g => {
                            g.user_joined = false;
                        });
                    }
                    this.giveaways = data;
                }
            })
            .catch(() => {});
        },
        openGiveawayModal() {
            this.newGiveaway = { title: '', description: '', prize: '', ends_at: '' };
            document.getElementById('giveawayModal').classList.add('active');
        },
        closeGiveawayModal() {
            document.getElementById('giveawayModal').classList.remove('active');
        },
        saveGiveaway() {
            if (!this.newGiveaway.title.trim() || !this.newGiveaway.prize.trim()) {
                this.showNotification('❌ يرجى ملء جميع الحقول');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'add_giveaway');
            fd.append('title', this.newGiveaway.title);
            fd.append('description', this.newGiveaway.description);
            fd.append('prize', this.newGiveaway.prize);
            fd.append('ends_at', this.newGiveaway.ends_at || '');
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.giveaways.push({
                        id: data.id,
                        title: this.newGiveaway.title,
                        description: this.newGiveaway.description,
                        prize: this.newGiveaway.prize,
                        ends_at: this.newGiveaway.ends_at || null,
                        entries_count: 0,
                        user_joined: false,
                        winner_id: null,
                        winner_name: null,
                        drawn: 0
                    });
                    this.showNotification('✅ تمت إضافة الهبة');
                    this.closeGiveawayModal();
                } else this.showNotification('❌ ' + (data.message || 'فشلت الإضافة'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        deleteGiveaway(id) {
            if (!confirm('هل أنت متأكد من حذف هذه الهبة؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_giveaway');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.giveaways = this.giveaways.filter(g => g.id !== id);
                    this.showNotification('✅ تم الحذف');
                } else this.showNotification('❌ ' + (data.message || 'فشل الحذف'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        joinGiveaway(id) {
            if (!this.isLoggedIn) {
                this.showNotification('❌ يجب تسجيل الدخول أولاً');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'join_giveaway');
            fd.append('giveaway_id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let g = this.giveaways.find(item => item.id === id);
                    if (g) {
                        g.user_joined = true;
                        g.entries_count = (g.entries_count || 0) + 1;
                    }
                    this.showNotification('✅ ' + data.message);
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        drawGiveaway(id) {
            if (!this.isFounder) {
                this.showNotification('❌ غير مصرح');
                return;
            }
            if (!confirm('تأكيد سحب الفائز؟')) return;
            let fd = new FormData();
            fd.append('action', 'draw_giveaway');
            fd.append('giveaway_id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let g = this.giveaways.find(item => item.id === id);
                    if (g) {
                        g.winner_id = data.winner_id;
                        g.winner_name = data.winner_name;
                        g.drawn = 1;
                    }
                    this.showNotification('✅ ' + data.message + ' - الفائز: ' + data.winner_name);
                } else {
                    this.showNotification('❌ ' + data.message);
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        toggleUserRole(user, roleId) {
            if (!this.isFounder) {
                this.showNotification('❌ فقط الفاوندر يمكنه تعديل الرتب');
                return;
            }
            let idx = user.role_ids.indexOf(roleId);
            if (idx === -1) user.role_ids.push(roleId); else user.role_ids.splice(idx, 1);
            let fd = new FormData();
            fd.append('action', 'update_user_roles');
            fd.append('user_id', user.id);
            fd.append('role_ids', JSON.stringify(user.role_ids));
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) this.showNotification('✅ تم تحديث الرتب');
                else this.showNotification('❌ ' + (data.message || 'فشل التحديث'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        toggleUserJob(user, jobId) {
            if (!this.isFounder) {
                this.showNotification('❌ فقط الفاوندر يمكنه تعديل الوظائف');
                return;
            }
            if (!user.job_ids) user.job_ids = [];
            let idx = user.job_ids.indexOf(jobId);
            if (idx === -1) user.job_ids.push(jobId); else user.job_ids.splice(idx, 1);
            let fd = new FormData();
            fd.append('action', 'update_user_jobs');
            fd.append('user_id', user.id);
            fd.append('job_ids', JSON.stringify(user.job_ids));
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) this.showNotification('✅ تم تحديث الوظائف');
                else this.showNotification('❌ ' + (data.message || 'فشل التحديث'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        fetchJobs() {
            fetch('api/api.php?action=getJobTitles')
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data)) this.jobsList = data;
            })
            .catch(() => {});
        },
        addJob() {
            if (!this.newJob.trim()) {
                this.showNotification('❌ أدخل اسم الوظيفة');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'add_job');
            fd.append('name', this.newJob.trim());
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.jobsList.push({ id: data.id, name: this.newJob.trim() });
                    this.newJob = '';
                    this.showNotification('✅ تمت إضافة الوظيفة');
                } else this.showNotification('❌ ' + (data.message || 'فشلت الإضافة'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        deleteJob(id) {
            if (!confirm('تأكيد حذف الوظيفة؟')) return;
            let fd = new FormData();
            fd.append('action', 'delete_job');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.jobsList = this.jobsList.filter(j => j.id !== id);
                    this.showNotification('✅ تم الحذف');
                } else this.showNotification('❌ ' + (data.message || 'فشل الحذف'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        fetchAppTypes() { },
        openAppTypeModal(app = null) {
            if (app) {
                this.editingAppType = true;
                this.appTypeForm = {
                    id: app.id,
                    name: app.name,
                    description: app.description || '',
                    manager_role_key: app.manager_role_key || '',
                    min_hours: app.min_hours || 0,
                    min_history: app.min_history || 0,
                    min_money: app.min_money || 0,
                    requirements: app.requirements || ''
                };
            } else {
                this.editingAppType = false;
                this.appTypeForm = { id: null, name: '', description: '', manager_role_key: '', min_hours: 0, min_history: 0, min_money: 0, requirements: '' };
            }
            document.getElementById('appTypeModal').classList.add('active');
        },
        closeAppTypeModal() {
            document.getElementById('appTypeModal').classList.remove('active');
        },
        saveAppType() {
            if (!this.appTypeForm.name.trim()) {
                this.showNotification('❌ أدخل اسم التقديم');
                return;
            }
            let action = this.editingAppType ? 'update_application_type' : 'add_application_type';
            let fd = new FormData();
            fd.append('action', action);
            fd.append('name', this.appTypeForm.name);
            fd.append('description', this.appTypeForm.description);
            fd.append('manager_role_key', this.appTypeForm.manager_role_key || '');
            fd.append('min_hours', this.appTypeForm.min_hours || 0);
            fd.append('min_history', this.appTypeForm.min_history || 0);
            fd.append('min_money', this.appTypeForm.min_money || 0);
            fd.append('requirements', this.appTypeForm.requirements || '');
            if (this.editingAppType) fd.append('id', this.appTypeForm.id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (this.editingAppType) {
                        let app = this.applicationTypes.find(a => a.id === this.appTypeForm.id);
                        if (app) {
                            app.name = this.appTypeForm.name;
                            app.description = this.appTypeForm.description;
                            app.manager_role_key = this.appTypeForm.manager_role_key || null;
                            app.min_hours = this.appTypeForm.min_hours || 0;
                            app.min_history = this.appTypeForm.min_history || 0;
                            app.min_money = this.appTypeForm.min_money || 0;
                            app.requirements = this.appTypeForm.requirements || '';
                        }
                        this.showNotification('✅ تم التحديث');
                    } else {
                        this.applicationTypes.push({
                            id: data.id,
                            name: this.appTypeForm.name,
                            description: this.appTypeForm.description,
                            is_open: 1,
                            manager_role_key: this.appTypeForm.manager_role_key || null,
                            min_hours: this.appTypeForm.min_hours || 0,
                            min_history: this.appTypeForm.min_history || 0,
                            min_money: this.appTypeForm.min_money || 0,
                            requirements: this.appTypeForm.requirements || '',
                            questions: []
                        });
                        this.showNotification('✅ تمت إضافة نوع التقديم');
                    }
                    this.closeAppTypeModal();
                } else this.showNotification('❌ ' + (data.message || 'فشلت العملية'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        editAppType(id) {
            let app = this.applicationTypes.find(a => a.id === id);
            if (app) this.openAppTypeModal(app);
        },
        deleteAppType(id) {
            if (!confirm('تأكيد حذف نوع التقديم؟ سيتم حذف جميع أسئلته أيضاً!')) return;
            let fd = new FormData();
            fd.append('action', 'delete_application_type');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.applicationTypes = this.applicationTypes.filter(a => a.id !== id);
                    this.showNotification('✅ تم الحذف');
                } else this.showNotification('❌ ' + (data.message || 'فشل الحذف'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        addQuestion(appId) {
            this.editingQuestion = false;
            this.currentAppId = appId;
            this.currentQuestionIdx = null;
            this.questionForm = { id: null, text: '', field_type: 'text', optionsArray: [], required: false };
            document.getElementById('questionModal').classList.add('active');
        },
        editQuestion(appId, idx) {
            let app = this.applicationTypes.find(a => a.id === appId);
            if (!app) return;
            let q = app.questions[idx];
            if (!q) return;
            this.editingQuestion = true;
            this.currentAppId = appId;
            this.currentQuestionIdx = idx;
            this.questionForm = {
                id: q.id,
                text: q.question_text,
                field_type: q.field_type,
                optionsArray: JSON.parse(q.options || '[]'),
                required: q.required == 1
            };
            document.getElementById('questionModal').classList.add('active');
        },
        closeQuestionModal() {
            document.getElementById('questionModal').classList.remove('active');
        },
        onFieldTypeChange() {
            if (this.questionForm.field_type !== 'select') {
                this.questionForm.optionsArray = [];
            }
        },
        addOption() {
            this.questionForm.optionsArray.push('');
        },
        removeOption(idx) {
            this.questionForm.optionsArray.splice(idx, 1);
        },
        saveQuestion() {
            if (!this.questionForm.text.trim()) {
                this.showNotification('❌ يرجى كتابة نص السؤال');
                return;
            }
            let optionsJson = JSON.stringify(this.questionForm.optionsArray);
            let action = this.editingQuestion ? 'update_question' : 'add_question';
            let fd = new FormData();
            fd.append('action', action);
            fd.append('type_id', this.currentAppId);
            fd.append('text', this.questionForm.text);
            fd.append('field_type', this.questionForm.field_type);
            fd.append('options', optionsJson);
            fd.append('required', this.questionForm.required ? 1 : 0);
            if (this.editingQuestion) fd.append('id', this.questionForm.id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let app = this.applicationTypes.find(a => a.id === this.currentAppId);
                    if (!app) return;
                    if (this.editingQuestion) {
                        let q = app.questions[this.currentQuestionIdx];
                        if (q) {
                            q.question_text = this.questionForm.text;
                            q.field_type = this.questionForm.field_type;
                            q.options = optionsJson;
                            q.required = this.questionForm.required ? 1 : 0;
                        }
                        this.showNotification('✅ تم التحديث');
                    } else {
                        app.questions.push({
                            id: data.id,
                            question_text: this.questionForm.text,
                            field_type: this.questionForm.field_type,
                            options: optionsJson,
                            required: this.questionForm.required ? 1 : 0
                        });
                        this.showNotification('✅ تمت الإضافة');
                    }
                    this.closeQuestionModal();
                } else this.showNotification('❌ ' + (data.message || 'فشلت العملية'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        removeQuestion(appId, idx) {
            let app = this.applicationTypes.find(a => a.id === appId);
            if (!app) return;
            let q = app.questions[idx];
            if (!q) return;
            if (!confirm('هل أنت متأكد من حذف هذا السؤال؟')) return;
            let fd = new FormData();
            fd.append('action', 'remove_question');
            fd.append('id', q.id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    app.questions.splice(idx, 1);
                    this.showNotification('✅ تم الحذف');
                } else this.showNotification('❌ ' + (data.message || 'فشل الحذف'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        viewAnswers(id) {
            let fd = new FormData();
            fd.append('action', 'get_submission_answers');
            fd.append('id', id);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.viewingSubmission = data.submission;
                    this.viewingAnswers = data.answers;
                    this.viewingQuestions = data.questions;
                    document.getElementById('answersModal').classList.add('active');
                } else {
                    this.showNotification('❌ ' + (data.message || 'فشل جلب البيانات'));
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        closeAnswersModal() {
            document.getElementById('answersModal').classList.remove('active');
            this.viewingSubmission = null;
            this.viewingAnswers = null;
            this.viewingQuestions = {};
        },
        reviewSubmissionFromModal(status) {
            if (!this.viewingSubmission) return;
            this.reviewSubmission(this.viewingSubmission.id, status);
            this.closeAnswersModal();
        },
        reviewSubmission(id, status) {
            if (!this.canManageSubmission({ id: id, manager_role_key: this.submissions.find(s => s.id === id)?.manager_role_key })) {
                this.showNotification('❌ غير مصرح لك بمراجعة هذا الطلب');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'review_submission');
            fd.append('id', id);
            fd.append('status', status);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let sub = this.submissions.find(s => s.id === id);
                    if (sub) sub.status = status;
                    this.showNotification(status === 'accepted' ? '✅ تم القبول' : '❌ تم الرفض');
                } else this.showNotification('❌ ' + (data.message || 'فشل التحديث'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        toggleApp(id) {
            let app = this.applicationTypes.find(a => a.id === id);
            if (!app) return;
            let newStatus = app.is_open ? 0 : 1;
            let fd = new FormData();
            fd.append('action', 'toggle_app');
            fd.append('id', id);
            fd.append('is_open', newStatus);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    app.is_open = !!newStatus;
                    this.showNotification('✅ تم ' + (app.is_open ? 'فتح' : 'غلق') + ' التقديم');
                } else this.showNotification('❌ ' + (data.message || 'فشل التحديث'));
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        },
        updateProfile() {
            if (!this.currentUser || !this.currentUser.username.trim()) {
                this.showNotification('❌ الاسم لا يمكن أن يكون فارغاً');
                return;
            }
            let fd = new FormData();
            fd.append('action', 'update_profile');
            fd.append('new_name', this.currentUser.username);
            fd.append('csrf_token', this.csrfToken);
            fetch('api/api.php', { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.showNotification('✅ تم تحديث الاسم');
                } else {
                    this.showNotification('❌ ' + (data.message || 'فشل التحديث'));
                }
            })
            .catch(() => this.showNotification('❌ حدث خطأ'));
        }
    },
    mounted() {
        // 🔥 إصلاح: رجع الصفحة لأولها عند التحميل
        window.scrollTo(0, 0);

        // التعامل مع الهاش عند التحميل (لما يجي من صفحة خارجية)
        const hash = window.location.hash;
        if (hash) {
            const tab = hash.replace('#tab-', '');
            const validTabs = ['home', 'store', 'applications', 'giveaways', 'profile', 'dashboard'];
            if (validTabs.includes(tab)) {
                this.switchTab(tab);
                // 🔴 السطر اللي بيبوظ الدنيا اتعطل نهائياً
                // if (history.pushState) {
                //     history.pushState(null, null, window.location.pathname);
                // }
                
                if (this.isLoggedIn) {
                    this.fetchNotifications();
                }
                this.refreshInterval = setInterval(() => {
                    this.fetchGiveaways();
                    if (this.isLoggedIn && !this.showNotifications) {
                        this.fetchNotifications();
                    }
                }, 30000);
                return;
            }
        }

        // لو مفيش هاش، نستخدم التبويبة المحفوظة
        let savedTab = this.getSavedTab();
        const validTabs = ['home', 'store', 'applications', 'giveaways', 'profile', 'dashboard'];
        if (validTabs.includes(savedTab)) {
            this.switchTab(savedTab);
        } else {
            this.switchTab('home');
        }
        
        if (this.isLoggedIn) {
            this.fetchNotifications();
        }
        
        this.refreshInterval = setInterval(() => {
            this.fetchGiveaways();
            if (this.isLoggedIn && !this.showNotifications) {
                this.fetchNotifications();
            }
        }, 30000);
    },
    beforeDestroy() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
    }
});

// السلايدر
let currentSlide = 0;
const slides = document.querySelectorAll('#slider img');
if (slides.length > 0) {
    setInterval(() => {
        slides.forEach(img => img.classList.remove('active'));
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].classList.add('active');
    }, 4000);
}