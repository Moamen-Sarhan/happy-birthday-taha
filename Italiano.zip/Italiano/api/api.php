<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../inc/config.php';
require_once __DIR__ . '/../inc/functions.php';

// === إجراءات GET ===
$action = $_GET['action'] ?? '';

if ($action === 'getProducts') {
    $stmt = $pdo->query("SELECT * FROM products");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}
if ($action === 'getApplicationTypes') {
    $stmt = $pdo->query("SELECT * FROM application_types");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}
if ($action === 'getSubmissions') {
    $stmt = $pdo->query("SELECT s.*, u.username FROM submissions s JOIN users u ON s.user_id = u.id");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}
if ($action === 'getProperties') {
    $stmt = $pdo->query("SELECT * FROM properties ORDER BY created_at DESC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}
if ($action === 'getVehicles') {
    $stmt = $pdo->query("SELECT * FROM vehicles ORDER BY created_at DESC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}
if ($action === 'getJobTitles') {
    $stmt = $pdo->query("SELECT * FROM job_titles ORDER BY name");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}
if ($action === 'getGiveaways') {
    $stmt = $pdo->query("
        SELECT g.*, u.username as winner_name,
        (SELECT COUNT(*) FROM giveaway_entries WHERE giveaway_id = g.id) as entries_count
        FROM giveaways g
        LEFT JOIN users u ON g.winner_id = u.id
        ORDER BY g.created_at DESC
    ");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}
if ($action === 'getSliders') {
    $stmt = $pdo->query("SELECT * FROM sliders ORDER BY sort_order ASC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// === إجراءات POST ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!verifyCSRFToken($csrf_token)) {
        echo json_encode(['success' => false, 'message' => 'طلب غير صالح (CSRF)']);
        exit;
    }

    $action = $_POST['action'] ?? '';
    $response = ['success' => false, 'message' => 'حدث خطأ'];

    // 🔥 تحديث الجلسة فوراً من الداتابيس (مهم جداً هنا)
    $userId = $_SESSION['user_id'] ?? 0;
    $sessionRoles = [];
    if ($userId) {
        $sessionRoles = getUserRolesFromDB($userId, $pdo);
        $_SESSION['roles'] = $sessionRoles;
    }

    $isFounder = in_array('founder', $sessionRoles, true);
    $isSkinDesigner = in_array('skin_designer', $sessionRoles, true);
    $isEngineSeller = in_array('engine_seller', $sessionRoles, true);
    $isFarmManager = in_array('farm_rental_manager', $sessionRoles, true);
    $isHousingManager = in_array('housing_apps_manager', $sessionRoles, true);
    
    $canManageAppType = function($managerRoleKey) use ($sessionRoles, $isFounder) {
        if ($isFounder) return true;
        if (!$managerRoleKey) return false;
        return in_array($managerRoleKey, $sessionRoles, true);
    };

    try {
        // ===== حذف طلب شراء =====
        if ($action === 'delete_purchase') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $purchaseId = intval($_POST['purchase_id'] ?? 0);
                // 🔥 جلب فئة المنتج للتأكد
                $chkStmt = $pdo->prepare("
                    SELECT pr.category 
                    FROM purchases p 
                    JOIN products pr ON p.product_id = pr.id 
                    WHERE p.id = ?
                ");
                $chkStmt->execute([$purchaseId]);
                $cat = $chkStmt->fetchColumn();
                
                if (!$isFounder) {
                    if ($cat === 'engines' && !$isEngineSeller) {
                        $response = ['success' => false, 'message' => 'فقط الفاوندر وبائع المحركات يمكنهم حذف طلبات المحركات'];
                        echo json_encode($response);
                        exit;
                    }
                    if (($cat === 'male_skins' || $cat === 'female_skins') && !$isSkinDesigner) {
                        $response = ['success' => false, 'message' => 'فقط الفاوندر ومصمم السكنات يمكنهم حذف طلبات السكنات'];
                        echo json_encode($response);
                        exit;
                    }
                }
                $stmt = $pdo->prepare("DELETE FROM purchases WHERE id = ?");
                $stmt->execute([$purchaseId]);
                $response = ['success' => true, 'message' => 'تم حذف طلب الشراء'];
            }
        }
        // ===== حذف تقديم =====
        elseif ($action === 'delete_submission') {
            $submissionId = intval($_POST['submission_id'] ?? 0);
            $chk = $pdo->prepare("
                SELECT a.manager_role_key 
                FROM submissions s 
                JOIN application_types a ON s.type_id = a.id 
                WHERE s.id = ?
            ");
            $chk->execute([$submissionId]);
            $row = $chk->fetch(PDO::FETCH_ASSOC);
            $managerRoleKey = $row['manager_role_key'] ?? null;
            if (!$canManageAppType($managerRoleKey)) {
                $response = ['success' => false, 'message' => 'غير مصرح لك بحذف هذا الطلب'];
            } else {
                $stmt = $pdo->prepare("DELETE FROM submissions WHERE id = ?");
                $stmt->execute([$submissionId]);
                $response = ['success' => true, 'message' => 'تم حذف التقديم'];
            }
        }
        // ===== update_product_status =====
        elseif ($action === 'update_product_status') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $status = $_POST['status'] ?? 'available';
                $allowed = ['available', 'sold', 'pending'];
                if (!in_array($status, $allowed)) {
                    $response = ['success' => false, 'message' => 'حالة غير صالحة'];
                } else {
                    $stmt = $pdo->prepare("UPDATE products SET status = ? WHERE id = ?");
                    $stmt->execute([$status, $id]);
                    $response = ['success' => true, 'message' => 'تم تحديث حالة المنتج'];
                }
            }
        }
        // ===== add_product =====
        elseif ($action === 'add_product') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح. رتبك الحالية: ' . implode(', ', $sessionRoles)];
                echo json_encode($response);
                exit;
            } else {
                $name = trim($_POST['name'] ?? '');
                $category = trim($_POST['category'] ?? 'male_skins');
                $price = floatval($_POST['price'] ?? 0);
                $iban = trim($_POST['iban'] ?? '');
                
                // 🔥 منع مصمم السكنات من إضافة محركات، ومنع بائع المحركات من إضافة سكنات
                if ($category === 'engines' && !$isFounder && !$isEngineSeller) {
                    $response = ['success' => false, 'message' => 'فقط الفاوندر وبائع المحركات يمكنهم إضافة المحركات'];
                    echo json_encode($response);
                    exit;
                }
                if (($category === 'male_skins' || $category === 'female_skins') && !$isFounder && !$isSkinDesigner) {
                    $response = ['success' => false, 'message' => 'فقط الفاوندر ومصمم السكنات يمكنهم إضافة السكنات'];
                    echo json_encode($response);
                    exit;
                }

                $uploadResult = uploadImage('image', 'products');
                $imagePath = null;
                if ($uploadResult['success']) {
                    $imagePath = $uploadResult['path'];
                } elseif (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
                    $response = ['success' => false, 'message' => 'فشل رفع الصورة: ' . $uploadResult['message']];
                    echo json_encode($response);
                    exit;
                }
                $stmt = $pdo->prepare("INSERT INTO products (name, category, price, iban, image, status) VALUES (?, ?, ?, ?, ?, 'available')");
                $stmt->execute([$name, $category, $price, $iban, $imagePath]);
                $response = ['success' => true, 'message' => 'تمت الإضافة', 'id' => $pdo->lastInsertId(), 'image' => $imagePath];
            }
        }
        // ===== delete_product =====
        elseif ($action === 'delete_product') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
                $stmt->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ===== purchase_product =====
        elseif ($action === 'purchase_product') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول أولاً'];
            } else {
                $product_id = intval($_POST['product_id'] ?? 0);
                if (!isset($_FILES['payment_image']) || $_FILES['payment_image']['error'] === UPLOAD_ERR_NO_FILE) {
                    $response = ['success' => false, 'message' => 'يرجى رفع صورة إثبات الدفع'];
                } else {
                    $uploadResult = uploadImage('payment_image', 'payments');
                    if (!$uploadResult['success']) {
                        $response = ['success' => false, 'message' => 'فشل رفع الصورة: ' . $uploadResult['message']];
                    } else {
                        $imagePath = $uploadResult['path'];
                        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND status = 'available'");
                        $stmt->execute([$product_id]);
                        $product = $stmt->fetch(PDO::FETCH_ASSOC);
                        if (!$product) {
                            $response = ['success' => false, 'message' => 'المنتج غير متاح أو تم بيعه'];
                        } else {
                            try {
                                $stmt = $pdo->prepare("INSERT INTO purchases (product_id, user_id, amount, iban_used, payment_image, status) VALUES (?, ?, ?, ?, ?, 'pending')");
                                $stmt->execute([$product_id, $userId, $product['price'], $product['iban'] ?? '', $imagePath]);

                                // 🔥 السكنات الرجالي والحريمي لا تتغير حالتها أبداً
                                if ($product['category'] !== 'male_skins' && $product['category'] !== 'female_skins') {
                                    $stmt = $pdo->prepare("UPDATE products SET status = 'pending' WHERE id = ?");
                                    $stmt->execute([$product_id]);
                                }

                                $response = ['success' => true, 'message' => 'تم إرسال طلب الشراء بنجاح، في انتظار مراجعة الإدارة'];
                            } catch (PDOException $e) {
                                error_log('Purchase error: ' . $e->getMessage());
                                $response = ['success' => false, 'message' => 'حدث خطأ أثناء معالجة الطلب'];
                            }
                        }
                    }
                }
            }
        }
        // ===== get_purchases =====
        elseif ($action === 'get_purchases') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $stmt = $pdo->prepare("
                    SELECT p.*, u.username as user_name, pr.name as product_name, pr.category
                    FROM purchases p
                    JOIN users u ON p.user_id = u.id
                    JOIN products pr ON p.product_id = pr.id
                    ORDER BY p.created_at DESC
                ");
                $stmt->execute();
                $purchases = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                // تصفية النتائج حسب الرتبة
                if (!$isFounder) {
                    if ($isSkinDesigner) {
                        $purchases = array_filter($purchases, function($p) {
                            return $p['category'] === 'male_skins' || $p['category'] === 'female_skins';
                        });
                    } elseif ($isEngineSeller) {
                        $purchases = array_filter($purchases, function($p) {
                            return $p['category'] === 'engines';
                        });
                    } else {
                        $purchases = [];
                    }
                }
                
                $response = ['success' => true, 'purchases' => array_values($purchases)];
            }
        }
        // ===== update_purchase =====
        elseif ($action === 'update_purchase') {
            if (!$isFounder && !$isSkinDesigner && !$isEngineSeller) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $purchase_id = intval($_POST['purchase_id'] ?? 0);
                $status = $_POST['status'] ?? 'pending';
                $delivery_link = trim($_POST['delivery_link'] ?? '');
                $admin_notes = trim($_POST['admin_notes'] ?? '');
                $stmt = $pdo->prepare("SELECT p.*, pr.category, pr.id as product_id, pr.name as product_name, p.user_id FROM purchases p JOIN products pr ON p.product_id = pr.id WHERE p.id = ?");
                $stmt->execute([$purchase_id]);
                $purchase = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$purchase) {
                    $response = ['success' => false, 'message' => 'الطلب غير موجود'];
                } else {
                    // 🔥 منع الصلاحيات المتقاطعة
                    if (!$isFounder) {
                        if ($purchase['category'] === 'engines' && !$isEngineSeller) {
                            $response = ['success' => false, 'message' => 'فقط الفاوندر وبائع المحركات يمكنهم مراجعة طلبات المحركات'];
                            echo json_encode($response);
                            exit;
                        }
                        if (($purchase['category'] === 'male_skins' || $purchase['category'] === 'female_skins') && !$isSkinDesigner) {
                            $response = ['success' => false, 'message' => 'فقط الفاوندر ومصمم السكنات يمكنهم مراجعة طلبات السكنات'];
                            echo json_encode($response);
                            exit;
                        }
                    }

                    $stmt = $pdo->prepare("UPDATE purchases SET status = ?, admin_notes = ?, delivery_link = ? WHERE id = ?");
                    $stmt->execute([$status, $admin_notes, $delivery_link, $purchase_id]);

                    // 🔥 السكنات الرجالي والحريمي لا تتغير حالتها أبداً
                    if ($purchase['category'] !== 'male_skins' && $purchase['category'] !== 'female_skins') {
                        if ($status === 'approved' || $status === 'delivered') {
                            $stmt = $pdo->prepare("UPDATE products SET status = 'sold' WHERE id = ?");
                            $stmt->execute([$purchase['product_id']]);
                        } elseif ($status === 'rejected') {
                            $stmt = $pdo->prepare("UPDATE products SET status = 'available' WHERE id = ?");
                            $stmt->execute([$purchase['product_id']]);
                        }
                    }

                    // 🔥 إضافة تذكرة استلام للمحركات عند الموافقة
                    if ($status === 'approved' && $purchase['category'] === 'engines') {
                        $userStmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                        $userStmt->execute([$purchase['user_id']]);
                        $user = $userStmt->fetch(PDO::FETCH_ASSOC);
                        
                        createBotTicket($pdo, $purchase['user_id'], 'engine',
                            'استلام محرك - ' . $user['username'],
                            'تم تأكيد شراء المحرك "' . $purchase['product_name'] . '". يرجى التواصل مع الإدارة لاستلام المحرك.'
                        );
                    }

                    if ($status === 'delivered' && !empty($delivery_link)) {
                        $notifStmt = $pdo->prepare("
                            INSERT INTO notifications (user_id, type, title, message, link) 
                            VALUES (?, 'delivery', '✅ تم تسليم طلبك!', ?, ?)
                        ");
                        $notifStmt->execute([
                            $purchase['user_id'],
                            'تم تسليم المنتج "' . $purchase['product_name'] . '"، يمكنك استلامه من خلال الرابط التالي:',
                            $delivery_link
                        ]);

                        // إرسال الرابط عبر البوت
                        sendBotDM($pdo, $purchase['user_id'], 
                            '✅ تم تسليم المنتج!', 
                            'تم تسليم المنتج "' . $purchase['product_name'] . '" الذي اشتريته. يمكنك استلامه من خلال الرابط التالي:',
                            $delivery_link
                        );
                    }
                    if ($status === 'approved' && $purchase['status'] !== 'approved') {
                        $notifStmt = $pdo->prepare("
                            INSERT INTO notifications (user_id, type, title, message, link) 
                            VALUES (?, 'purchase', '✅ تم تأكيد طلب الشراء!', ?, ?)
                        ");
                        $notifStmt->execute([
                            $purchase['user_id'],
                            'تم تأكيد طلب شراء "' . $purchase['product_name'] . '" بنجاح، جاري تجهيز الطلب.',
                            null
                        ]);
                    }
                    $response = ['success' => true, 'message' => 'تم تحديث الطلب'];
                }
            }
        }
        // ===== get_notifications =====
        elseif ($action === 'get_notifications') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول'];
            } else {
                $stmt = $pdo->prepare("
                    SELECT * FROM notifications 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT 50
                ");
                $stmt->execute([$userId]);
                $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
                $stmt->execute([$userId]);
                $unreadCount = (int) $stmt->fetchColumn();
                $response = ['success' => true, 'notifications' => $notifications, 'unread_count' => $unreadCount];
            }
        }
        // ===== mark_notification_read =====
        elseif ($action === 'mark_notification_read') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول'];
            } else {
                $notification_id = intval($_POST['notification_id'] ?? 0);
                if ($notification_id > 0) {
                    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
                    $stmt->execute([$notification_id, $userId]);
                } else {
                    $stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
                    $stmt->execute([$userId]);
                }
                $response = ['success' => true, 'message' => 'تم التحديث'];
            }
        }
        // ===== delete_read_notifications =====
        elseif ($action === 'delete_read_notifications') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول'];
            } else {
                try {
                    $stmt = $pdo->prepare("DELETE FROM notifications WHERE user_id = ? AND is_read = 1");
                    $stmt->execute([$userId]);
                    $response = ['success' => true, 'message' => 'تم حذف الإشعارات المقروءة بنجاح'];
                } catch (PDOException $e) {
                    $response = ['success' => false, 'message' => 'حدث خطأ أثناء الحذف'];
                }
            }
        }
        // ===== add_slider =====
        elseif ($action === 'add_slider') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $title = trim($_POST['title'] ?? '');
                $link = trim($_POST['link'] ?? '');
                $uploadResult = uploadImage('slider_image', 'slider');
                if (!$uploadResult['success']) {
                    $response = ['success' => false, 'message' => 'فشل رفع الصورة: ' . $uploadResult['message']];
                } else {
                    $imagePath = $uploadResult['path'];
                    try {
                        $stmt = $pdo->prepare("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM sliders");
                        $stmt->execute();
                        $nextSort = $stmt->fetchColumn();
                        $stmt = $pdo->prepare("INSERT INTO sliders (image, title, link, sort_order, is_active) VALUES (?, ?, ?, ?, 1)");
                        $stmt->execute([$imagePath, $title, $link, $nextSort]);
                        $response = ['success' => true, 'message' => 'تمت إضافة الصورة بنجاح'];
                    } catch (PDOException $e) {
                        error_log('Slider insert error: ' . $e->getMessage());
                        $response = ['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()];
                    }
                }
            }
        }
        // ===== delete_slider =====
        elseif ($action === 'delete_slider') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("DELETE FROM sliders WHERE id = ?");
                $stmt->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ===== toggle_slider_status =====
        elseif ($action === 'toggle_slider_status') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $is_active = intval($_POST['is_active'] ?? 1);
                try {
                    $stmt = $pdo->prepare("UPDATE sliders SET is_active = ? WHERE id = ?");
                    $stmt->execute([$is_active, $id]);
                    $response = ['success' => true, 'message' => 'تم تحديث الحالة'];
                } catch (PDOException $e) {
                    error_log('Toggle slider status error: ' . $e->getMessage());
                    $response = ['success' => false, 'message' => 'خطأ في قاعدة البيانات: ' . $e->getMessage()];
                }
            }
        }
        // ===== toggle_app =====
        elseif ($action === 'toggle_app') {
            $id = intval($_POST['id'] ?? 0);
            $is_open = intval($_POST['is_open'] ?? 1);
            $chk = $pdo->prepare("SELECT manager_role_key, name FROM application_types WHERE id = ?");
            $chk->execute([$id]);
            $row = $chk->fetch(PDO::FETCH_ASSOC);
            $managerRoleKey = $row['manager_role_key'] ?? null;
            if (!$isFounder && !in_array($managerRoleKey, $sessionRoles, true)) {
                $response = ['success' => false, 'message' => 'غير مصرح لك بإدارة هذا التقديم'];
            } else {
                $stmt = $pdo->prepare("UPDATE application_types SET is_open = ? WHERE id = ?");
                $stmt->execute([$is_open, $id]);
                if ($is_open == 1) {
                    $appName = $row['name'] ?? 'تقديم';
                    $title = '📢 تم فتح تقديم جديد!';
                    $message = 'تم فتح تقديم "' . $appName . '" في الموقع. يمكنك التقديم الآن من خلال قسم التقديمات.';
                    $usersStmt = $pdo->query("SELECT id FROM users");
                    $users = $usersStmt->fetchAll(PDO::FETCH_COLUMN);
                    foreach ($users as $userId) {
                        sendBotDM($pdo, $userId, $title, $message);
                    }
                }
                $response = ['success' => true, 'message' => 'تم التحديث'];
            }
        }
        // ===== delete_giveaway =====
        elseif ($action === 'delete_giveaway') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("DELETE FROM giveaways WHERE id = ?");
                $stmt->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ===== join_giveaway =====
        elseif ($action === 'join_giveaway') {
            if (!$userId) {
                $response = ['success' => false, 'message' => 'يجب تسجيل الدخول أولاً'];
            } else {
                $giveaway_id = intval($_POST['giveaway_id'] ?? 0);
                $check = $pdo->prepare("SELECT title, ends_at, drawn FROM giveaways WHERE id = ?");
                $check->execute([$giveaway_id]);
                $row = $check->fetch(PDO::FETCH_ASSOC);
                if (!$row) {
                    $response = ['success' => false, 'message' => 'الجيفاواي غير موجودة'];
                } elseif ($row['drawn']) {
                    $response = ['success' => false, 'message' => 'تم السحب مسبقاً'];
                } elseif ($row['ends_at'] && strtotime($row['ends_at']) < time()) {
                    $response = ['success' => false, 'message' => 'انتهت صلاحية هذه الهبة'];
                } else {
                    $checkEntry = $pdo->prepare("SELECT 1 FROM giveaway_entries WHERE giveaway_id = ? AND user_id = ?");
                    $checkEntry->execute([$giveaway_id, $userId]);
                    if ($checkEntry->fetchColumn()) {
                        $response = ['success' => false, 'message' => 'أنت مشترك بالفعل'];
                    } else {
                        $stmt = $pdo->prepare("INSERT INTO giveaway_entries (giveaway_id, user_id) VALUES (?, ?)");
                        $stmt->execute([$giveaway_id, $userId]);
                        $title = '✅ تم الاشتراك في الجيفاواي';
                        $message = 'لقد اشتركت بنجاح في الجيفاواي "' . $row['title'] . '". حظاً موفقاً!';
                        addNotification($pdo, $userId, 'giveaway', $title, $message);
                        sendBotDM($pdo, $userId, $title, $message);
                        $response = ['success' => true, 'message' => 'تم الاشتراك بنجاح'];
                    }
                }
            }
        }
        // ===== draw_giveaway =====
        elseif ($action === 'draw_giveaway') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $giveaway_id = intval($_POST['giveaway_id'] ?? 0);
                $check = $pdo->prepare("SELECT * FROM giveaways WHERE id = ?");
                $check->execute([$giveaway_id]);
                $giveaway = $check->fetch(PDO::FETCH_ASSOC);
                if (!$giveaway) {
                    $response = ['success' => false, 'message' => 'الجيفاواي غير موجودة'];
                } elseif ($giveaway['drawn']) {
                    $response = ['success' => false, 'message' => 'تم السحب مسبقاً'];
                } elseif ($giveaway['ends_at'] && strtotime($giveaway['ends_at']) < time()) {
                    $response = ['success' => false, 'message' => 'انتهت صلاحية الهبة، يتم السحب تلقائياً'];
                } else {
                    $stmt = $pdo->prepare("SELECT user_id FROM giveaway_entries WHERE giveaway_id = ? ORDER BY RAND() LIMIT 1");
                    $stmt->execute([$giveaway_id]);
                    $winner = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($winner) {
                        $winner_id = $winner['user_id'];
                        $update = $pdo->prepare("UPDATE giveaways SET winner_id = ?, drawn = 1 WHERE id = ?");
                        $update->execute([$winner_id, $giveaway_id]);
                        $nameStmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                        $nameStmt->execute([$winner_id]);
                        $username = $nameStmt->fetchColumn();
                        $title = '🎉 لقد فزت بالجيفاواي!';
                        $message = 'تهانينا، لقد فزت بجائزة "' . $giveaway['prize'] . '" في الجيفاواي "' . $giveaway['title'] . '".';
                        addNotification($pdo, $winner_id, 'giveaway', $title, $message);
                        sendBotDM($pdo, $winner_id, $title, $message);
                        $userStmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
                        $userStmt->execute([$winner_id]);
                        $user = $userStmt->fetch(PDO::FETCH_ASSOC);
                        createBotTicket($pdo, $winner_id, 'prize',
                            'استلام جائزة الجيفاواي - ' . $user['username'],
                            'تهانينا على فوزك بالجيفاواي "' . $giveaway['title'] . '". يرجى التواصل مع الإدارة لاستلام جائزتك: ' . $giveaway['prize']
                        );
                        $response = ['success' => true, 'message' => 'تم السحب', 'winner_id' => $winner_id, 'winner_name' => $username];
                    } else {
                        $response = ['success' => false, 'message' => 'لا يوجد مشاركون في هذه الهبة'];
                    }
                }
            }
        }
        // ===== review_submission (نسخة كاملة ومشخصة) =====
        elseif ($action === 'review_submission') {
            $id = intval($_POST['id'] ?? 0);
            $status = $_POST['status'] ?? 'pending';

            $chk = $pdo->prepare("
                SELECT s.user_id, a.manager_role_key, a.name as type_name, a.id as type_id, s.answers
                FROM submissions s
                JOIN application_types a ON s.type_id = a.id
                WHERE s.id = ?
            ");
            $chk->execute([$id]);
            $row = $chk->fetch(PDO::FETCH_ASSOC);
            $managerRoleKey = $row['manager_role_key'] ?? null;

            error_log("🔍 review_submission - التقديم ID: $id, الحالة: $status, نوع التقديم: " . ($row['type_name'] ?? 'غير معروف'));

            if (!$canManageAppType($managerRoleKey)) {
                error_log("❌ review_submission - غير مصرح لك بمراجعة هذا الطلب");
                $response = ['success' => false, 'message' => 'غير مصرح لك بمراجعة هذا الطلب'];
            } else {
                try {
                    // تحديث حالة التقديم
                    $stmt = $pdo->prepare("UPDATE submissions SET status = ? WHERE id = ?");
                    $stmt->execute([$status, $id]);
                    error_log("✅ review_submission - تم تحديث حالة التقديم إلى: " . $status);

                    if ($status === 'accepted' || $status === 'rejected') {
                        $title = $status === 'accepted' ? '✅ تم قبول طلبك!' : '❌ تم رفض طلبك';
                        $message = $status === 'accepted'
                            ? 'تم قبول تقديمك "' . $row['type_name'] . '" بنجاح.'
                            : 'تم رفض تقديمك "' . $row['type_name'] . '".';

                        addNotification($pdo, $row['user_id'], 'submission', $title, $message);
                        sendBotDM($pdo, $row['user_id'], $title, $message);
                        error_log("✅ review_submission - تم إرسال الإشعارات للمستخدم ID: " . $row['user_id']);

                        // ==========================================================
                        //  منح الرتب والتغييرات عند القبول
                        // ==========================================================
                        if ($status === 'accepted') {
                            error_log("🔍 review_submission - بدأ عملية منح الرتب لتقديم ID: " . $id);

                            // جلب الديسكورد آي دي للمستخدم
                            $userStmt = $pdo->prepare("SELECT discord_id FROM users WHERE id = ?");
                            $userStmt->execute([$row['user_id']]);
                            $discord_id = $userStmt->fetchColumn();
                            error_log("🔍 review_submission - Discord ID للمستخدم: " . ($discord_id ? $discord_id : 'غير موجود'));

                            // --- حالة 1: تقديم على الشركة ---
                            if (mb_strpos($row['type_name'], 'شركة') !== false) {
                                error_log("🔍 review_submission - تم التعرف على تقديم الشركة");

                                // 1. منح رتبة الموقع "عضو بالشركة" (company_member)
                                $roleKeySite = 'company_member';
                                $roleStmt = $pdo->prepare("SELECT id FROM roles WHERE role_key = ?");
                                $roleStmt->execute([$roleKeySite]);
                                $roleId = $roleStmt->fetchColumn();
                                error_log("🔍 review_submission - معرف رتبة الموقع company_member: " . ($roleId ? $roleId : 'غير موجود'));

                                if ($roleId) {
                                    $insRole = $pdo->prepare("INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)");
                                    $insRole->execute([$row['user_id'], $roleId]);
                                    error_log("✅ review_submission - تم منح رتبة الشركة للمستخدم ID: " . $row['user_id']);
                                } else {
                                    error_log("❌ review_submission - خطأ فادح: رتبة 'company_member' غير موجودة في جدول roles!");
                                }

                                // 2. منح رول ديسكورد باستخدام Role ID
                                if ($discord_id) {
                                    $targetDiscordRoleId = '1532574205554593952';
                                    error_log("🔍 review_submission - إرسال أمر give_role للبوت بـ role_id: " . $targetDiscordRoleId);
                                    $actionId = addBotAction($pdo, $row['user_id'], 'give_role', [
                                        'discord_id' => $discord_id,
                                        'role_id' => $targetDiscordRoleId
                                    ]);
                                    error_log("✅ review_submission - تم إدراج أمر give_role في bot_actions برقم: " . ($actionId ? $actionId : 'فشل'));
                                } else {
                                    error_log("⚠️ review_submission - لا يمكن منح رول ديسكورد لأن discord_id غير موجود.");
                                }

                                // 3. استخراج الاسم والـ ID من الإجابات لتغيير النيكネーム
                                $answers = json_decode($row['answers'] ?? '{}', true);
                                if (is_array($answers) && !empty($answers)) {
                                    // جلب أسئلة هذا النوع
                                    $qStmt = $pdo->prepare("SELECT id, question_text FROM application_questions WHERE type_id = ?");
                                    $qStmt->execute([$row['type_id']]);
                                    $questions = $qStmt->fetchAll(PDO::FETCH_KEY_PAIR);

                                    $name = '';
                                    $idValue = '';
                                    foreach ($questions as $qid => $qtext) {
                                        if (mb_strpos($qtext, 'الاسم') !== false && isset($answers[$qid])) {
                                            $name = trim($answers[$qid]);
                                            error_log("✅ review_submission - تم العثور على اسم الشخصية: " . $name);
                                        }
                                        if (mb_strpos($qtext, 'الأيدي') !== false && isset($answers[$qid])) {
                                            $idValue = trim($answers[$qid]);
                                            error_log("✅ review_submission - تم العثور على الأيدي: " . $idValue);
                                        }
                                    }

                                    if (!empty($name) && !empty($idValue) && $discord_id) {
                                        $newNick = $name . ' | ' . $idValue;
                                        error_log("🔍 review_submission - إرسال أمر change_nickname باسم: " . $newNick);
                                        $actionId = addBotAction($pdo, $row['user_id'], 'change_nickname', [
                                            'discord_id' => $discord_id,
                                            'nickname' => $newNick
                                        ]);
                                        error_log("✅ review_submission - تم إدراج أمر change_nickname في bot_actions برقم: " . ($actionId ? $actionId : 'فشل'));
                                    } else {
                                        error_log("⚠️ review_submission - لم يتم العثور على إجابات كاملة للاسم أو الأيدي.");
                                    }
                                } else {
                                    error_log("⚠️ review_submission - الإجابات غير موجودة أو فارغة.");
                                }
                            } else {
                                error_log("🔍 review_submission - لم يتم التعرف على تقديم الشركة، نوع التقديم هو: " . $row['type_name']);
                            }
                        }
                    }

                    $response = ['success' => true, 'message' => 'تم التحديث بنجاح'];
                } catch (Exception $e) {
                    error_log('🔥 خطأ في review_submission: ' . $e->getMessage());
                    $response = ['success' => false, 'message' => 'حدث خطأ: ' . $e->getMessage()];
                }
            }
        }
        // ===== get_submission_answers =====
        elseif ($action === 'get_submission_answers') {
            $id = intval($_POST['id'] ?? 0);
            $chk = $pdo->prepare("
                SELECT s.*, u.username, a.name as type_name, a.manager_role_key
                FROM submissions s
                JOIN users u ON s.user_id = u.id
                JOIN application_types a ON s.type_id = a.id
                WHERE s.id = ?
            ");
            $chk->execute([$id]);
            $submission = $chk->fetch(PDO::FETCH_ASSOC);
            
            if (!$submission) {
                $response = ['success' => false, 'message' => 'الطلب غير موجود'];
            } else {
                if (!$canManageAppType($submission['manager_role_key'])) {
                    $response = ['success' => false, 'message' => 'غير مصرح بعرض هذا الطلب'];
                } else {
                    $answers = json_decode($submission['answers'] ?? '{}', true);
                    if (!is_array($answers)) $answers = [];
                    $questions = [];
                    if (!empty($answers)) {
                        $qids = array_keys($answers);
                        $placeholders = implode(',', array_fill(0, count($qids), '?'));
                        $qstmt = $pdo->prepare("SELECT id, question_text FROM application_questions WHERE id IN ($placeholders)");
                        $qstmt->execute($qids);
                        $questions = $qstmt->fetchAll(PDO::FETCH_KEY_PAIR);
                    }
                    $response = [
                        'success' => true,
                        'submission' => $submission,
                        'answers' => $answers,
                        'questions' => $questions
                    ];
                }
            }
        }
        // ===== add_question =====
        elseif ($action === 'add_question') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $type_id = intval($_POST['type_id'] ?? 0);
                $text = trim($_POST['text'] ?? 'سؤال جديد');
                $field_type = $_POST['field_type'] ?? 'text';
                $options = $_POST['options'] ?? '[]';
                $required = intval($_POST['required'] ?? 0);
                $stmt = $pdo->prepare("INSERT INTO application_questions (type_id, question_text, field_type, options, required) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$type_id, $text, $field_type, $options, $required]);
                $response = ['success' => true, 'message' => 'تمت الإضافة', 'id' => $pdo->lastInsertId()];
            }
        }
        // ===== update_question =====
        elseif ($action === 'update_question') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $text = trim($_POST['text'] ?? '');
                $field_type = $_POST['field_type'] ?? 'text';
                $options = $_POST['options'] ?? '[]';
                $required = intval($_POST['required'] ?? 0);
                $stmt = $pdo->prepare("UPDATE application_questions SET question_text = ?, field_type = ?, options = ?, required = ? WHERE id = ?");
                $stmt->execute([$text, $field_type, $options, $required, $id]);
                $response = ['success' => true, 'message' => 'تم التحديث'];
            }
        }
        // ===== remove_question =====
        elseif ($action === 'remove_question') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("DELETE FROM application_questions WHERE id = ?");
                $stmt->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ===== update_profile =====
        elseif ($action === 'update_profile') {
            $response = ['success' => false, 'message' => 'تغيير الاسم غير مسموح، اسمك مرتبط بحساب Discord'];
        }
        // ===== update_user_roles =====
        elseif ($action === 'update_user_roles') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'فقط الفاوندر يقدر يعدل الرتب'];
            } else {
                $target_user_id = intval($_POST['user_id'] ?? 0);
                $role_ids = json_decode($_POST['role_ids'] ?? '[]', true);
                if (!is_array($role_ids)) $role_ids = [];
                $role_ids = array_map('intval', $role_ids);
                $pdo->prepare("DELETE FROM user_roles WHERE user_id = ?")->execute([$target_user_id]);
                $ins = $pdo->prepare("INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)");
                foreach ($role_ids as $rid) {
                    $ins->execute([$target_user_id, $rid]);
                }
                $response = ['success' => true, 'message' => 'تم تحديث الرتب'];
            }
        }
        // ===== add_job =====
        elseif ($action === 'add_job') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $name = trim($_POST['name'] ?? '');
                if (empty($name)) {
                    $response = ['success' => false, 'message' => 'أدخل اسم الوظيفة'];
                } else {
                    $stmt = $pdo->prepare("INSERT INTO job_titles (name) VALUES (?)");
                    $stmt->execute([$name]);
                    $response = ['success' => true, 'message' => 'تمت الإضافة', 'id' => $pdo->lastInsertId()];
                }
            }
        }
        // ===== delete_job =====
        elseif ($action === 'delete_job') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $pdo->prepare("DELETE FROM job_titles WHERE id = ?")->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ===== update_user_jobs =====
        elseif ($action === 'update_user_jobs') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $user_id = intval($_POST['user_id'] ?? 0);
                $job_ids = json_decode($_POST['job_ids'] ?? '[]', true);
                if (!is_array($job_ids)) $job_ids = [];
                $job_ids = array_map('intval', $job_ids);
                $pdo->prepare("DELETE FROM user_jobs WHERE user_id = ?")->execute([$user_id]);
                $ins = $pdo->prepare("INSERT IGNORE INTO user_jobs (user_id, job_id) VALUES (?, ?)");
                foreach ($job_ids as $jid) {
                    $ins->execute([$user_id, $jid]);
                }
                $response = ['success' => true, 'message' => 'تم تحديث الوظائف'];
            }
        }
        // ===== add_application_type =====
        elseif ($action === 'add_application_type') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $name = trim($_POST['name'] ?? '');
                $desc = trim($_POST['description'] ?? '');
                $manager_role_key = trim($_POST['manager_role_key'] ?? '');
                $min_hours = intval($_POST['min_hours'] ?? 0);
                $min_history = intval($_POST['min_history'] ?? 0);
                $min_money = intval($_POST['min_money'] ?? 0);
                $requirements = trim($_POST['requirements'] ?? '');
                if (empty($name)) {
                    $response = ['success' => false, 'message' => 'أدخل اسم التقديم'];
                } else {
                    $stmt = $pdo->prepare("INSERT INTO application_types (name, description, manager_role_key, min_hours, min_history, min_money, requirements) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$name, $desc, $manager_role_key ?: null, $min_hours, $min_history, $min_money, $requirements]);
                    $response = ['success' => true, 'message' => 'تمت الإضافة', 'id' => $pdo->lastInsertId()];
                }
            }
        }
        // ===== update_application_type =====
        elseif ($action === 'update_application_type') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $name = trim($_POST['name'] ?? '');
                $desc = trim($_POST['description'] ?? '');
                $manager_role_key = trim($_POST['manager_role_key'] ?? '');
                $min_hours = intval($_POST['min_hours'] ?? 0);
                $min_history = intval($_POST['min_history'] ?? 0);
                $min_money = intval($_POST['min_money'] ?? 0);
                $requirements = trim($_POST['requirements'] ?? '');
                if (empty($name)) {
                    $response = ['success' => false, 'message' => 'أدخل اسم التقديم'];
                } else {
                    $stmt = $pdo->prepare("UPDATE application_types SET name = ?, description = ?, manager_role_key = ?, min_hours = ?, min_history = ?, min_money = ?, requirements = ? WHERE id = ?");
                    $stmt->execute([$name, $desc, $manager_role_key ?: null, $min_hours, $min_history, $min_money, $requirements, $id]);
                    $response = ['success' => true, 'message' => 'تم التحديث'];
                }
            }
        }
        // ===== delete_application_type =====
        elseif ($action === 'delete_application_type') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $id = intval($_POST['id'] ?? 0);
                $pdo->prepare("DELETE FROM application_types WHERE id = ?")->execute([$id]);
                $response = ['success' => true, 'message' => 'تم الحذف'];
            }
        }
        // ===== add_giveaway =====
        elseif ($action === 'add_giveaway') {
            if (!$isFounder) {
                $response = ['success' => false, 'message' => 'غير مصرح'];
            } else {
                $title = trim($_POST['title'] ?? 'هدية جديدة');
                $description = trim($_POST['description'] ?? '');
                $prize = trim($_POST['prize'] ?? 'جائزة');
                $ends_at = $_POST['ends_at'] ?? null;
                $stmt = $pdo->prepare("INSERT INTO giveaways (title, description, prize, ends_at) VALUES (?, ?, ?, ?)");
                $stmt->execute([$title, $description, $prize, $ends_at]);
                $response = ['success' => true, 'message' => 'تمت إضافة الهبة', 'id' => $pdo->lastInsertId()];
            }
        }
        else {
            $response = ['success' => false, 'message' => 'إجراء غير معروف'];
        }
    } catch (PDOException $e) {
        error_log('Database error in api.php: ' . $e->getMessage());
        $response = ['success' => false, 'message' => 'حدث خطأ في قاعدة البيانات: ' . $e->getMessage()];
    } catch (Exception $e) {
        error_log('General error in api.php: ' . $e->getMessage());
        $response = ['success' => false, 'message' => 'حدث خطأ غير متوقع: ' . $e->getMessage()];
    }

    echo json_encode($response);
    exit;
}