<?php
// Italiano/store.php - مجرد نقطة عبور للتوجيه
require_once __DIR__ . '/inc/functions.php';
require_once __DIR__ . '/inc/config.php';

header('Location: index.php#tab-store');
exit;
?>